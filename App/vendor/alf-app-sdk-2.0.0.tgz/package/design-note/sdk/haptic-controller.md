# HapticController — Tài liệu tham khảo

`HapticController` quản lý rung/haptic feedback trên thiết bị di động (iOS & Android) và web. Cho phép tùy chỉnh **cường độ** (nhẹ, vừa, mạnh) và **độ dài** (one-shot hoặc duration ms).

---

## 1. Tổng quan

### Mục đích

- Trigger rung điện thoại với tham số quyết định cường độ và độ dài
- Cung cấp preset nhanh cho các ngữ cảnh phổ biến (tap, click, success, warning, error)
- Hỗ trợ đa nền tảng: iOS (dùng Capacitor Haptics plugin), Android (Navigator.vibrate + Capacitor Haptics), Web (Navigator.vibrate)

### Platform support

| Platform | Cơ chế | Ghi chú |
|----------|--------|---------|
| iOS | `Capacitor.Plugins.Haptics.impact()` / `.notification()` | Chỉ hỗ trợ one-shot. Duration dài được mô phỏng bằng nhiều impact lặp lại |
| Android | `Capacitor.Plugins.Haptics.impact()` + `Navigator.vibrate()` | Duration tuỳ chỉnh hoạt động đầy đủ |
| Web | `Navigator.vibrate()` | Duration tuỳ chỉnh, yêu cầu trình duyệt hỗ trợ |

---

## 2. API Reference

### `HapticController.supported`

Kiểm tra thiết bị có hỗ trợ haptic feedback không.

```typescript
get supported(): boolean
```

- `true`: nếu native (iOS/Android) có Capacitor Haptics plugin, hoặc web có `Navigator.vibrate`
- `false`: nếu không hỗ trợ

---

### `Trigger(options?: HapticOptions)`

Phương thức chính — trigger rung với tuỳ chỉnh cường độ và độ dài.

```typescript
async Trigger(options?: HapticOptions): Promise<void>
```

| Param | Type | Default | Mô tả |
|-------|------|---------|-------|
| `options.intensity` | `'light' \| 'medium' \| 'heavy'` | `'medium'` | Cường độ rung |
| `options.duration` | `'oneShot' \| number` | `'oneShot'` | Độ dài: one-shot ngắn hoặc duration ms |

**Ví dụ:**

```typescript
// One-shot mặc định (medium)
await ALF.Instance.Haptic.Trigger()

// Rung nhẹ, one-shot
await ALF.Instance.Haptic.Trigger({ intensity: 'light' })

// Rung mạnh kéo dài 500ms
await ALF.Instance.Haptic.Trigger({ intensity: 'heavy', duration: 500 })

// Rung vừa kéo dài 1 giây
await ALF.Instance.Haptic.Trigger({ intensity: 'medium', duration: 1000 })
```

---

### `Preset(preset: HapticPreset)`

Sử dụng preset có sẵn theo ngữ cảnh.

```typescript
async Preset(preset: HapticPreset): Promise<void>
```

| Preset | Cảm giác | Tương đương |
|--------|----------|-------------|
| `'tap'` | Nhẹ, one-shot | `Trigger({ intensity: 'light', duration: 'oneShot' })` |
| `'click'` | Nhẹ, one-shot | Giống `tap` |
| `'success'` | Notification-style (success) | notification type |
| `'warning'` | Notification-style (warning) | notification type |
| `'error'` | Notification-style (error) | notification type |
| `'selection'` | Cảm giác chọn item | selectionStart → selectionEnd |
| `'impact'` | Medium one-shot | `Trigger({ intensity: 'medium', duration: 'oneShot' })` |

**Ví dụ:**

```typescript
await ALF.Instance.Haptic.Preset('success')
await ALF.Instance.Haptic.Preset('error')
await ALF.Instance.Haptic.Preset('selection')
```

---

### Shortcut methods

Các phương thức shorthand cho các ngữ cảnh thông dụng.

| Method | Tương đương |
|--------|-------------|
| `Tap()` | `Trigger({ intensity: 'light', duration: 'oneShot' })` |
| `Click()` | `Trigger({ intensity: 'light', duration: 'oneShot' })` |
| `Heavy()` | `Trigger({ intensity: 'heavy', duration: 'oneShot' })` |
| `Success()` | `Preset('success')` |
| `Warning()` | `Preset('warning')` |
| `Error()` | `Preset('error')` |
| `Selection()` | `Preset('selection')` |

**Ví dụ:**

```typescript
await ALF.Instance.Haptic.Tap()
await ALF.Instance.Haptic.Click()
await ALF.Instance.Haptic.Heavy()
await ALF.Instance.Haptic.Success()
await ALF.Instance.Haptic.Warning()
await ALF.Instance.Haptic.Error()
```

---

## 3. Types

### `HapticIntensity`

```typescript
type HapticIntensity = 'light' | 'medium' | 'heavy'
```

### `HapticDuration`

```typescript
type HapticDuration = 'oneShot' | number
```

- `'oneShot'`: rung một nhịp ngắn
- `number`: thời gian rung tính bằng milliseconds

### `HapticOptions`

```typescript
interface HapticOptions {
  intensity?: HapticIntensity  // mặc định: 'medium'
  duration?: HapticDuration    // mặc định: 'oneShot'
}
```

### `HapticPreset`

```typescript
type HapticPreset =
  | 'tap'
  | 'click'
  | 'success'
  | 'warning'
  | 'error'
  | 'selection'
  | 'impact'
```

---

## 4. Usage examples

### 4.1. Cơ bản

```typescript
import { ALF } from '@alf/app-sdk'

// Rung nhẹ khi tap vào button
button.addEventListener('click', async () => {
  await ALF.Instance.Haptic.Tap()
})
```

### 4.2. Notification feedback

```typescript
// Sau khi hành động thành công
async function onSaveSuccess() {
  await ALF.Instance.Haptic.Success()
}

// Khi có lỗi
async function onSaveError() {
  await ALF.Instance.Haptic.Error()
}
```

### 4.3. Heavy impact + kéo dài

```typescript
// Rung mạnh trong 1 giây để cảnh báo
await ALF.Instance.Haptic.Trigger({
  intensity: 'heavy',
  duration: 1000,
})
```

### 4.4. Kiểm tra support trước khi gọi

```typescript
if (ALF.Instance.Haptic.supported) {
  await ALF.Instance.Haptic.Tap()
} else {
  console.log('Device does not support haptic feedback')
}
```

### 4.5. Kết hợp với animation

```typescript
import { ALF } from '@alf/app-sdk'

async function onButtonPress() {
  // Rung nhẹ khi bắt đầu press
  await ALF.Instance.Haptic.Tap()

  // Animation hoặc logic khác...
  await animateButton()

  // Rung success khi hoàn thành
  await ALF.Instance.Haptic.Success()
}
```

---

## 5. Implementation notes

### iOS limitations

- iOS không hỗ trợ `Navigator.vibrate()`
- Capacitor Haptics plugin trên iOS chỉ hỗ trợ **impact one-shot** (không có duration)
- Khi gọi `Trigger()` với `duration` > 0 trên iOS, controller mô phỏng bằng cách gọi `impact()` lặp lại mỗi 100ms (tối đa 10 lần ~ 1 giây)

### Android

- Hỗ trợ đầy đủ: cả impact one-shot và `Navigator.vibrate()` cho duration tuỳ chỉnh
- `getVibrationMs()` nhân duration với hệ số intensity: light=0.5, medium=1.0, heavy=1.5

### Web

- Dùng `Navigator.vibrate(ms)` cho duration tuỳ chỉnh
- Không hỗ trợ notification-style hay selection feedback
- `supported` = `false` nếu `navigator.vibrate` không tồn tại

---

## 6. So sánh với DeviceController.vibrate()

`DeviceController` hiện có sẵn method `vibrate(type: HapticType)` và `tap()`. `HapticController` là bản chuyên biệt hoá với:

| Tính năng | `DeviceController.vibrate()` | `HapticController` |
|-----------|-----------------------------|-------------------|
| Cường độ | `light/medium/heavy` (fixed) | `light/medium/heavy` + multiplier cho duration |
| Duration | Chỉ one-shot | One-shot + duration ms |
| Preset | `success/warning/error/selection` | `tap/click/success/warning/error/selection/impact` |
| Trigger tuỳ chỉnh | Không | `Trigger({ intensity, duration })` |
| Kiểm tra support | Không | `supported` getter |

> **Khuyến nghị:** Dùng `HapticController` cho mọi nhu cầu haptic mới. `DeviceController.vibrate()` giữ lại cho backward compatibility.
