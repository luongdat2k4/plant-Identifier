# Sơ đồ thực thể & Class Diagram

## 1. Class Diagram — Hệ thống ALF Framework

```mermaid
classDiagram
    class ALF {
        -static _instance: ALF
        +Config: ConfigManager
        +Ads: AdController
        +Camera: CameraController
        +Permission: PermissionController
        +Storage: StorageController
        +Firebase: FirebaseController
        +Analytics: AnalyticsController
        +Share: ShareController
        +Media: MediaController
        +static get Instance() ALF
        -constructor()
    }

    class ConfigManager {
        -configData: Config
        +set(config: Config) void
        +get(path: string) any
        +getAll() Config
        +getSettings() Settings
        +getKeys() KeysConfig
        +isReady() boolean
    }

    class ConfigConverter {
        +static convert(raw: Object, mappings?: Object) Config
        +static convertFromJSON(path: string, mappings?: Object) Promise~Config~
    }

    class AdController {
        -af: ALF
        -initialized: boolean
        +init() Promise~void~
        +InitBannerAd() Promise~void~
        +HideBannerAd() Promise~void~
        +ShowInterstitial(placement?: string) Promise~void~
        +ShowRewarded(placement?: string) Promise~void~
        +LoadRewarded() Promise~void~
        +IsRewardedReady() boolean
    }

    class CameraController {
        -af: ALF
        +init() Promise~void~
        +Take(options?: CameraOptions) Promise~string~
    }

    class PermissionController {
        -af: ALF
        +init() Promise~void~
        +RequestPermission(perm: PermissionType) Promise~PermissionStatus~
        +CheckPermission(perm: PermissionType) Promise~PermissionStatus~
    }

    class StorageController {
        -af: ALF
        -dbPath: string
        +init() Promise~void~
        +Get(key: string) Promise~any~
        +Set(key: string, value: any) Promise~void~
        +Delete(key: string) Promise~void~
        +Clear() Promise~void~
    }

    class FirebaseController {
        -af: ALF
        +init() Promise~void~
        +FetchRemoteConfig() Promise~void~
        +GetRemoteValue(key: string) Promise~any~
    }

    class AnalyticsController {
        -af: ALF
        +init() Promise~void~
        +LogEvent(name: string, params?: object) Promise~void~
        +SetUserId(id: string) Promise~void~
    }

    class ShareController {
        -af: ALF
        +init() Promise~void~
        +ShareImage(base64: string, fileName?: string) Promise~void~
        +ShareText(text: string) Promise~void~
        +ShareFile(uri: string) Promise~void~
    }

    class MediaController {
        -af: ALF
        +init() Promise~void~
        +CaptureImage(elementId: string) Promise~string~
        +CreateSlideshowVideo(deps: SlideshowDeps, opts: SlideshowOpts) Promise~VideoResult~
    }

    class initSDK {
        +initSDK(config: Config) Promise~void~
    }

    class Config {
        +settings: Settings
        +keys: KeysConfig
    }

    class Settings {
        +dev: boolean
        +isGame: boolean
        +isApp: boolean
        +appName: string
        +appVersion: string
        +environment: string
    }

    ALF "1" *-- "1" ConfigManager
    ALF "1" *-- "1" AdController
    ALF "1" *-- "1" CameraController
    ALF "1" *-- "1" PermissionController
    ALF "1" *-- "1" StorageController
    ALF "1" *-- "1" FirebaseController
    ALF "1" *-- "1" AnalyticsController
    ALF "1" *-- "1" ShareController
    ALF "1" *-- "1" MediaController

    initSDK --> ALF : tạo & init
    initSDK --> Config : nhận config object
    Config --> ConfigManager : set vào memory
    AdController --> ConfigManager : đọc sdkKey, adUnitId
    AnalyticsController --> ConfigManager : đọc devKey, appId
    FirebaseController --> ConfigManager : đọc firebase config
    mọi Controller --> ConfigManager : đọc settings (dev, isGame...)
    AdController --> ALF : gọi controller khác (vd: Permission)
    ShareController --> MediaController : lấy ảnh đã capture để share
    CameraController --> PermissionController : kiểm tra quyền trước khi chụp
```

## 2. Dependency Graph — Controllers gọi nhau

```mermaid
graph TD
    ALF[ALF Singleton]

    ALF --> Config[ConfigManager]
    ALF --> Ads[AdController]
    ALF --> Camera[CameraController]
    ALF --> Permission[PermissionController]
    ALF --> Storage[StorageController]
    ALF --> Firebase[FirebaseController]
    ALF --> Analytics[AnalyticsController]
    ALF --> Share[ShareController]
    ALF --> Media[MediaController]

    Ads -.->|đọc key & settings| Config
    Analytics -.->|đọc key & settings| Config
    Firebase -.->|đọc key & settings| Config
    Camera -.->|đọc settings| Config
    Share -.->|đọc settings| Config
    Storage -.->|đọc settings| Config
    Media -.->|đọc settings| Config
    Permission -.->|đọc settings| Config
    Camera -.->|kiểm tra quyền| Permission
    Media -.->|kiểm tra quyền| Permission
    Share -.->|lấy ảnh từ| Media
    Ads -.->|lưu config| Storage
    Analytics -.->|log event| Firebase
```

## 3. Package Diagram

```mermaid
packages
    package "ALF Framework (af/)" {
        package "controllers" {
            component "AdController"
            component "CameraController"
            component "PermissionController"
            component "StorageController"
            component "FirebaseController"
            component "AnalyticsController"
            component "ShareController"
            component "MediaController"
        }
        package "types" {
            component "ad.types"
            component "camera.types"
            component "permission.types"
            component "config.types"
        }
        package "utils" {
            component "ConfigConverter"
        }
        component "ALF (singleton)"
        component "ConfigManager"
        component "initSDK(config)"
    }

    package "Application (src/)" {
        component "main.ts"
        component "Vue App"
        component "Router"
    }

    package "Native Plugins" {
        component "Capacitor Plugins"
        component "AppLovin MAX"
        component "AppsFlyer"
        component "Firebase"
    }

    package "Config" {
        component "config.json"
    }

    "main.ts" --> "initSDK(config)"
    "initSDK(config)" --> "Config"
    "initSDK(config)" --> "ALF (singleton)"
    "ALF (singleton)" --> "ConfigManager"
    "ALF (singleton)" --> controllers
    "Config" --> "ConfigManager"
    controllers --> "Native Plugins"
    "Vue App" --> "ALF (singleton)"
```
