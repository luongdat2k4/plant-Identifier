# Export SDK — Hướng dẫn đưa `@alf/app-sdk` thành npm package

Tài liệu này hướng dẫn cách build, publish lên Gitea, và sử dụng `@alf/app-sdk` như một package npm thực thụ. Các dự án khác có thể `npm install @alf/app-sdk` từ Gitea registry.

---

## 1. Cấu trúc package

Sau khi build, `dist/` chứa toàn bộ những gì cần publish:

```
dist/
├── index.mjs                # ES module entry (import)
├── index.cjs                # CommonJS entry (require)
├── index.d.ts               # TypeScript declarations
├── alf/                     # .d.ts cho controllers, types, utils
├── assets/fonts/            # Font files (Nunito)
├── vite/
│   ├── reloadPlugin.mjs
│   ├── reloadPlugin.cjs
│   └── reloadPlugin.d.ts
```

`package.json` exports map quy định 3 entry point:


| Import path              | File                                  | Mục đích                             |
| ------------------------ | ------------------------------------- | ------------------------------------ |
| `@alf/app-sdk`           | `dist/index.mjs` / `.cjs`             | Main SDK — `initSDK()`, `ALF`, types |
| `@alf/app-sdk/vite`      | `dist/vite/reloadPlugin.mjs` / `.cjs` | Vite plugin cho dev reload           |
| `@alf/app-sdk/style.css` | `dist/app-sdk.css`                    | Base styles + fonts                  |


---

## 2. Build

### 2.1. Yêu cầu

- Node.js >= 18
- npm >= 9

### 2.2. Build package

```bash
# Từ thư mục gốc của app-framework
npm run build
```

Kết quả: thư mục `dist/` được tạo với đầy đủ `.mjs`, `.cjs`, `.d.ts`, fonts.

### 2.3. Kiểm tra dist

```bash
ls dist/
# Kết quả mong đợi:
#   index.mjs  index.cjs  index.d.ts
#   alf/  assets/  vite/
```

---

## 3. Cấu hình Gitea npm registry

Gitea hỗ trợ npm registry built-in. Mỗi user hoặc organization có registry riêng.

### 3.1. Tạo Personal Access Token

**Cách 1 — Qua UI:**

1. Vào **Settings → Applications** (hoặc `https://git.ifr.vn/user/settings/applications`)
2. Trong mục **Manage Access Tokens**, chọn **Generate New Token**
3. Chọn permissions cần thiết, tối thiểu: `**read:package`** và `**write:package**`
4. Copy token sau khi tạo (chỉ hiện 1 lần)

**Cách 2 — Qua API:**

```bash
curl -H "Content-Type: application/json" \
  -d '{"name":"alf-sdk-publish","scopes":["write:package"]}' \
  -u 'username:password' \
  "https://git.ifr.vn/api/v1/users/{username}/tokens"
```

Response trả về `sha1` là token của bạn.

### 3.2. Cấu hình npm registry

Dùng `npm config set` để cấu hình registry cho scope `@alf`:

```bash
# Cấu hình registry cho scope @alf
npm config set @alf:registry=https://git.ifr.vn/api/packages/alf/npm/

# Cấu hình auth token
npm config set -- '//git.ifr.vn/api/packages/alf/npm/:_authToken' "YOUR_TOKEN"
```


| Parameter    | Ý nghĩa                                                              |
| ------------ | -------------------------------------------------------------------- |
| `@alf`       | Scope của package (khớp với `"name": "@alf/app-sdk"`)                |
| `alf`        | Owner của package trên Gitea (tên user hoặc org)                     |
| `YOUR_TOKEN` | Personal access token có permission `read:package` + `write:package` |


> **Lưu ý:** Nếu bạn đã config token ở global npm config (`~/.npmrc`), nó sẽ được dùng cho tất cả các dự án trên máy. Nếu chỉ muốn cho dự án này, tạo `.npmrc` trong thư mục gốc của `app-framework`.

---

## 4. Publish lên Gitea

### 4.1. publishConfig trong package.json

`package.json` đã có sẵn:

```json
{
  "publishConfig": {
    "registry": "https://git.ifr.vn/api/packages/alf/npm/"
  }
}
```

Khi có `publishConfig`, lệnh `npm publish` tự động dùng registry này — không cần flag `--registry`.

### 4.2. Publish

```bash
npm run publish:gitea
# tương đương: npm run build && npm publish
```

Package sẽ xuất hiện trên Gitea tại: `https://git.ifr.vn/alf/-/packages`

### 4.3. Update version

```bash
# Patch (bug fix)
npm version patch

# Minor (thêm tính năng, backward compatible)
npm version minor

# Major (breaking change)
npm version major

# Build & publish
npm run publish:gitea
```

### 4.4. Unpublish (xoá package)

> **Lưu ý:** Gitea npm registry có giới hạn: chỉ cho phép unpublish nếu package có **ít hơn 24 giờ tuổi** và **chưa có ai download**. Nếu package đã cũ hơn, bạn phải tăng version và publish bản mới — Gitea sẽ dùng version mới nhất.

```bash
# Xoá toàn bộ package (chỉ hoạt động nếu package < 24h)
npm unpublish @alf/app-sdk --force

# Xoá một version cụ thể (chỉ hoạt động nếu version < 24h)
npm unpublish @alf/app-sdk@1.1.6 --force

# Kiểm tra danh sách version hiện có trước khi unpublish
npm view @alf/app-sdk versions
```

### 4.5. .npmignore / files

Package sử dụng field `"files"` trong `package.json` (không cần `.npmignore`):

```json
{
  "files": [
    "dist",
    "plugins/applovin",
    "README.md",
    "LICENSE"
  ]
}
```

Chỉ những mục này được publish: `dist/`, thư mục native `plugins/applovin/` (android + ios + Package.swift), `design-note/`, `README.md`, `LICENSE`. `sdk/` source gốc, `src-dev/`, `config.json`, `vite.config.ts`, `tsconfig.*` không xuất hiện trong package.

---

## 5. Cài đặt từ dự án khác

### 5.1. Cấu hình trong dự án tiêu thụ

Tạo file `.npmrc` ở thư mục gốc của dự án cần cài `@alf/app-sdk`:

```
@alf:registry=https://git.ifr.vn/api/packages/alf/npm/
//git.ifr.vn/api/packages/alf/npm/:_authToken=YOUR_TOKEN
```

Scope `@alf` đảm bảo chỉ package `@alf/*` mới lấy từ Gitea registry. Các package khác (vue, capacitor, ...) vẫn dùng npmjs.com mặc định.

### 5.2. Install

```bash
npm install @alf/app-sdk
```

### 5.3. Cài từ local path (khi chưa publish)

```bash
# Cách 1: npm link
cd app-framework
npm link

cd my-project
npm link @alf/app-sdk

# Cách 2: npm install từ local path
cd my-project
npm install ../app-framework
```

### 5.4. Kiểm tra package đã cài

```bash
ls node_modules/@alf/app-sdk/dist/
# Phải thấy: index.mjs, index.cjs, index.d.ts, assets/, vite/
```

---

## 6. Dependencies của package

### 6.1. runtime dependencies (tự động cài cùng package)

```
@capacitor-firebase/remote-config
@capacitor/app
@capacitor/core
@capacitor/device
@capacitor/filesystem
@capacitor/haptics
@capacitor/local-notifications
@capacitor/network
@capacitor/preferences
@capacitor/push-notifications
@capacitor/share
appsflyer-capacitor-plugin
html-to-image
vue-i18n
```

> **AppLovin MAX plugin:** Đã tích hợp sẵn *trong* SDK (thư mục `plugins/applovin/` chứa native `android/` + `ios/`). SDK root `package.json` khai báo `"capacitor"` trỏ tới đó, nên `npx cap sync` ở project tiêu thụ tự động đăng ký native code — không cần cài plugin riêng.

### 6.2. peer dependencies (dự án tiêu thụ phải tự cài)

```json
{
  "vue": "^3.5.0",
  "vue-router": "^4.5.0"
}
```

Dự án của bạn **bắt buộc** phải có Vue 3 và Vue Router:

```bash
npm install vue@^3.5.0 vue-router@^4.5.0
```

---

## 7. Sử dụng trong dự án mới

```typescript
// 1. Import
import { initSDK, ALF, SetupFlow, registerSetupRoutes, SetupFlowProvide } from '@alf/app-sdk'
import '@alf/app-sdk/style.css'

// 2. Gọi initSDK() trước khi mount Vue app
await initSDK(config)

// 3. Đăng ký setup routes
registerSetupRoutes(router, config.settings)

// 4. Dùng controllers
const online = await ALF.Instance.Network.isOnline()
const deviceId = ALF.Instance.Device.getDeviceId()
await ALF.Instance.Ads.InitBannerAd()
```

---

## 8. Troubleshooting

### `Cannot find module '@alf/app-sdk'`

Kiểm tra:

```bash
ls node_modules/@alf/app-sdk/
npm ls @alf/app-sdk
```

### `ERR_REQUIRE_ESM` khi dùng require()

Package là `"type": "module"`. Nếu dùng CommonJS:

```javascript
// Dùng dynamic import:
const sdk = await import('@alf/app-sdk')

// Hoặc dùng require với .cjs extension:
const sdk = require('@alf/app-sdk/dist/index.cjs')
```

### `401 Unauthorized` khi publish

Token không hợp lệ hoặc chưa được cấu hình. Kiểm tra:

```bash
npm config list
# Phải thấy dòng: //git.ifr.vn/api/packages/alf/npm/:_authToken=xxx
```

Tạo token mới ở **Settings → Applications** nếu cần.

### `403 Forbidden` khi publish

Bạn không có quyền ghi vào registry của owner đó. Kiểm tra:

- Token có scope `write:package` không?
- Bạn có là member của org đó không?

### `409 Conflict` / package already exists

Không thể publish nếu package cùng tên + version đã tồn tại. Tăng version:

```bash
npm version patch
npm run publish:gitea
```

### Missing peerDependencies

```bash
npm install vue@^3.5.0 vue-router@^4.5.0
```

### Build thất bại vì missing file

```bash
rm -rf node_modules dist
npm install
npm run build
```

---

## 9. CI/CD với Gitea Actions

Tạo file `.gitea/workflows/publish.yaml`:

```yaml
name: Publish SDK to Gitea

on:
  push:
    tags:
      - 'v*'

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm ci
      - run: npm run build
      - run: npm publish
        env:
          NODE_AUTH_TOKEN: ${{ secrets.GITEA_PACKAGES_TOKEN }}
```

Tạo secret `GITEA_PACKAGES_TOKEN` trong **Settings → Secrets and variables → Actions** của repo Gitea, giá trị là token bạn đã tạo ở bước 3.1.

> **Lưu ý:** Khi dùng Gitea Actions, `publishConfig.registry` trong `package.json` sẽ được dùng tự động. Token được inject qua biến môi trường `NODE_AUTH_TOKEN`, npm tự động đọc biến này và dùng làm auth token cho registry.

---

## 10. Các lệnh npm được Gitea hỗ trợ

Gitea npm registry hỗ trợ các lệnh sau:

- `npm install`
- `npm ci`
- `npm publish`
- `npm unpublish`
- `npm dist-tag`
- `npm view`
- `npm search`

---

## 11. Tham khảo

- [Gitea npm package registry docs](https://docs.gitea.com/usage/packages/npm)
- [Gitea API authentication](https://docs.gitea.com/development/api-usage#authentication)
- [npm publishConfig](https://docs.npmjs.com/cli/v10/configuring-npm/package-json#publishconfig)
- [npm scoped packages](https://docs.npmjs.com/misc/scope/)

