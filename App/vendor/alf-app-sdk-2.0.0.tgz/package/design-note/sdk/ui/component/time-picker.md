# TimePicker - Clock Face Time Selection

Component popup chọn giờ với giao diện đồng hồ (clock face) kiểu Vuetify, hỗ trợ 24h/12h, AM/PM, seconds, và tùy chỉnh màu sắc.

## Layout

```
┌─────────────────────────────────┐
│          CHỌN GIỜ              │  ← Title
├─────────────────────────────────┤
│                                 │
│       [12]  :  [00]  AM/PM     │  ← Header: editable HH:MM + AM/PM toggle
│                                 │
├─────────────────────────────────┤
│                                 │
│          ┌─────────┐           │
│         ╱12        1╲          │
│        ╱              ╲         │
│      11                 2       │
│      │                   │      │  ← Clock face dial
│      │        ●          │      │     with rotating hand
│     10 │                 │ 3    │
│       ╲                  ╱      │
│        9               4        │
│         ╲             ╱         │
│            8   7   5            │
│          └─────────┘           │
│                                 │
├─────────────────────────────────┤
│                    [Huỷ]  [OK]  │  ← Action buttons
└─────────────────────────────────┘
```

## Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `modelValue` | `string \| null` | `null` | Selected time in `'HH:MM'` or `'HH:MM:SS'` format (v-model) |
| `theme` | `PickerTheme` | - | Theme customization object |
| `use24h` | `boolean` | `true` | Dùng định dạng 24h hay 12h |
| `minuteStep` | `1 \| 5 \| 10 \| 15 \| 30` | `5` | Bước nhảy của phút trên đồng hồ |
| `useSeconds` | `boolean` | `false` | Hiển thị trường seconds |
| `title` | `string` | `'Chọn giờ'` | Tiêu đề popup |
| `okText` | `string` | `'OK'` | Confirm button text |
| `cancelText` | `string` | `'Huỷ'` | Cancel button text |

## Events

| Event | Payload | Description |
|-------|---------|-------------|
| `update:modelValue` | `string \| null` | Emitted with `'HH:MM'` (or `'HH:MM:SS'` when `useSeconds`) when OK is pressed |
| `open` | - | Emitted when the picker is opened |

## PickerTheme interface

```typescript
interface PickerTheme {
  backgroundColor?: string      // Màu nền popup (mặc định: #ffffff)
  strongTextColor?: string      // Màu chữ đậm: header, item active (mặc định: #111111)
  mediumTextColor?: string      // Màu chữ trung bình: separator, label (mặc định: #888888)
  weakTextColor?: string        // Màu chữ mờ (mặc định: #cccccc)
  accentColor?: string          // Màu nút OK, clock hand, selected item (mặc định: #007AFF)
  accentTextColor?: string      // Màu chữ trên selected item (mặc định: #ffffff)
}
```

## Behaviours

1. **Clock face dial**: Hiển thị số giờ/phút/giây trên mặt đồng hồ tròn
2. **Rotating hand**: Kim đồng hồ quay chỉ vào giá trị đang chọn, với dot tròn ở đầu kim
3. **Two-step selection**: Chọn giờ → tự động chuyển sang chọn phút
4. **Editable header**: Text field HH và MM trong header cho phép nhập trực tiếp hoặc dùng arrow keys
5. **AM/PM toggle**: Chỉ hiển thị khi `use24h = false`, nằm bên phải trong header
6. **24 positions**: Khi `use24h = true`, mặt đồng hồ hiển thị 24 vị trí (0-23)
7. **Minute/clock**: Mặt đồng hồ hiển thị số phút theo bước `minuteStep`
8. **Second support**: Khi `useSeconds = true`, có thêm trường seconds trong header và mặt đồng hồ
9. **Confirm**: Click OK → emit `modelValue` dạng `'HH:MM'` hoặc `'HH:MM:SS'` (luôn ở 24h format)
10. **Cancel**: Click Huỷ hoặc backdrop → reset về `modelValue` ban đầu
11. **Transitions**: Fade-in backdrop + scale-up popup

## Usage

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { TimePicker } from '@alf/app-sdk'

const showPicker = ref(false)
const selectedTime = ref<string | null>(null)
</script>

<template>
  <div>
    <button @click="showPicker = true">Chọn giờ</button>
    <p>Đã chọn: {{ selectedTime }}</p>

    <TimePicker
      v-model="selectedTime"
      v-model:visible="showPicker"
      :minute-step="5"
    />
  </div>
</template>
```

### 12h mode

```vue
<template>
  <TimePicker
    v-model="selectedTime"
    v-model:visible="showPicker"
    :use-24h="false"
    :minute-step="15"
  />
</template>
```

### With seconds

```vue
<template>
  <TimePicker
    v-model="selectedTime"
    v-model:visible="showPicker"
    :use-seconds="true"
  />
</template>
```

### Custom theme

```vue
<template>
  <TimePicker
    v-model="selectedTime"
    v-model:visible="showPicker"
    :theme="{
      backgroundColor: '#1E1E1E',
      strongTextColor: '#FFFFFF',
      mediumTextColor: '#AAAAAA',
      weakTextColor: '#666666',
      accentColor: '#FF9500',
      accentTextColor: '#FFFFFF',
    }"
  />
</template>
```
