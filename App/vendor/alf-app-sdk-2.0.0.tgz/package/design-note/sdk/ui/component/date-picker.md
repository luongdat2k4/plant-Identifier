# DateTimePicker - Popup chọn ngày

Component popup chọn ngày (ngày/tháng/năm) với giao diện lịch hiện đại, hỗ trợ tuỳ chỉnh màu sắc và style.

## Layout

```
┌──────────────────────────────────────┐
│            Tháng 6, 2026             │  ← Header với < > navigation
├──────────────────────────────────────┤
│   T2   T3   T4   T5   T6   T7   CN  │  ← Day-of-week row
│        1    2    3    4    5    6    │
│   7    8    9   10   11   12   13    │
│  14   15   16   17   18   19   20    │
│  21   22   23   24   25   26   27    │
│  28   29   30                        │  ← Calendar grid (max 6 rows)
├──────────────────────────────────────┤
│                   [Huỷ]   [OK]       │  ← Action buttons
└──────────────────────────────────────┘

Year picker (tap vào tháng/năm):
┌──────────────────────────────────────┐
│  2020  2021  2022  2023             │
│  2024  2025  2026  2027  ← selected │
│  2028  2029  2030  2031             │
├──────────────────────────────────────┤
│                   [Huỷ]   [OK]       │
└──────────────────────────────────────┘
```

## Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `modelValue` | `Date \| null` | `null` | Selected date (v-model) |
| `visible` | `boolean` | `false` | Show/hide popup |
| `minDate` | `Date \| undefined` | - | Minimum selectable date |
| `maxDate` | `Date \| undefined` | - | Maximum selectable date |
| `locale` | `string` | `'vi'` | Locale for day/month names. `'vi'` uses Vietnamese names, others use `Intl.DateTimeFormat` |
| `theme` | `DateTimeTheme` | - | Theme customization object |
| `okText` | `string` | `'OK'` | Confirm button text |
| `cancelText` | `string` | `'Huỷ'` | Cancel button text |

## Events

| Event | Payload | Description |
|-------|---------|-------------|
| `update:modelValue` | `Date \| null` | Emitted when OK is pressed |
| `update:visible` | `boolean` | Emitted with `false` when popup should close |

## Theme interface (`DateTimeTheme`)

```typescript
interface DateTimeTheme {
  primaryColor?: string         // Màu nền ngày được chọn (default: #007AFF)
  backgroundColor?: string      // Màu nền popup (default: #ffffff)
  textColor?: string            // Màu chữ mặc định (default: #333333)
  headerTextColor?: string      // Màu chữ header tháng/năm (default: #111111)
  dayNameColor?: string         // Màu chữ thứ (T2,T3...) (default: #888888)
  todayTextColor?: string       // Màu chữ ngày hôm nay (default: #007AFF)
  disabledTextColor?: string    // Màu chữ ngày bị disable (default: #cccccc)
  selectedTextColor?: string    // Màu chữ ngày đang chọn (default: #ffffff)
  otherMonthColor?: string      // Màu chữ ngày tháng trước/sau (default: #e0e0e0)
  navColor?: string             // Màu nút < > (default: #007AFF)
  borderRadius?: string         // Border radius popup (default: 16px)
  cellSize?: string             // Kích thước ô ngày (default: 40px)
  overlayColor?: string         // Màu backdrop phía sau (default: rgba(0,0,0,0.5))
}
```

## Behaviours

1. **Month navigation**: Click `<` / `>` để chuyển tháng trước/sau
2. **Year selection**: Click vào label tháng/năm để mở year grid (12 năm), click để chọn
3. **Date selection**: Click vào ngày để chọn, click lại vào ngày đã chọn để bỏ chọn
4. **Ngày hôm nay**: Được highlight bằng màu `todayTextColor`
5. **Ngày ngoài tháng**: Hiển thị mờ màu `otherMonthColor`
6. **Disabled dates**: Ngày ngoài `minDate`/`maxDate` bị grey out, không thể chọn
7. **Confirm**: Click OK -> emit `update:modelValue` với `Date` đã chọn (hoặc `null` nếu chưa chọn)
8. **Cancel**: Click Huỷ hoặc click backdrop -> reset về `modelValue` ban đầu, emit `update:visible(false)`
9. **Transitions**: Fade-in backdrop + scale-up popup

## Usage

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { DateTimePicker } from '@alf/app-sdk'

const showPicker = ref(false)
const selectedDate = ref<Date | null>(null)
</script>

<template>
  <div>
    <button @click="showPicker = true">Chọn ngày</button>
    <p>Đã chọn: {{ selectedDate?.toLocaleDateString('vi-VN') }}</p>

    <DateTimePicker
      v-model="selectedDate"
      v-model:visible="showPicker"
      :min-date="new Date(2025, 0, 1)"
      :max-date="new Date(2027, 11, 31)"
    />
  </div>
</template>
```

### Custom theme

```vue
<template>
  <DateTimePicker
    v-model="selectedDate"
    v-model:visible="showPicker"
    :theme="{
      primaryColor: '#34C759',
      backgroundColor: '#1C1C1E',
      textColor: '#FFFFFF',
      headerTextColor: '#FFFFFF',
      dayNameColor: '#8E8E93',
      todayTextColor: '#34C759',
      disabledTextColor: '#48484A',
      selectedTextColor: '#FFFFFF',
      otherMonthColor: '#48484A',
      navColor: '#34C759',
      borderRadius: '20px',
      cellSize: '44px',
      overlayColor: 'rgba(0,0,0,0.7)',
    }"
  />
</template>
```
