# `MediaController` — Capture màn hình & Slideshow video

## Vai trò

**Chụp màn hình (capture)** một element HTML thành ảnh, và **tạo video slideshow** từ nhiều ảnh chụp. Dùng thư viện `html-to-image` và Web API `MediaRecorder`.

---

## Luồng CaptureImage

```mermaid
flowchart TD
    A["CaptureImage(options?)"] --> B["element = getElementById(elementId)<br/><i>default: 'capture-area'</i>"]
    B --> C{"Element tồn tại?"}
    C -->|No| D["THROW Error"]
    C -->|Yes| E["AWAIT document.fonts.ready"]
    E --> F["toPng(element, {<br/>  pixelRatio: max(3, devicePixelRatio),<br/>  cacheBust: true,<br/>  filter: skip ignoreAttr<br/>})"]
    F --> G["Return imageData<br/><i>base64 PNG</i>"]
```

## Luồng CreateSlideshowVideo

```mermaid
flowchart TD
    A["CreateSlideshowVideo(deps, opts)"] --> B["PHASE 1: Capture All Slides"]
    
    subgraph "PHASE 1: Capture"
        B --> B1["FOR i = 0 to totalSlides-1"]
        B1 --> B2["deps.onProgress(i+1, total)"]
        B2 --> B3["deps.setSlide(i)<br/>nextTick()<br/>waitFrames(3)"]
        B3 --> B4["Tìm element trong component"]
        B4 --> B5["Đợi fonts + images ready"]
        B5 --> B6["toJpeg(element, options)"]
        B6 --> B7["loadImageFromUrl(dataUrl)"]
        B7 --> B8["push image → images[]"]
        B8 --> B1
    end
    
    B1 -.->|"Đã capture xong"| C["PHASE 2: Encode Images to Video"]
    
    subgraph "PHASE 2: Encode"
        C --> C1["Tạo offscreen canvas (w×h)"]
        C1 --> C2["canvas.captureStream(fps)<br/>→ stream"]
        C2 --> C3["new MediaRecorder(stream, mimeType)"]
        C3 --> C4["recorder.start()"]
        C4 --> C5["Render loop:<br/>requestAnimationFrame"]
        C5 --> C6["Mỗi frame:<br/>1. Tính slide hiện tại<br/>2. Vẽ background<br/>3. Vẽ slide<br/>4. Cross-fade (nếu có)"]
        C6 --> C7{"elapsed ≥ totalDuration?"}
        C7 -->|No| C5
        C7 -->|Yes| C8["Vẽ frame cuối → recorder.stop()"]
        C8 --> C9["Blob từ chunks"]
        C9 --> C10["Return { blob, mime, ext, durationMs, w, h }"]
    end
```

## Chi tiết Render loop

```mermaid
flowchart TD
    A["renderFrame()"] --> B["elapsed = now - startTime"]
    B --> C{"elapsed ≥ totalDurationMs?"}
    C -->|Yes| D["Vẽ frame cuối"]
    D --> E["recorder.stop()"]
    C -->|No| F["slideIdx = MIN(images.length-1,<br/>FLOOR(elapsed / (secondsPerSlide × 1000)))"]
    F --> G["Vẽ background + currentImage"]
    G --> H{"fadeMs > 0<br/>AND còn slide tiếp?"}
    H -->|Yes| I["Tính alpha = min(1, (elapsed - fadeStart) / fadeMs)"]
    I --> J["Vẽ nextImage với globalAlpha = alpha"]
    H -->|No| K["requestAnimationFrame(renderFrame)"]
    J --> K
```

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `CaptureImage(options?)` | `CaptureOptions` | `Promise<string>` | Chụp element HTML → base64 PNG |
| `CreateSlideshowVideo(deps, opts)` | `SlideshowDeps`, `SlideshowOptions` | `Promise<VideoResult>` | Tạo video từ nhiều slide với cross-fade |

### Parameters

| Tham số | Field | Mô tả |
|---|---|---|
| `CaptureOptions` | `elementId`, `pixelRatio`, `ignoreAttr` | Element cần chụp, độ phân giải, attribute bỏ qua |
| `SlideshowDeps` | `captureRef`, `setSlide(i)`, `onProgress(i,total)` | Ref Vue component, hàm set nội dung, callback progress |
| `SlideshowOptions` | `totalSlides`, `fps`, `secondsPerSlide`, `fadeMs`, `width`, `height` | Số slide, fps, thời gian mỗi slide, cross-fade, kích thước |
| `VideoResult` | `blob`, `mime`, `ext`, `durationMs`, `width`, `height` | Blob video + metadata |

## Dependencies

- Output thường chuyển sang **ShareController**: `this.af.Share.ShareImage()`
- Có thể gọi **PermissionController**: kiểm tra quyền lưu trữ trước khi ghi video
