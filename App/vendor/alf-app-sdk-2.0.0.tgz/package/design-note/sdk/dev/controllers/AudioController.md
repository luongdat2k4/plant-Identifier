# `AudioController` — Phát âm thanh & Live Audio Instance

**Scope:** Quản lý phát âm thanh từ thư mục device, hỗ trợ one-shot và loop, điều khiển tốc độ và âm lượng.

**Access:** `ALF.Instance.Audio`

**Live Instance:** `ALF.Instance.Audio.CreateLiveAudioInstance()` → `LiveAudioInstance`

---

## 1. Mục đích

`AudioController` cung cấp hệ thống âm thanh tập trung cho phép:

- Load file âm thanh từ thư mục device (mặc định `public/audio/`)
- Tạo các `LiveAudioInstance` để phát âm thanh
- Hỗ trợ **one-shot** (phát 1 lần rồi tự giải phóng) và **loop** (phát vô hạn)
- Điều khiển phát/tạm dừng/dừng từng instance riêng lẻ
- Thay đổi tốc độ phát (speed/pitch)
- Thay đổi âm lượng
- Quản lý nhiều instance cùng lúc (StopAll, PauseAll, ResumeAll)

---

## 2. Cấu hình

Audio được cấu hình trong `keys.audio` của app Config:

```json
{
  "keys": {
    "audio": {
      "enable": true,
      "deviceAudioFolder": "audio",
      "defaultVolume": 1.0
    }
  }
}
```

| Field | Type | Default | Mô tả |
|---|---|---|---|
| `enable` | `boolean` | — | Bật/tắt hệ thống audio |
| `deviceAudioFolder` | `string` | `"audio"` | Thư mục chứa file âm thanh (relative to public/asset) |
| `defaultVolume` | `number` | `1.0` | Âm lượng mặc định (0.0 – 1.0) |

---

## 3. API

### 3.1. Tạo & phát âm thanh

```typescript
// One-shot — phát 1 lần
const sfx = ALF.Instance.Audio.CreateLiveAudioInstance('sfx/click.mp3')
sfx.Start()

// Loop — phát vô hạn
const bgm = ALF.Instance.Audio.CreateLiveAudioInstance('music/bg.mp3', { mode: 'loop' })
bgm.Start()
```

### 3.2. Điều khiển instance

```typescript
const music = ALF.Instance.Audio.CreateLiveAudioInstance('music/bg.mp3', { mode: 'loop' })

music.Start()       // Bắt đầu phát từ đầu
music.Pause()       // Tạm dừng
music.Play()        // Tiếp tục từ vị trí đã dừng
music.Stop()        // Dừng hẳn (về đầu)
```

### 3.3. Speed manipulation

```typescript
music.SetSpeed(1.5)        // Set speed = 1.5x
music.IncreaseSpeed(0.5)   // 1.5 → 2.0
music.DecreaseSpeed(0.3)   // 2.0 → 1.7

const currentSpeed = music.getSpeed()  // 1.7
```

### 3.4. Volume control

```typescript
music.SetVolume(0.5)        // Set volume 50%
const vol = music.getVolume()  // 0.5
```

### 3.5. State queries

```typescript
music.getState()       // 'idle' | 'playing' | 'paused' | 'stopped' | 'finished'
music.isPlaying()      // boolean
music.isPaused()       // boolean
music.isStopped()      // boolean
music.getMode()        // 'oneshot' | 'loop'

const snapshot = music.getSnapshot()
// { id, source, state, mode, volume, speed, currentTime, duration }

// Đợi cho đến khi phát xong (oneshot)
await music.onFinished()
```

### 3.6. Events

```typescript
music.on('statechange', (event) => {
  console.log('State:', event.state)
})

music.on('finish', (event) => {
  console.log('Finished:', event.source)
})

music.on('error', (event) => {
  console.error('Audio error:', event.error)
})

music.off('statechange', handler)
```

### 3.7. Quản lý hàng loạt

```typescript
// Dừng tất cả instance đang phát
await ALF.Instance.Audio.StopAll()

// Tạm dừng tất cả
await ALF.Instance.Audio.PauseAll()

// Tiếp tục tất cả
await ALF.Instance.Audio.ResumeAll()

// Set volume cho tất cả instance
ALF.Instance.Audio.SetMasterVolume(0.7)

// Lấy danh sách instance
const all = ALF.Instance.Audio.getAllInstances()
const active = ALF.Instance.Audio.getActiveInstances()

// Giải phóng instance
await ALF.Instance.Audio.DisposeInstance(music)
```

---

## 4. Usage examples

### 4.1. Sound effect (one-shot)

```typescript
function playClick() {
  const sfx = ALF.Instance.Audio.CreateLiveAudioInstance('sfx/click.mp3')
  sfx.Start()
}
```

### 4.2. Background music với speed control

```typescript
const bgm = ALF.Instance.Audio.CreateLiveAudioInstance('music/bg.mp3', {
  mode: 'loop',
  volume: 0.5,
})

bgm.Start()

// Tăng tốc khi đạt high score
function onScoreMilestone() {
  bgm.IncreaseSpeed(0.2)
}

// Giảm tốc khi về menu
function onPause() {
  bgm.DecreaseSpeed(0.3)
}

function onQuit() {
  bgm.Stop()
  ALF.Instance.Audio.DisposeInstance(bgm)
}
```

### 4.3. Đợi âm thanh phát xong

```typescript
async function playSequence() {
  const intro = ALF.Instance.Audio.CreateLiveAudioInstance('sfx/intro.mp3')
  intro.Start()
  await intro.onFinished()  // đợi intro kết thúc

  const main = ALF.Instance.Audio.CreateLiveAudioInstance('music/main.mp3', { mode: 'loop' })
  main.Start()
}
```

### 4.4. Tắt tiếng toàn bộ game

```typescript
function toggleMute() {
  const vol = isMuted ? 0 : 1
  ALF.Instance.Audio.SetMasterVolume(vol)
  isMuted = !isMuted
}
```

---

## 5. Thư mục âm thanh (device)

Mặc định, audio files được đặt trong thư mục `public/audio/` (web) hoặc `resources/src/asset/audio/` (native):

```
public/
└── audio/
    ├── sfx/
    │   ├── click.mp3
    │   ├── coin.mp3
    │   └── levelup.mp3
    └── music/
        ├── bg_main.mp3
        └── bg_menu.mp3
```

Cấu hình thư mục qua `keys.audio.deviceAudioFolder`.

---

## 6. Dependencies

- Không có native plugin — sử dụng **HTML5 Audio API** cho tất cả nền tảng
- Capacitor WebView hỗ trợ HTML5 Audio đầy đủ trên cả Android và iOS

---

## 7. Lưu ý

- Audio files nên dùng định dạng `.mp3` hoặc `.ogg` (tương thích đa nền tảng)
- One-shot instances tự động cleanup sau khi phát xong
- Loop instances cần được gọi `Stop()` và `DisposeInstance()` thủ công
- Speed range hợp lệ: `0.25` – `4.0`
- Trên web, browser có thể yêu cầu user gesture trước khi phát audio (autoplay policy). Xử lý bằng cách gọi `Start()` trong event handler của user (click/touch)
- `IncreaseSpeed`/`DecreaseSpeed` sử dụng delta, không phải target — tiện cho game loop
