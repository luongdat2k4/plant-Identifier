# `AppDataController` — Dữ liệu App

## Vai trò

Quản lý dữ liệu **persist** của ứng dụng — các lựa chọn của người dùng cần ghi nhớ giữa các lần mở app (ngôn ngữ, trạng thái onboarding, ...).

Dữ liệu được lưu dưới dạng **JSON file** (`app-data.json`) trong **Capacitor Filesystem** (`Directory.Data`).

---

## Cấu trúc dữ liệu

```typescript
interface AppPersistedData {
  /** Ngôn ngữ người dùng đã chọn (ví dụ: 'vi', 'en') */
  locale: string | null
  /** Đã chọn ngôn ngữ lần đầu qua màn ChooseLanguage? */
  languageChosen: boolean
  /** Đã xem hết màn Onboarding? */
  onboardingCompleted: boolean
}
```

Giá trị mặc định khi chưa có file:

```json
{
  "locale": null,
  "languageChosen": false,
  "onboardingCompleted": false
}
```

---

## Luồng Init

```mermaid
flowchart TD
    A["init()"] --> B["No-op (load lazy)"]
```

Controller **không** tự động load dữ liệu khi init. Việc load xảy ra khi `load()` được gọi lần đầu (từ `main.ts` trong boot sequence).

---

## Luồng Load

```mermaid
flowchart TD
    A["load()"] --> B{"cached?"}
    B -->|Yes| C["Return cached"]
    B -->|No| D["TRY: Filesystem.readFile<br/>app-data.json"]
    D --> E{"File tồn tại?"}
    E -->|Yes| F["Parse JSON → merge DEFAULT<br/>→ cache → return"]
    E -->|No| G["Dùng DEFAULT_DATA<br/>→ cache → return"]
```

---

## Luồng Save

```mermaid
flowchart LR
    A["save(data)"] --> B["this.cached = data"]
    B --> C["Filesystem.writeFile<br/>app-data.json"]
```

---

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init()` | — | `Promise<void>` | No-op. Dữ liệu load lazy. |
| `load()` | — | `Promise<AppPersistedData>` | Đọc dữ liệu từ thiết bị (có cache). |
| `save(data)` | `AppPersistedData` | `Promise<void>` | Ghi toàn bộ dữ liệu xuống thiết bị. |
| `setLocale(locale)` | string | `Promise<void>` | Lưu locale + đánh dấu `languageChosen = true`. |
| `completeOnboarding()` | — | `Promise<void>` | Đánh dấu `onboardingCompleted = true`. |
| `resetAll()` | — | `Promise<void>` | Xoá file dữ liệu, reset về mặc định. |

---

## Luồng Boot

```mermaid
sequenceDiagram
    participant main as main.ts
    participant Data as AppDataController
    participant Router as Vue Router

    main->>Data: load()
    Data-->>main: AppPersistedData

    alt languageChosen === true && locale
        main->>main: Restore locale vào i18n
    end

    alt onboardingCompleted === true
        main->>Router: Skip onboarding → HOME
    else
        main->>Router: Navigate → ONBOARDING
    end
```

---

## Dependencies

- **Capacitor Filesystem** — đọc/ghi file `app-data.json` vào `Directory.Data`
- Không gọi controller nào khác

## Các controller/view gọi AppDataController

| Module | Mục đích |
|---|---|
| `main.ts` | `load()` để quyết định skip screen nào |
| `ChooseLanguageView.vue` | `setLocale()` khi user chọn ngôn ngữ |
| `OnboardingView.vue` | `completeOnboarding()` khi user next hết hoặc skip |
| `HomeView.vue` | `setLocale()` khi đổi ngôn ngữ, `resetAll()` khi reset data |

## Lưu ý

- File lưu ở `Directory.Data`: Android `/data/data/<app>/files/`, iOS `Library/Application Support/`
- Dữ liệu JSON plaintext, không mã hoá
- Dùng cơ chế cache: chỉ đọc từ disk 1 lần, các lần sau dùng `this.cached`
- `resetAll()` xoá file để đảm bảo lần `load()` tiếp theo dùng defaults
