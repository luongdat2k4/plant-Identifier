# `StorageController` — Lưu trữ local

## Vai trò

Quản lý dữ liệu local dưới dạng **JSON database** lưu trong **Capacitor Filesystem** (`Directory.Data`). Hoạt động như document database đơn giản: table, select, insert, update, delete.

---

## Luồng Init

```mermaid
flowchart TD
    A["init()"] --> B["TRY: Filesystem.readFile({ path: 'appdb.json', directory: DATA })"]
    B --> C{"File tồn tại?"}
    C -->|Yes| D["this.db = JSON.parse(result.data)"]
    C -->|No| E["this.db = getDefaultSchema()<br/>(object rỗng)"]
    E --> F["saveToDisk()<br/>Filesystem.writeFile"]
```

## Luồng CRUD

```mermaid
flowchart TD
    subgraph "CreateTable"
        CT["CreateTable(tableName)"] --> CT1{"db[tableName] exists?"}
        CT1 -->|No| CT2["db[tableName] = []"]
        CT2 --> CT3["saveToDisk()"]
    end
    
    subgraph "Select"
        SL["Select(tableName, filter?)"] --> SL1{"db[tableName] exists?"}
        SL1 -->|No| SL2["Return []"]
        SL1 -->|Yes| SL3{"filter?"}
        SL3 -->|No| SL4["Return all rows"]
        SL3 -->|Yes| SL5["Filter rows match all key-value"]
        SL5 --> SL6["Return filtered rows"]
    end
    
    subgraph "Insert"
        IN["Insert(tableName, record)"] --> IN1{"db[tableName] exists?"}
        IN1 -->|No| IN2["db[tableName] = []"]
        IN2 --> IN3{"record.id?"}
        IN1 -->|Yes| IN3
        IN3 -->|No| IN4["record.id = generateUUID()"]
        IN4 --> IN5["db[tableName].push(record)"]
        IN3 -->|Yes| IN5
        IN5 --> IN6["saveToDisk()"]
    end
    
    subgraph "Update"
        UP["Update(tableName, filter, updateData)"] --> UP1{"db[tableName] exists?"}
        UP1 -->|No| UP2["Return"]
        UP1 -->|Yes| UP3["Map rows:<br/>match filter → merge updateData<br/>else → giữ nguyên"]
        UP3 --> UP4["saveToDisk()"]
    end
    
    subgraph "Delete"
        DL["Delete(tableName, filter)"] --> DL1{"db[tableName] exists?"}
        DL1 -->|No| DL2["Return"]
        DL1 -->|Yes| DL3["Filter rows:<br/>giữ row NOT match filter"]
        DL3 --> DL4["saveToDisk()"]
    end
```

## Luồng SaveToDisk

```mermaid
flowchart LR
    A["saveToDisk()"] --> B["Filesystem.writeFile({<br/>  path: 'appdb.json',<br/>  directory: DATA,<br/>  data: JSON.stringify(db)<br/>})"]
```

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init()` | — | `Promise<void>` | Đọc database từ disk, nếu chưa có thì tạo mới |
| `CreateTable(tableName)` | string | `Promise<void>` | Tạo table mới (array rỗng) |
| `Select(tableName, filter?)` | string, object | `Promise<Array>` | Lấy dữ liệu, có thể filter theo key-value |
| `Insert(tableName, record)` | string, any | `Promise<void>` | Thêm record. Tự sinh UUID nếu thiếu id |
| `Update(tableName, filter, data)` | string, object, object | `Promise<void>` | Cập nhật các row match filter |
| `Delete(tableName, filter)` | string, object | `Promise<void>` | Xoá các row match filter |

## Dependencies

- Không gọi controller nào khác
- Các controller khác (AdController, ShareController) có thể gọi `ALF.Storage` để lưu config

## Lưu ý

- Không dùng cho dữ liệu lớn — toàn bộ DB load vào memory
- File lưu ở `Directory.Data`: Android `/data/data/<app>/files/`, iOS `Library/Application Support/`
- Không mã hoá — dữ liệu JSON plaintext
