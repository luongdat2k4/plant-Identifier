# `FileController` — Pick/Browse file (ảnh, video, file bất kỳ)

**Scope:** Tập trung tất cả luồng lấy file từ thiết bị — gallery ảnh/video (mobile), browse từ máy tính (desktop/web).

**Access:** `ALF.Instance.File`

**Migration:** Chức năng `PickFromGallery` đã được chuyển từ `CameraController` sang `FileController`.

---

## 1. Vai trò

`FileController` là đầu mối duy nhất để lấy file từ bên ngoài app:

| Nền tảng | Cơ chế | API |
|---|---|---|
| **Android / iOS** | Capacitor Camera plugin (`source: PHOTOS`) | `PickFromGallery()` |
| **Web / Desktop** | `<input type="file">` | `Browse()`, `PickFromGallery()` (tự động fallback) |

---

## 2. API

### 2.1. PickFromGallery — Lấy ảnh/video từ gallery mobile

```typescript
// Pick 1 ảnh từ gallery
const photo = await ALF.Instance.File.PickFromGallery()
// => FileResult { data, name, mime, size, uri? }

// Pick 1 video
const video = await ALF.Instance.File.PickFromGallery({ mediaType: 'video' })

// Pick nhiều ảnh
const photos = await ALF.Instance.File.PickFromGallery({ multiple: true })
// => FileResultList { files: FileResult[] }
```

**Options:**

| Field | Type | Default | Mô tả |
|---|---|---|---|
| `quality` | `number` | `90` | Chất lượng nén ảnh (1-100) |
| `width` | `number` | `1920` | Chiều rộng tối đa (ảnh) |
| `mediaType` | `'image' \| 'video' \| 'all'` | `'image'` | Loại media cần pick |
| `multiple` | `boolean` | `false` | Cho phép chọn nhiều |

> **Lưu ý:** Trên native, Capacitor Camera plugin chỉ hỗ trợ pick 1 ảnh. `multiple` và `video` sẽ tự động fallback sang web file input.

### 2.2. Browse — Mở hộp thoại chọn file (desktop/web)

```typescript
// Browse file bất kỳ
const file = await ALF.Instance.File.Browse()

// Browse ảnh
const photo = await ALF.Instance.File.BrowseImage()
// tương đương Browse({ accept: 'image/*' })

// Browse video
const video = await ALF.Instance.File.BrowseVideo()
// tương đương Browse({ accept: 'video/*' })

// Browse tất cả file
const anyFile = await ALF.Instance.File.BrowseAll()

// Chọn nhiều ảnh
const photos = await ALF.Instance.File.BrowseImage({ multiple: true })
// => FileResultList
```

**Options:**

| Field | Type | Default | Mô tả |
|---|---|---|---|
| `accept` | `string` | `'*/*'` | MIME accept string (vd: `'image/*,video/*'`) |
| `multiple` | `boolean` | `false` | Cho phép chọn nhiều file |
| `capture` | `'camera' \| 'camcorder'` | — | Capture trực tiếp từ camera (mobile) |

### 2.3. FileResult — Kết quả trả về

```typescript
interface FileResult {
  data: string       // Base64 data (ảnh: không prefix, khác: data URL đầy đủ)
  name: string       // Tên file (vd: "photo_123456789.jpg")
  mime: string       // MIME type (vd: "image/jpeg")
  size: number       // Dung lượng bytes
  uri?: string       // Native URI (chỉ có trên mobile)
}

// Khi chọn nhiều file:
interface FileResultList {
  files: FileResult[]
}
```

---

## 3. Usage examples

### 3.1. Chụp ảnh → pick từ gallery → share

```typescript
// Chụp ảnh bằng camera
const photoBase64 = await ALF.Instance.Camera.Take()

// Hoặc pick từ gallery
const photo = await ALF.Instance.File.PickFromGallery()

// Share ảnh
await ALF.Instance.Share.ShareImage(photo.data)
```

### 3.2. Upload ảnh từ máy tính

```typescript
async function uploadPhoto() {
  const result = await ALF.Instance.File.BrowseImage()
  // result.data là base64 data URL, gửi lên server
  await fetch('/upload', {
    method: 'POST',
    body: JSON.stringify({
      image: result.data,
      name: result.name,
    }),
    headers: { 'Content-Type': 'application/json' },
  })
}
```

### 3.3. Pick video từ gallery

```typescript
const video = await ALF.Instance.File.PickFromGallery({ mediaType: 'video' })
// Trên native sẽ fallback sang web input (Capacitor Camera ko hỗ trợ video picker)
```

---

## 4. So sánh CameraController vs FileController

| Chức năng | CameraController | FileController |
|---|---|---|
| Chụp ảnh (camera) | `Take()` | — |
| Live preview camera | `startLivePreview()` | — |
| Pick ảnh từ gallery | ❌ (đã xoá) | `PickFromGallery()` |
| Pick video từ gallery | — | `PickFromGallery({ mediaType: 'video' })` |
| Browse file từ máy tính | — | `Browse()`, `BrowseImage()`, `BrowseVideo()` |

---

## 5. Lưu ý

- `PickFromGallery()` trên native chỉ hỗ trợ pick 1 ảnh. Nếu cần pick video hoặc multiple, dùng `Browse()` với accept tương ứng (hệ thống sẽ fallback sang `<input type="file">`).
- Trên iOS, Capacitor Camera plugin yêu cầu quyền truy cập photo library (tự động xin khi gọi lần đầu).
- File result trả về dạng base64 để dễ dàng xử lý (hiển thị, upload, lưu trữ).
- `BrowseImage()`, `BrowseVideo()`, `BrowseAll()` là các shortcut cho `Browse()` với accept string tương ứng.
