# `LocalizationController` — Đa ngôn ngữ (I18n)

## Vai trò

Quản lý đa ngôn ngữ cho toàn bộ framework và ứng dụng sử dụng Vue I18n. Cung cấp API để khởi tạo, chuyển đổi locale runtime, và lấy danh sách ngôn ngữ hỗ trợ.

Hoạt động như wrapper của **vue-i18n**, accessible qua `ALF.Instance.Localization`.

---

## Kiến trúc

```
LocalizationController
  └── i18n/index.ts (core)
        ├── createAppI18n() — tạo vue-i18n instance
        ├── getI18n()      — lấy instance
        ├── setLocale()    — đổi locale runtime
        ├── getCurrentLocale()
        └── SUPPORTED_LOCALES — mảng locale + label + flag URL
```

Các file `.json` locale được import static để Vite bundle chung:

```
src/alf/i18n/
├── index.ts
├── en.json           # English
├── vi.json           # Tiếng Việt
├── ja.json           # 日本語
├── ko.json           # 한국어
├── zh.json           # 中文
├── th.json           # ไทย
├── es.json           # Español
├── pt.json           # Português
├── fr.json           # Français
├── de.json           # Deutsch
├── it.json           # Italiano
├── hi.json           # हिन्दी
├── bn.json           # বাংলা
├── id.json           # Bahasa Indonesia
├── ru.json           # Русский
├── tr.json           # Türkçe
├── ar-eg.json        # العربية (مصر)
└── pcm.json          # Naija Pidgin
```

---

## Luồng Init

```mermaid
sequenceDiagram
    participant main as main.ts
    participant ALF as ALF.Instance
    participant LC as LocalizationController
    participant i18n as vue-i18n

    main->>ALF: initControllers()
    ALF->>LC: constructor(alf)
    LC-->>ALF: LocalizationController instance

    main->>LC: init('vi')
    LC->>i18n: createAppI18n('vi')
    i18n-->>LC: I18n instance
    LC->>LC: this.i18n = instance

    main->>LC: getI18n()
    LC-->>main: I18n instance
    main->>main: app.use(i18n)
```

---

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init(defaultLocale)` | `SupportedLocale` | `void` | Khởi tạo vue-i18n với locale mặc định |
| `getI18n()` | — | `I18n` | Lấy vue-i18n instance để `app.use()` |
| `setLocale(locale)` | `SupportedLocale` | `void` | Đổi ngôn ngữ runtime |
| `getCurrentLocale()` | — | `SupportedLocale` | Lấy locale hiện tại |
| `supportedLocales` | (getter) | `SUPPORTED_LOCALES` | Danh sách locale hỗ trợ + label + flag |

---

## SupportedLocale type

```typescript
type SupportedLocale =
  | 'vi' | 'en' | 'ja' | 'ko' | 'zh' | 'th'
  | 'es' | 'pt' | 'fr' | 'de' | 'it'
  | 'hi' | 'bn' | 'id' | 'ru' | 'tr'
  | 'ar-eg' | 'pcm'
```

---

## Danh sách locale

```typescript
SUPPORTED_LOCALES = [
  { code: 'vi',   label: 'Tiếng Việt',     flag: 'https://flagcdn.com/28x21/vn.png' },
  { code: 'en',   label: 'English',         flag: 'https://flagcdn.com/28x21/us.png' },
  { code: 'ja',   label: '日本語',           flag: 'https://flagcdn.com/28x21/jp.png' },
  { code: 'ko',   label: '한국어',           flag: 'https://flagcdn.com/28x21/kr.png' },
  { code: 'zh',   label: '中文',             flag: 'https://flagcdn.com/28x21/cn.png' },
  { code: 'th',   label: 'ไทย',             flag: 'https://flagcdn.com/28x21/th.png' },
  { code: 'es',   label: 'Español',         flag: 'https://flagcdn.com/28x21/es.png' },
  { code: 'pt',   label: 'Português',       flag: 'https://flagcdn.com/28x21/br.png' },
  { code: 'fr',   label: 'Français',        flag: 'https://flagcdn.com/28x21/fr.png' },
  { code: 'de',   label: 'Deutsch',         flag: 'https://flagcdn.com/28x21/de.png' },
  { code: 'it',   label: 'Italiano',        flag: 'https://flagcdn.com/28x21/it.png' },
  { code: 'hi',   label: 'हिन्दी',            flag: 'https://flagcdn.com/28x21/in.png' },
  { code: 'bn',   label: 'বাংলা',            flag: 'https://flagcdn.com/28x21/bd.png' },
  { code: 'id',   label: 'Bahasa Indonesia', flag: 'https://flagcdn.com/28x21/id.png' },
  { code: 'ru',   label: 'Русский',         flag: 'https://flagcdn.com/28x21/ru.png' },
  { code: 'tr',   label: 'Türkçe',          flag: 'https://flagcdn.com/28x21/tr.png' },
  { code: 'ar-eg', label: 'العربية (مصر)',    flag: 'https://flagcdn.com/28x21/eg.png' },
  { code: 'pcm',  label: 'Naija Pidgin',     flag: 'https://flagcdn.com/28x21/ng.png' },
]
```

---

## Cấu trúc locale JSON

Mỗi file `.json` chứa các key phân cấp, tương ứng với từng màn hình:

```json
{
  "app":       { "name": "..." },
  "language":  { "title": "...", "subtitle": "...", "confirm": "..." },
  "onboarding": {
    "skip": "...",
    "next": "...",
    "start": "...",
    "steps": [
      { "title": "...", "description": "..." }
    ]
  },
  "home":      { "title": "...", "subtitle": "...", "sdk_title": "...", "settings": "...", "gameplay": "..." },
  "settings":  { "title": "...", "general": "...", "sound": "...", "volume": "...", "other": "...", "game_mode": "...", "version": "...", "language": "..." },
  "gameplay":  { "title": "...", "back": "...", "tap_hint": "...", "finished": "...", "score": "...", "play_again": "...", "start": "..." }
}
```

---

## Dependencies

- **vue-i18n** — core localization engine
- **vue** (peer dependency) — Composition API (`useI18n()`)
- Không gọi controller nào khác

## Các controller/view gọi LocalizationController

| Module | Mục đích |
|---|---|
| `main.ts` | `init()`, `getI18n()` để `app.use()` |
| `ChooseLanguageView.vue` | `setLocale()` để xem trước khi confirm |
| `HomeView.vue` | `getCurrentLocale()`, `setLocale()` khi đổi ngôn ngữ |
| `OnboardingView.vue` | Dùng `useI18n()` cho text skip/next/start |

## Lưu ý

- `init()` phải được gọi **trước** `getI18n()` — nếu không sẽ throw error
- `createAppI18n()` chỉ tạo instance **1 lần** (singleton pattern trong module)
- `supportedLocales` là getter, trả về `SUPPORTED_LOCALES` từ `i18n/index.ts`
- Để thêm locale mới: tạo file `.json` → import trong `i18n/index.ts` → thêm vào `SUPPORTED_LOCALES` + `messages`
