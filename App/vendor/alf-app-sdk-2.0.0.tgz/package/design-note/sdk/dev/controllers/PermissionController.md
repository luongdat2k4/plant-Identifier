# `PermissionController` — Cấp quyền thiết bị

## Vai trò

Quản lý việc xin và kiểm tra các quyền trên thiết bị (camera, microphone, photo library, notifications, tracking...). Dùng **Capacitor Permission plugin**.

Đây là controller mà các controller khác (Camera, Media, ...) gọi đến trước khi thực hiện tác vụ cần quyền.

---

## Luồng RequestPermission

```mermaid
flowchart TD
    A["RequestPermission(permissionType)"] --> B{"Cache có kết quả?"}
    B -->|Yes| C["Return cached status"]
    B -->|No| D["Capacitor.Plugins.Permissions.query({ name: type })"]
    
    D --> E{"Status === 'granted'?"}
    E -->|Yes| F["Lưu cache"]
    E -->|No| G["Capacitor.Plugins.Permissions.request({ name: type })"]
    G --> H["status = result"]
    H --> F
    
    F --> I["Return status"]
```

## Luồng CheckPermission (chỉ kiểm tra, không xin)

```mermaid
flowchart LR
    A["CheckPermission(type)"] --> B["Permissions.query({ name: type })"]
    B --> C["Return status"]
```

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `RequestPermission(type)` | `PermissionType` | `Promise<PermissionStatus>` | Xin quyền. Nếu đã có thì trả về ngay (cache). |
| `CheckPermission(type)` | `PermissionType` | `Promise<PermissionStatus>` | Chỉ kiểm tra, không xin quyền. |
| `RequestTracking()` | — | `Promise<PermissionStatus>` | Shortcut: `RequestPermission('tracking')` — iOS ATT. |
| `HasPermission(type)` | `PermissionType` | `Promise<boolean>` | Shortcut: `CheckPermission(type) === 'granted'`. |
| `ClearCache()` | — | `void` | Xoá cache để xin lại quyền. |

## Các loại quyền

```mermaid
flowchart TD
    A["PermissionType"] --> B["camera<br/>← CameraController, MediaController"]
    A --> C["photos<br/>← CameraController (PickFromGallery)"]
    A --> D["microphone<br/>← MediaController"]
    A --> E["notifications<br/>(dùng riêng)"]
    A --> F["tracking<br/>← AdController trước khi init"]
    A --> G["storage<br/>← StorageController (Android)"]
```

## Cách dùng

```mermaid
flowchart LR
    A["CameraController"] --> B["this.af.Permission.RequestPermission('camera')"]
    B --> C{"granted?"}
    C -->|Yes| D["Chụp ảnh"]
    C -->|No| E["Báo lỗi"]
    
    F["Bất kỳ đâu"] --> G["ALF.Permission.RequestTracking()<br/><i>iOS ATT</i>"]
    F --> H["ALF.Permission.HasPermission('camera')<br/><i>kiểm tra nhanh</i>"]
```

## Lưu ý

- **iOS Tracking (ATT)**: Trên iOS 14+, `RequestTracking()` phải gọi trước `AdController.init()`, nếu không app sẽ bị Apple từ chối.
- **Cache**: Kết quả được cache trong session để tránh popup liên tục. Gọi `ClearCache()` nếu cần xin lại.
