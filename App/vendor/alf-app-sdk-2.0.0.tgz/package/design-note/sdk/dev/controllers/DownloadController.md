# `DownloadController` — Tải file về thiết bị / bộ nhớ app

**Scope:** Tải file từ URL về 2 đích: thư mục Download của hệ thống, hoặc bộ nhớ riêng của app (dùng cho nội dung nặng như model AI).

**Access:** `ALF.Instance.Download`

**Native plugin:** `ALFDownload` (`sdk/plugins/download/`) — package `@alf/download-plugin`.

---

## 1. Vai trò

`DownloadController` là đầu mối duy nhất để tải file về thiết bị:

| Hàm | Đích lưu | Dùng khi nào |
|---|---|---|
| `DownloadToDevice(url, targetPath)` | Thư mục **Download** của hệ thống | Người dùng muốn giữ file (báo cáo, APK, media...) |
| `DownloadToApp(url, relativePath)` | **Bộ nhớ riêng của app** | Nội dung nặng cần tải khi mở app (model AI) để APK/IPA nhẹ |

**Bảng ánh xạ storage theo nền tảng:**

| Nền tảng | `DownloadToDevice` | `DownloadToApp` |
|---|---|---|
| Android 10+ | `MediaStore.Downloads` (không cần quyền) | `getFilesDir()` (khớp `Directory.Data` của `@capacitor/filesystem`) |
| Android ≤9 | Thư mục Download công khai (tự xin `WRITE_EXTERNAL_STORAGE`) | `getFilesDir()` |
| iOS | `Documents/` (hiển thị trong Files app nếu bật `UIFileSharingEnabled`) | `Application Support/` |
| Web | Tải qua trình duyệt (anchor download) | ❌ Không hỗ trợ |

---

## 2. API

### 2.1. DownloadToDevice — Tải về thư mục Download hệ thống

```typescript
// targetPath là relative path trong thư mục Download, tự tạo thư mục con
const path = await ALF.Instance.Download.DownloadToDevice(
  'https://c1.alf.vn/picast/picast_wtool_win64_1.0.0.tar.br',
  'picast/picast_wtool_win64_1.0.0.tar.br',
)
// Android 10+ => "Download/picast/picast_wtool_win64_1.0.0.tar.br"
// Android ≤9   => "/storage/emulated/0/Download/picast/..."
// iOS          => "<app>/Documents/picast/picast_wtool_win64_1.0.0.tar.br"
```

**Tham số:**

| Field | Type | Bắt buộc | Mô tả |
|---|---|---|---|
| `url` | `string` | ✅ | HTTP/HTTPS url cần tải |
| `targetPath` | `string` | ✅ | Relative path trong thư mục Download (vd `"models/a.bin"`). Phải kết thúc bằng tên file. |

**Trả về:** `Promise<string>` — absolute path của file đã lưu.

### 2.2. DownloadToApp — Tải về bộ nhớ riêng của app

```typescript
// relativePath là relative path trong bộ nhớ app, tự tạo thư mục con
const modelPath = await ALF.Instance.Download.DownloadToApp(
  'https://c1.alf.vn/picast/picast_wtool_win64_1.0.0.tar.br',
  'models/picast.bin',
)
// Android => "/data/user/0/<package>/files/models/picast.bin"
// iOS     => "<app>/Library/Application Support/models/picast.bin"
```

**Tham số:**

| Field | Type | Bắt buộc | Mô tả |
|---|---|---|---|
| `url` | `string` | ✅ | HTTP/HTTPS url cần tải |
| `relativePath` | `string` | ✅ | Relative path trong bộ nhớ app (vd `"models/llama.bin"`) |

**Trả về:** `Promise<string>` — absolute path, dùng để native code (AI loader) đọc file trực tiếp.

### 2.3. IsDownloaded — Kiểm tra file đã tải chưa

```typescript
if (!(await ALF.Instance.Download.IsDownloaded('models/picast.bin'))) {
  await ALF.Instance.Download.DownloadToApp(url, 'models/picast.bin')
}
```

### 2.4. GetAppPath — Absolute path đã resolve

```typescript
// Chỉ có sau khi DownloadToApp thành công (cache trong controller)
const path = ALF.Instance.Download.GetAppPath('models/picast.bin')
```

### 2.5. SetOnDownloadProgress — Theo dõi tiến trình tải

```typescript
const unsub = ALF.Instance.Download.SetOnDownloadProgress((e) => {
  console.log(`${Math.round(e.progress * 100)}% — ${e.receivedBytes}/${e.totalBytes}`)
})
// ... sau khi tải xong
unsub()
```

**Event payload:**

```typescript
interface DownloadProgressEvent {
  url: string          // url đang tải
  receivedBytes: number // số byte đã nhận
  totalBytes: number    // tổng byte (0 nếu server không gửi Content-Length)
  progress: number      // 0..1
}
```

---

## 3. Kiến trúc

### 3.1. Tại sao là native plugin, không dùng `fetch` + `@capacitor/filesystem`

Model AI thường vài trăm MB. Đường `fetch → base64 → Filesystem.writeFile` tốn gấp ~1.33x RAM (base64), rất chậm và dễ OOM trên mobile. Plugin native **stream trực tiếp HTTP xuống disk**:

```
[TS] DownloadController ──(Capacitor bridge, chỉ 1 call)──▶ [Native]
                                                    ┌──────────────────────────────┐
                                                    │ HttpURLConnection (Android)  │
                                                    │ URLSession.downloadTask (iOS)│
                                                    │   └─▶ write stream ──▶ file  │
                                                    └──────────────────────────────┘
        progress: notifyListeners("OnDownloadProgress") ──▶ controller ──▶ handlers
```

### 3.2. Cấu trúc thư mục plugin

```
sdk/plugins/download/
├── package.json            # @alf/download-plugin, khai báo android/ios src
├── index.ts                # re-export src
├── Package.swift           # iOS SPM target
├── src/
│   ├── definitions.ts      # Types + ALFDownloadPlugin interface
│   ├── index.ts            # registerPlugin<ALFDownloadPlugin>('ALFDownload')
│   └── web.ts              # Web impl (browser download / không hỗ trợ app)
├── android/
│   ├── build.gradle        # namespace com.alf.download, chỉ cần capacitor-android
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml  # INTERNET + WRITE_EXTERNAL_STORAGE (maxSdk 28)
│       └── java/alf/download/ALFDownloadPlugin.java
└── ios/Sources/ALFDownloadPlugin/
    ├── ALFDownloadPlugin.m      # CAP_PLUGIN method registration
    └── ALFDownloadPlugin.swift  # URLSessionDownloadDelegate
```

### 3.3. Luồng xử lý Android

1. `downloadToDevice`: nếu SDK < 29 và chưa có quyền `WRITE_EXTERNAL_STORAGE` → tự xin qua `requestPermissionForAlias("storage", ...)` rồi callback lại.
2. Chạy trên `ExecutorService` (không block main thread).
3. `HttpURLConnection` → đọc từng chunk 8KB → ghi thẳng xuống `MediaStore`/`FileOutputStream`.
4. Mỗi chunk: `notifyListeners("OnDownloadProgress", { receivedBytes, totalBytes, progress })`.

### 3.4. Luồng xử lý iOS

1. `URLSession.downloadTask` với delegate `URLSessionDownloadDelegate`.
2. `urlSession(_:downloadTask:didWriteData:...)` → emit progress.
3. `didFinishDownloadingTo` → move file từ temp location sang đích, tạo thư mục cha.
4. `didCompleteWithError` → reject call nếu có lỗi.

### 3.5. Bảo mật path

Cả Android (`resolveWithin`) và iOS (`resolveWithin`) đều chặn path escape: `relativePath`/`targetPath` chứa `..` không được phép vượt ra ngoài thư mục gốc.

---

## 4. Usage examples

### 4.1. Tải model AI khi mở app (giảm dung lượng APK)

```typescript
async function ensureModelLoaded() {
  const RELATIVE = 'models/picast.bin'
  const URL = 'https://c1.alf.vn/picast/picast_wtool_win64_1.0.0.tar.br'

  if (await ALF.Instance.Download.IsDownloaded(RELATIVE)) {
    return ALF.Instance.Download.GetAppPath(RELATIVE)
  }

  const unsub = ALF.Instance.Download.SetOnDownloadProgress((e) => {
    updateProgressUI(Math.round(e.progress * 100))
  })
  try {
    const absPath = await ALF.Instance.Download.DownloadToApp(URL, RELATIVE)
    return absPath // truyền cho native AI loader
  } finally {
    unsub()
  }
}
```

### 4.2. Tải file về thư mục Download cho người dùng

```typescript
const saved = await ALF.Instance.Download.DownloadToDevice(
  'https://example.com/report.pdf',
  'reports/2026-08.pdf',
)
// Mở/Share qua absolute path (nếu cần)
```

---

## 5. Đăng ký & khởi tạo

- Controller đăng ký trong `sdk/alf/ALF.ts`: `public Download!: DownloadController`, khởi tạo trong `initControllers()`.
- Export trong `sdk/alf/controllers/index.ts` và `sdk/alf/index.ts`.
- Plugin nạp native qua `cap sync`: src-dev cần thêm `"@alf/download-plugin": "file:../sdk/plugins/download"` vào `package.json`.
- `initSDK` gọi `alf.Download.init()` (no-op — plugin dùng on-demand).

---

## 6. Lưu ý

- **Không thể ghi vào chính APK sau khi cài.** APK đã ký là read-only. `DownloadToApp` ghi vào internal storage — đạt đúng mục tiêu (APK nhẹ, tải khi mở app) nhưng file **không** nằm trong file APK.
- Trên Android 10+, `DownloadToDevice` không cần bất kỳ quyền nào (dùng `MediaStore`). Trên Android ≤9 cần `WRITE_EXTERNAL_STORAGE` (plugin tự xin runtime).
- iOS không có "thư mục Download" hệ thống mở ghi → `DownloadToDevice` ánh xạ sang `Documents/`.
- `DownloadToApp` không hỗ trợ trên web (web app không có filesystem nội bộ).
- File tải bằng `DownloadToApp` có thể đọc lại từ JS qua `@capacitor/filesystem` với `Directory.Data` + relative path (khớp `getFilesDir()` trên Android).
- Progress event dùng chung một listener duy nhất từ plugin; controller phát cho tất cả handler đã đăng ký.
