# PaymentController — Payment Gateway Integration

**Scope:** Xử lý thanh toán qua Stripe (PaymentSheet, Apple Pay, Google Pay) và các cổng thanh toán khác.

**Access:** `ALF.Instance.Payment`

---

## 1. Mục đích

`PaymentController` là đầu mối duy nhất để thực hiện mọi thao tác thanh toán trong ứng dụng:

- Tạo PaymentIntent qua backend server (giữ Stripe Secret Key an toàn)
- Hiển thị native payment sheet (Stripe PaymentSheet)
- Hỗ trợ Apple Pay (iOS) và Google Pay (Android)
- Ghi nhận giao dịch và tạo receipt
- Xác nhận giao dịch với backend

---

## 2. Native Plugin

| Plugin | Version | Chức năng |
|---|---|---|
| `@capacitor-community/stripe` | ^8.1.0 | PaymentSheet, Apple Pay, Google Pay |

Plugin này là open-source (MIT), được bảo trì bởi cộng đồng Capacitor.

---

## 3. Kiến trúc

```
App ──→ PaymentController ──→ Stripe Plugin (native)
  │                              ├── PaymentSheet
  │                              ├── Apple Pay (iOS)
  │                              └── Google Pay (Android)
  │
  └──→ Backend API ──→ Stripe API
                       └── create PaymentIntent
                       └── confirm / webhook
```

> **Quan trọng:** PaymentIntent phải được tạo từ backend server để bảo vệ Stripe Secret Key. Client chỉ dùng Publishable Key + Client Secret.

---

## 4. Cấu hình

### 4.1. Config `keys.payment`

```json
{
  "keys": {
    "payment": {
      "gateway": "stripe",
      "stripe": {
        "publishableKey": "pk_live_xxxxxxxxxxxx",
        "applePayMerchantId": "merchant.com.alf.app",
        "merchantDisplayName": "ALF App"
      },
      "backend": {
        "baseUrl": "https://api.myapp.com",
        "createIntentPath": "/create-payment-intent",
        "confirmPath": "/confirm-payment",
        "receiptPath": "/receipt",
        "apiKey": "your-backend-api-key"
      }
    }
  }
}
```

### 4.2. PaymentKeysConfig Fields

| Field | Type | Bắt buộc | Mô tả |
|---|---|---|---|
| `gateway` | `stripe` | ✅ | Cổng thanh toán (hiện tại chỉ Stripe) |
| `stripe.publishableKey` | `string` | ✅ | Stripe publishable key (client-side) |
| `stripe.applePayMerchantId` | `string` | (nếu dùng Apple Pay) | Merchant ID đã đăng ký với Apple |
| `stripe.merchantDisplayName` | `string` | | Tên hiển thị trong PaymentSheet |
| `backend.baseUrl` | `string` | ✅ | URL backend server |
| `backend.createIntentPath` | `string` | | Mặc định: `/create-payment-intent` |
| `backend.confirmPath` | `string` | | Mặc định: `/confirm-payment` |
| `backend.receiptPath` | `string` | | Mặc định: `/receipt` |
| `backend.apiKey` | `string` | | API key để auth với backend |

---

## 5. API

### 5.1. Pay — Bắt đầu thanh toán

```typescript
const result = await ALF.Instance.Payment.pay({
  amount: 499,        // $4.99 (minor unit: cents)
  currency: 'USD',    // ISO 4217
  description: 'Pro Monthly Subscription',
  metadata: { userId: '123' },
})
```

**`PaymentStartOptions`:**

| Field | Type | Bắt buộc | Mô tả |
|---|---|---|---|
| `amount` | `number` | ✅ | Số tiền (minor unit: cents / xu). VD: 499 = $4.99 |
| `currency` | `string` | ✅ | ISO 4217 currency code. VD: `USD`, `VND` |
| `description` | `string` | | Mô tả giao dịch |
| `clientSecret` | `string` | (nếu có sẵn) | PaymentIntent client secret từ backend |
| `customerId` | `string` | | Stripe Customer ID (để lưu phương thức thanh toán) |
| `customerEphemeralKeySecret` | `string` | | Ephemeral key cho customer |
| `enableApplePay` | `boolean` | | Bật Apple Pay (iOS) |
| `enableGooglePay` | `boolean` | | Bật Google Pay (Android) |
| `metadata` | `Record<string, string>` | | Metadata đính kèm giao dịch |

**`PaymentResult`:**

| Field | Type | Mô tả |
|---|---|---|
| `transactionId` | `string` | Internal transaction ID |
| `gatewayTransactionId` | `string` | Stripe PaymentIntent ID |
| `clientSecret` | `string?` | Client secret đã dùng |
| `transaction` | `PaymentTransaction` | Đầy đủ thông tin giao dịch |
| `receipt` | `PaymentReceipt?` | Receipt data |

### 5.2. Transactions

```typescript
// Lấy transaction theo ID
const tx = ALF.Instance.Payment.getTransaction('tx_12345')

// Lấy tất cả transactions trong session
const all = ALF.Instance.Payment.getTransactions()
```

**`PaymentTransaction`:**

| Field | Type | Mô tả |
|---|---|---|
| `id` | `string` | Internal ID |
| `gateway` | `stripe` | Gateway đã dùng |
| `status` | `PaymentStatus` | `pending`, `processing`, `succeeded`, `failed`, `cancelled`, `refunded` |
| `amount` | `number` | Số tiền (minor unit) |
| `currency` | `string` | Currency code |
| `paymentMethod` | `string?` | `card`, `apple_pay`, `google_pay` |
| `cardBrand` | `string?` | `visa`, `mastercard`, `amex`, ... |
| `cardLast4` | `string?` | 4 số cuối thẻ |
| `gatewayTransactionId` | `string?` | Stripe PaymentIntent ID |
| `clientSecret` | `string?` | Client secret |
| `createdAt` | `string` | Thời gian tạo |
| `completedAt` | `string?` | Thời gian hoàn tất |
| `description` | `string?` | Mô tả |
| `metadata` | `Record<string, string>?` | Metadata |

### 5.3. Receipt

```typescript
// Lấy receipt cho transaction
const receipt = await ALF.Instance.Payment.getReceipt('tx_12345')
```

**`PaymentReceipt`:**

| Field | Type | Mô tả |
|---|---|---|
| `id` | `string` | Receipt ID |
| `amountFormatted` | `string` | Số tiền đã format: `$4.99` hoặc `4.990₫` |
| `paidAt` | `string` | Ngày thanh toán |
| `paymentSummary` | `string` | Tóm tắt phương thức: `VISA •••• 4242` |
| `receiptUrl` | `string?` | URL download PDF receipt (nếu backend hỗ trợ) |

---

## 6. Backend API

Controller gọi các endpoint sau trên backend của bạn:

### 6.1. `POST /create-payment-intent`

Request body:
```json
{
  "amount": 499,
  "currency": "USD",
  "description": "Pro Monthly Subscription",
  "metadata": { "userId": "123" }
}
```

Response:
```json
{
  "clientSecret": "pi_3xxxx_secret_yyyy"
}
```

### 6.2. `POST /confirm-payment`

Request body:
```json
{
  "gateway": "stripe",
  "transactionId": "tx_12345",
  "gatewayTransactionId": "pi_3xxxx"
}
```

### 6.3. `GET /receipt/:transactionId`

Response:
```json
{
  "id": "tx_12345",
  "amountFormatted": "$4.99",
  "paidAt": "2026-06-16T10:00:00Z",
  "paymentSummary": "VISA •••• 4242",
  "receiptUrl": "/receipt/tx_12345/pdf"
}
```

---

## 7. Luồng sử dụng điển hình

### 7.1. Thanh toán cơ bản

```typescript
async function buySubscription() {
  try {
    const result = await ALF.Instance.Payment.pay({
      amount: 999,
      currency: 'USD',
      description: 'Pro Monthly',
      enableApplePay: true,
      enableGooglePay: true,
    })

    // Lưu giao dịch thành công
    await saveTransaction(result.transaction)

    // Hiển thị receipt
    showReceipt(result.receipt!)
  } catch (e: any) {
    if (e.message.includes('cancel')) {
      toast.info('Đã huỷ thanh toán')
    } else {
      toast.error('Thanh toán thất bại: ' + e.message)
    }
  }
}
```

### 7.2. Backend Node.js (Stripe)

Ví dụ backend tối thiểu với Stripe:

```javascript
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY)
const express = require('express')
const app = express()
app.use(express.json())

app.post('/create-payment-intent', async (req, res) => {
  const { amount, currency, description, metadata } = req.body
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency,
      description,
      metadata,
      automatic_payment_methods: { enabled: true },
    })
    res.json({ clientSecret: paymentIntent.client_secret })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

app.post('/confirm-payment', async (req, res) => {
  const { gatewayTransactionId } = req.body
  try {
    const pi = await stripe.paymentIntents.retrieve(gatewayTransactionId)
    // Lưu trạng thái giao dịch vào DB
    res.json({ status: pi.status })
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
})

app.get('/receipt/:id', async (req, res) => {
  // Lấy receipt từ DB
  res.json({ id: req.params.id, /* ... */ })
})

app.listen(3000)
```

---

## 8. Webhook (Server-side)

Stripe gửi webhook để thông báo sự kiện (thanh toán thành công, thất bại, refund). Backend của bạn cần xử lý:

```javascript
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY)

app.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature']
  let event
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.WEBHOOK_SECRET)
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`)
  }

  switch (event.type) {
    case 'payment_intent.succeeded':
      // Cập nhật trạng thái giao dịch trong DB
      break
    case 'payment_intent.payment_failed':
      // Xử lý lỗi
      break
    case 'payment_intent.refunded':
      // Xử lý hoàn tiền
      break
  }

  res.json({ received: true })
})
```

---

## 9. Testing

### 9.1. Stripe Test Mode

Dùng Stripe publishable key ở **Test Mode** (bắt đầu bằng `pk_test_`):

```json
{
  "stripe": {
    "publishableKey": "pk_test_xxxxxxxxxxxx"
  }
}
```

### 9.2. Thẻ test

| Card Number | Brand | Result |
|---|---|---|
| `4242 4242 4242 4242` | VISA | Success |
| `4000 0000 0000 3220` | VISA | 3D Secure required |
| `4000 0000 0000 0002` | VISA | Decline |
| `4000 0000 0000 9995` | VISA | Insufficient funds |

### 9.3. Sandbox Testing

**iOS:**
- Apple Pay: Chỉ hoạt động trên device thật, cần sandbox account
- PaymentSheet: Chạy được trên simulator

**Android:**
- Google Pay: Chỉ hoạt động trên device có Google Play services
- PaymentSheet: Chạy được trên emulator

---

## 10. Troubleshooting

### `@capacitor-community/stripe not installed`

```bash
npm install @capacitor-community/stripe
npx cap sync
```

### `Stripe plugin not available on this platform`

PaymentSheet hoạt động trên:
- Android: ✅ (native)
- iOS: ✅ (native)
- Web: ❌ (cần dùng Stripe.js trực tiếp)

### `No client secret` / `Backend not configured`

Cần cấu hình `keys.payment.backend.baseUrl` hoặc truyền `clientSecret` trực tiếp.

### `Payment cancelled by user`

User đã đóng PaymentSheet — đây không phải lỗi, không cần báo lỗi.

### `Payment failed` không rõ nguyên nhân

Kiểm tra:
1. Stripe publishable key còn hoạt động không
2. Backend endpoint `/create-payment-intent` trả về đúng client secret
3. Kiểm tra Stripe Dashboard → Payments để xem chi tiết lỗi

### Apple Pay không hiển thị

- Cần device thật (không chạy trên simulator)
- Merchant ID phải được đăng ký trên Apple Developer
- Xcode capability: In-App Purchase + Apple Pay

### Google Pay không hiển thị

- Cần device có Google Play services
- Tài khoản Google phải có phương thức thanh toán
- Google Pay phải được bật trong Stripe Dashboard

---

## 11. Tham khảo

- [Stripe PaymentSheet docs](https://stripe.com/docs/payments/accept-a-payment)
- [Stripe Apple Pay Guide](https://stripe.com/docs/apple-pay)
- [Stripe Google Pay Guide](https://stripe.com/docs/google-pay)
- [@capacitor-community/stripe](https://capacitor-community-stripe.netlify.app/)
- [capacitor-community/stripe GitHub](https://github.com/capacitor-community/stripe)
- [Stripe Webhooks](https://stripe.com/docs/webhooks)
- [Stripe API idempotency](https://stripe.com/docs/api/idempotent_requests)
