# `main.ts` — Entry point

## Vai trò

File đầu vào của ứng dụng. Khi app khởi động, `main.ts` gọi `initSDK(config)` với object config (có thể convert từ file JSON của repo). Sau đó mới mount Vue app.

## Luồng runApp()

```mermaid
flowchart TD
    A["runApp()"] --> B["fetch('/config.json')<br/><i>load config từ repo</i>"]
    B --> C["ConfigConverter.convert(raw, mappings)<br/><i>map field + merge defaults</i>"]
    C --> D["initSDK(config)<br/><i>set config + init tất cả SDK</i>"]
    
    D --> E["requireProjectConfig()<br/><i>đọc config UI/theme từ state</i>"]
    
    E --> F["Áp dụng theme<br/><i>--background, --primary-text</i>"]
    F --> G["Thiết lập router<br/><i>assignHome + addRoutes</i>"]
    
    G --> H["createApp(App)<br/>app.use(router)<br/>app.mount('#app')"]
```

## Giải thích các bước

| Bước | Hàm | Chức năng |
|---|---|---|
| 1 | `ConfigConverter.convert()` | Đọc raw JSON từ file `config.json` của repo, map field + merge defaults → object Config chuẩn. Nếu JSON đã đúng cấu trúc Config thì dùng thẳng (không cần mapping). |
| 2 | `initSDK(config)` | Gọi 1 lần duy nhất với object config. Bên trong: set config vào ConfigManager → RequestTracking (iOS ATT) → init lần lượt: Analytics (AppsFlyer), Ads (AppLovin MAX), Firebase, Storage, Permission, Camera, Share, Media. |
| 3 | `requireProjectConfig()` | Lấy config từ `state.ts` — config UI, router, theme đã được set trước bởi `src/index.ts` qua hàm `init(projectConfig)`. |
| 4 | Áp dụng theme | Set CSS variables từ projectConfig. |
| 5 | Thiết lập router | Gán trang chủ + thêm routes phụ (nếu có). |
| 6 | Mount Vue app | `createApp(App)`, `app.use(router)`, `app.mount('#app')`. |

## Cách dùng

```mermaid
flowchart LR
    A["src/index.ts<br/>init(projectConfig)"]
    A --> B["setProjectConfig(projectConfig)<br/><i>lưu config UI/theme</i>"]
    B --> C["runApp()"]
    
    C --> D["fetch + convert JSON"]
    D --> E["initSDK(config)"]
    E --> F["Mount Vue app"]
```
