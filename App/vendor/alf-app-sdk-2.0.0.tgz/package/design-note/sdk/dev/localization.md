# 🌐 Localization (I18n)

## Overview

ALF Framework tích hợp **vue-i18n** để hỗ trợ đa ngôn ngữ (localization) cho toàn bộ framework và các dự án sử dụng.

Kiến trúc:

```
src/af/i18n/
├── index.ts          # Setup: createI18n, setLocale, getCurrentLocale, SUPPORTED_LOCALES
├── vi.json           # Tiếng Việt
├── en.json           # English
├── ja.json           # 日本語
├── ko.json           # 한국어
├── zh.json           # 中文
├── th.json           # ไทย
├── es.json           # Español
├── pt.json           # Português
├── fr.json           # Français
├── de.json           # Deutsch
├── it.json           # Italiano
├── hi.json           # हिन्दी
├── bn.json           # বাংলা
├── id.json           # Bahasa Indonesia
├── ru.json           # Русский
├── tr.json           # Türkçe
├── ar-eg.json        # العربية (مصر)
└── pcm.json          # Naija Pidgin
```

## Cách hoạt động

### 1. Khởi tạo

`initSDK(config)` tự động gọi `createAppI18n()` với locale mặc định từ `config.settings.defaultLocale` (fallback `'en'`).

```mermaid
flowchart TD
    A[main.ts gọi initSDK config] --> B[ALF.Instance.initControllers]
    B --> C[ConfigManager.set config]
    C --> D{config.settings.defaultLocale?}
    D -->|Có| E[createAppI18n defaultLocale]
    D -->|Không| F[createAppI18n 'en']
    E --> G[App.use i18n]
    F --> G
    G --> H[Các view dùng useI18n + t ]
```



Trong `main.ts`:

```typescript
// main.ts
const app = createApp(App)
const i18n = createAppI18n('vi')  // hoặc locale từ config
app.use(i18n)                     // rồi mới mount
app.mount('#app')
```

### 2. Trong Vue components

Dùng Composition API:

```vue
<script setup>
import { useI18n } from 'vue-i18n'

const { t } = useI18n()
</script>

<template>
  <h1>{{ t('home.title') }}</h1>
  <p>{{ t('home.subtitle') }}</p>
  <button>{{ t('settings.confirm') }}</button>
</template>
```

Hoặc dùng template syntax trực tiếp:

```vue
<template>
  <p>{{ $t('home.sdk_title') }}</p>
</template>
```

### 3. Đổi ngôn ngữ runtime

Dùng `setLocale()` từ ALF framework:

```typescript
import { setLocale } from '@alf/app-sdk'

// Trong language picker:
function selectLang(code: string) {
  setLocale(code)       // 'vi' | 'en' | 'ja' | 'ko' | 'zh' | 'th' | 'es' | 'pt' | ...
}
```

Danh sách locale có sẵn:

```typescript
import { SUPPORTED_LOCALES } from '@alf/app-sdk'

// SUPPORTED_LOCALES = [
//   { code: 'vi',   label: 'Tiếng Việt',     flag: 'https://flagcdn.com/28x21/vn.png' },
//   { code: 'en',   label: 'English',         flag: 'https://flagcdn.com/28x21/us.png' },
//   { code: 'ja',   label: '日本語',           flag: 'https://flagcdn.com/28x21/jp.png' },
//   { code: 'ko',   label: '한국어',           flag: 'https://flagcdn.com/28x21/kr.png' },
//   { code: 'zh',   label: '中文',             flag: 'https://flagcdn.com/28x21/cn.png' },
//   { code: 'th',   label: 'ไทย',             flag: 'https://flagcdn.com/28x21/th.png' },
//   { code: 'es',   label: 'Español',         flag: 'https://flagcdn.com/28x21/es.png' },
//   { code: 'pt',   label: 'Português',       flag: 'https://flagcdn.com/28x21/br.png' },
//   { code: 'fr',   label: 'Français',        flag: 'https://flagcdn.com/28x21/fr.png' },
//   { code: 'de',   label: 'Deutsch',         flag: 'https://flagcdn.com/28x21/de.png' },
//   { code: 'it',   label: 'Italiano',        flag: 'https://flagcdn.com/28x21/it.png' },
//   { code: 'hi',   label: 'हिन्दी',             flag: 'https://flagcdn.com/28x21/in.png' },
//   { code: 'bn',   label: 'বাংলা',             flag: 'https://flagcdn.com/28x21/bd.png' },
//   { code: 'id',   label: 'Bahasa Indonesia', flag: 'https://flagcdn.com/28x21/id.png' },
//   { code: 'ru',   label: 'Русский',         flag: 'https://flagcdn.com/28x21/ru.png' },
//   { code: 'tr',   label: 'Türkçe',          flag: 'https://flagcdn.com/28x21/tr.png' },
//   { code: 'ar-eg', label: 'العربية (مصر)',    flag: 'https://flagcdn.com/28x21/eg.png' },
//   { code: 'pcm',  label: 'Naija Pidgin',    flag: 'https://flagcdn.com/28x21/ng.png' },
// ]
```

### 4. API Reference


| Function                        | Description                                     |
| ------------------------------- | ----------------------------------------------- |
| `createAppI18n(defaultLocale?)` | Tạo vue-i18n instance. Gọi 1 lần duy nhất.      |
| `getI18n()`                     | Lấy i18n instance hiện tại.                     |
| `setLocale(locale)`             | Đổi locale runtime.                             |
| `getCurrentLocale()`            | Trả về locale hiện tại.                         |
| `SUPPORTED_LOCALES`             | Mảng các locale được hỗ trợ + label + flag URL. |


## Cấu trúc locale JSON

Mỗi file `.json` chứa các key phân cấp, tương ứng với từng màn hình:

```json
{
  "app":       { "name": "..." },
  "language":  { "title": "...", "subtitle": "...", "confirm": "..." },
  "onboarding": {
    "skip": "...",
    "next": "...",
    "start": "...",
    "steps": [
      { "title": "...", "description": "..." },
      ...
    ]
  },
  "home":      { "title": "...", "subtitle": "...", "sdk_title": "...", "settings": "...", "gameplay": "..." },
  "settings":  { "title": "...", "general": "...", "sound": "...", "volume": "...", "other": "...", "game_mode": "...", "version": "...", "language": "..." },
  "gameplay":  { "title": "...", "back": "...", "tap_hint": "...", "finished": "...", "score": "...", "play_again": "...", "start": "..." }
}
```

## Mở rộng locale cho dự án

Dự án dùng framework có thể thêm locale riêng:

```typescript
import { getI18n } from '@alf/app-sdk'

const i18n = getI18n()

// Thêm locale mới
i18n.global.setLocaleMessage('fr', {
  home: { title: 'Accueil', subtitle: 'Bienvenue' },
  // ...
})

// Chuyển sang locale vừa thêm
import { setLocale } from '@alf/app-sdk'
setLocale('fr' as any)
```

Hoặc dùng Vue module augmentation để có autocomplete TypeScript.