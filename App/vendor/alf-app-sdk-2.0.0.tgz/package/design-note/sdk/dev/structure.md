# Cấu trúc thư mục ALF Framework

## Cây thư mục

```
project-root/
├── config.json                        # [CONFIG] Cấu hình framework: settings + keys
│
├── design-note/                       # [DOCS] Tài liệu thiết kế
│   ├── overview.md
│   ├── entity-diagram.md
│   ├── sequence-diagram.md
│   └── controllers/                   # Pseudo-code từng controller
│       ├── AdController.md
│       ├── CameraController.md
│       ├── PermissionController.md
│       ├── StorageController.md
│       ├── FirebaseController.md
│       ├── AnalyticsController.md
│       ├── ShareController.md
│       └── MediaController.md
│
src/
├── main.ts                          # [ENTRY] Gọi initSDK(config) → mount Vue app
├── App.vue                          # [VUE] Root component — <RouterView />
│
├── af/                              # [CORE] ALF Framework
│   ├── index.ts                     # Public API: initSDK(config), ALF, ConfigConverter, types
│   ├── ALF.ts                        # Singleton ALF: ConfigManager + 8 controllers
│   │
│   ├── controllers/                 # 8 module chức năng
│   │   ├── AdController.ts          #      ALF.Ads — banner, interstitial, rewarded
│   │   ├── CameraController.ts      #      ALF.Camera — chụp ảnh, pick từ gallery
│   │   ├── PermissionController.ts  #      ALF.Permission — xin/kiểm tra quyền
│   │   ├── StorageController.ts     #      ALF.Storage — JSON database local
│   │   ├── FirebaseController.ts    #      ALF.Firebase — remote config
│   │   ├── AnalyticsController.ts   #      ALF.Analytics — AppsFlyer events
│   │   ├── ShareController.ts       #      ALF.Share — share ảnh, text, file
│   │   ├── MediaController.ts       #      ALF.Media — capture element, slideshow video
│   │   └── index.ts                 # Barrel: export tất cả controller class
│   │
│   ├── types/                       # Interface/type cho params & return của controller
│   │   ├── ad.types.ts              #     AdViewPosition, AdFormat
│   │   ├── camera.types.ts          #     CameraOptions
│   │   ├── permission.types.ts      #     PermissionType, PermissionStatus
│   │   ├── storage.types.ts         #     StorageSchema, Filter
│   │   ├── firebase.types.ts        #     RemoteConfigValue
│   │   ├── analytics.types.ts       #     EventPayload
│   │   ├── share.types.ts           #     ShareOptions
│   │   ├── media.types.ts           #     CaptureOptions, SlideshowOptions, VideoResult
│   │   ├── config.types.ts          #     Config, Settings, KeysConfig — type cho config
│   │   └── index.ts                 # Barrel: export tất cả types
│   │
│   └── utils/                       # Helper dùng chung giữa các controller
│       ├── platform.ts              #     Capacitor platform check (isNative, isAndroid, isIOS)
│       ├── config.ts                #     Đọc ProjectConfigData từ state
│       ├── logger.ts                #     Logger thống nhất (console wrapper)
│       ├── deepGet.ts               #     Truy xuất object theo dot notation ("a.b.c")
│       └── ConfigConverter.ts       #     Convert JSON → object Config chuẩn
│
├── types/                           # [CONFIG] ProjectConfigData schema cho project chủ
│   ├── index.ts                     #     ProjectConfigData, CaptureOptions, SlideshowOpts
│   ├── app.ts                       #     AppConfig (id, name)
│   ├── applovin.ts                  #     ApplovinConfig (adUnitId theo platform)
│   ├── appsflyer.ts                 #     AppsFlyerConfig (devKey, iosAppId)
│   ├── router.ts                    #     RouterConfig (name, path, component)
│   └── server.ts                    #     ServerConfig (api endpoint)
│
├── router/                          # [VUE] Vue Router config
│   └── index.ts                     #     Khởi tạo router, addRoutes, assignHome
│
├── state.ts                         # [STATE] Global state: lưu ProjectConfigData
│                                   #     setProjectConfig / getProjectConfig / requireProjectConfig
│
└── index.ts                         # [PUBLIC API] Export cho project chủ
                                    #     init(), goToRouter(), showToast(), Database, captureImage
```

## Phân loại thư mục

| Loại | Thư mục / File | Mô tả |
|---|---|---|
| `[CONFIG]` | `config.json` (root) | Cấu hình framework: settings + keys — không commit lên git |
| `[CONFIG]` | `src/types/` | Schema cho ProjectConfigData — dữ liệu từ project chủ truyền vào qua `init()` |
| `[ENTRY]` | `src/main.ts` | Entry point — gọi `initSDK(config)` rồi mount Vue app |
| `[CORE]` | `src/af/` | Toàn bộ ALF Framework: singleton, controllers, types, utils |
| `[CORE]` | `src/af/index.ts` | Public API của framework: `initSDK(config)`, `ALF`, `ConfigConverter` |
| `[CORE]` | `src/af/ALF.ts` | Singleton ALF — chứa ConfigManager + 8 controller instance |
| `[CORE]` | `src/af/controllers/` | 8 controller, mỗi controller quản lý 1 nhóm chức năng |
| `[CORE]` | `src/af/types/config.types.ts` | Type `Config`, `Settings`, `KeysConfig` |
| `[CORE]` | `src/af/types/` | Interface & type nội bộ cho params/return của controller |
| `[CORE]` | `src/af/utils/` | Helper: platform check, config reader, logger, deepGet, ConfigConverter |
| `[VUE]` | `src/App.vue` | Root Vue component — chứa `<RouterView />` |
| `[VUE]` | `src/router/` | Vue Router — khởi tạo, addRoutes, assignHome |
| `[STATE]` | `src/state.ts` | Global state — lưu ProjectConfigData, getter/setter |
| `[PUBLIC API]` | `src/index.ts` | Đầu ra cho project chủ: `init()`, `goToRouter()`, `showToast()`, `Database`, `captureImage` |
