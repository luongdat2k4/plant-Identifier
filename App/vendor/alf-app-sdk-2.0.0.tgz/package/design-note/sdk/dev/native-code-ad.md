# Native Code — Ad Plugins (AppLovin MAX & AdMob)

> Tài liệu mô tả phần **code native** của các ad plugin trong `sdk/plugins`. Hai plugin có liên quan tới quảng cáo: `applovin` và `admob`. (Plugin `download` trong cùng thư mục không liên quan đến ad, không nằm trong tài liệu này.)

## Tổng quan kiến trúc

Mỗi plugin là một **Capacitor plugin**: TypeScript bridge + native implementation cho Android (Java) và iOS (Swift + ObjC registration). JS gọi qua `registerPlugin`, Capacitor bridge `notifyListeners` đẩy event native → JS.

```
sdk/plugins/applovin/
├── index.ts                    # registerPlugin('ALFAppLovinMAX')
├── src/
│   ├── definitions.ts          # Types + interface plugin method
│   ├── index.ts                # registerPlugin kèm web fallback
│   └── web.ts                  # Web implementation (no-op + warning)
├── android/
│   ├── build.gradle            # AppLovin SDK + mediation adapters
│   └── src/main/java/alf/applovin/ALFAppLovinMAXPlugin.java
├── ios/Sources/ALFAppLovinMAXPlugin/
│   ├── ALFAppLovinMAXPlugin.swift
│   └── ALFAppLovinMAXPlugin.m  # CAP_PLUGIN registration
└── Package.swift               # AppLovin-MAX-Swift-Package dependency

sdk/plugins/admob/
├── index.ts                    # registerPlugin('ALFAdMob')
├── src/
│   ├── definitions.ts          # BannerOptions, BannerSize, NativeAdData, ...
│   ├── index.ts
│   └── web.ts
├── android/
│   ├── build.gradle            # play-services-ads
│   └── src/main/java/alf/admob/ALFAdMobPlugin.java
├── ios/Sources/ALFAdMobPlugin/
│   ├── ALFAdMobPlugin.swift
│   └── ALFAdMobPlugin.m        # CAP_PLUGIN registration
└── Package.swift               # GoogleMobileAds SPM dependency
```

| Plugin | JS handle | Android class | iOS class |
|---|---|---|---|
| AppLovin MAX | `ALFAppLovinMAX` | `alf.applovin.ALFAppLovinMAXPlugin` | `ALFAppLovinMAXPlugin` (Swift) |
| AdMob | `ALFAdMob` | `alf.admob.ALFAdMobPlugin` | `ALFAdMobPlugin` (Swift) |

> **Web**: cả 2 plugin có `web.ts` implementation trả no-op + `console.warn` — ads không hoạt động trên web.

---

## 1. Plugin `ALFAppLovinMAX` (AppLovin MAX)

### 1.1 Method map

| Method (JS) | Android | iOS | Events gửi đi |
|---|---|---|---|
| `initialize` | `AppLovinSdk.initialize` | `ALSdk.initialize` | — |
| `isTablet` | `AppLovinSdkUtils.isTablet` | `UIDevice.userInterfaceIdiom == .pad` | — |
| `createBanner` / `showBanner` / `hideBanner` / `destroyBanner` | `MaxAdView` | `MAAdView` | — |
| `createMRec` / `showMRec` / `hideMRec` / `destroyMRec` | `MaxAdView(MREC)` | `MAAdView(.mrec)` | — |
| `showNativeAd({ template: 'mrec' })` (1.6.0) | ✅ `alf_native_ad_mrec.xml`, ~228dp, không body | ⛔ rơi về `medium` | — |
| `createMRec({ rect })` / `updateMRecRect` (1.5.0) | ✅ đặt giữa `rect`, 300×250dp | ⛔ bỏ qua `rect` | — |
| `loadInterstitial` / `isInterstitialReady` / `showInterstitial` | `MaxInterstitialAd` | `MAInterstitialAd` | `OnInterstitialAdHiddenEvent` |
| `loadRewardedAd` / `isRewardedAdReady` / `showRewardedAd` | `MaxRewardedAd` | `MARewardedAd` | `OnRewardedAdReceivedRewardEvent`, `OnRewardedAdSkippedEvent`, `OnRewardedAdHiddenEvent` |
| `loadAppOpenAd` / `isAppOpenAdReady` / `showAppOpenAd` | `MaxAppOpenAd` | `MAAppOpenAd` | `OnAppOpenAdHiddenEvent` |

### 1.2 Android (`ALFAppLovinMAXPlugin.java`)

**State** — tất cả cache theo `adUnitId` (HashMap):

```java
Map<String, MaxAdView>           banners;
Map<String, MaxAdView>           mrecs;
Map<String, MaxInterstitialAd>   interstitials;
Map<String, MaxRewardedAd>       rewardedAds;
Map<String, Boolean>             rewardedGranted;   // trạng thái grant theo adUnitId
Map<String, MaxAppOpenAd>        appOpenAds;
```

**Các điểm chính:**

- **`initialize`**: validate `sdkKey`, `AppLovinSdk.getInstance(ctx)` + `AppLovinSdkInitializationConfiguration` với `AppLovinMediationProvider.MAX`; resolve `{initialized:true, isTablet}` trong callback async. Mọi method ad khác phải qua `requireSdk(call)` (reject nếu SDK chưa init).
- **`createBanner`**: xóa banner cũ cùng unit → tạo `MaxAdView(adUnitId, sdk, ctx)` → `setListener(MaxAdViewAdListener)` resolve/reject **một lần** nhờ `AtomicBoolean loadCallCompleted` khi `onAdLoaded`/`onAdLoadFailed` → height cố định **50dp (phone) / 90dp (tablet)** → `FrameLayout.LayoutParams` (`MATCH_PARENT` × height, gravity `BOTTOM|CENTER_HORIZONTAL` hoặc `TOP|CENTER_HORIZONTAL`) → add vào **window content FrameLayout** trên UI thread → `adView.loadAd()`.
- **`showBanner`/`hideBanner`**: chỉ đổi `setVisibility(VISIBLE/GONE)` — banner giữ resource.
- **`createMRec`**: `MaxAdView(adUnitId, MaxAdFormat.MREC, sdk, ctx)` kích thước **300×250dp**; `gravityForMRecPosition()` map 7 vị trí (`TOP_LEFT/CENTER/RIGHT`, `CENTER`, `BOTTOM_LEFT/CENTER/RIGHT`) sang Android `Gravity`; vị trí bottom thì `applyBottomInset`. Có `rect` (1.5.0) thì `mrecRectLayoutParams()` đặt ad GIỮA rect (TOP|START + margin, quy px CSS × density như rect của native AdMob), không kéo giãn, không inset; `updateMRecRect` dời lại.
- **`loadInterstitial`**: tạo `MaxInterstitialAd`, `setListener`; trong `onAdHidden` → `notifyListeners("OnInterstitialAdHiddenEvent", {adUnitId})`.
- **`loadRewardedAd`**: `MaxRewardedAd.getInstance(adUnitId, sdk, ctx)`; `onUserRewarded` → `rewardedGranted[adUnitId]=true` + `OnRewardedAdReceivedRewardEvent` (kèm `amount`); `onAdLoaded` → `rewardedGranted=false`; `onAdHidden` → emit `OnRewardedAdHiddenEvent` **và** nếu `rewardedGranted != true` → emit `OnRewardedAdSkippedEvent`.
- **`loadAppOpenAd`**: `MaxAppOpenAd(adUnitId, sdk)`; `onAdHidden` → `OnAppOpenAdHiddenEvent`.
- **Ad container (quan trọng)**: `getAdContainer()` trả `(FrameLayout) getActivity().findViewById(android.R.id.content)`. Comment trong code ghi rõ: **không** add ad view vào WebView vì Capacitor WebView là `AbsoluteLayout`-derived, bỏ qua FrameLayout gravity → banner/MREC luôn dính phía trên.
- **`applyBottomInset`**: `setOnApplyWindowInsetsListener` set `lp.bottomMargin = insets.getSystemWindowInsetBottom()` — giữ ad bottom không bị che bởi navigation bar trên edge-to-edge Android 15+.
- **Build**: `applovin-sdk:13.6.3`, `google-adapter:25.4.0.0` (mediation AdMob), + 10 mediation adapters (bidmachine, bigoads, fyber, ironsource, vungle, facebook, mintegral, bytedance, unityads, yandex), `consumerProguardFiles 'proguard-rules.pro'`.

### 1.3 iOS (`ALFAppLovinMAXPlugin.swift` + `.m`)

**State** — dictionary theo `adUnitId` (`[String: ...]`), riêng `pendingBannerLoads: [String: CAPPluginCall]` để resolve call `createBanner` khi ad load xong (banner load là async):

**Các điểm chính:**

- **`initialize`**: `ALSdk.initialize(sdkKey:settings:)`, resolve `{initialized:true}` trong completion.
- **`createBanner`**: `MAAdView(adUnitIdentifier:)`, `backgroundColor = .black`, Auto Layout vào `safeAreaLayoutGuide` (leading/trailing + bottom/top), height cố định **50 (pad: 90)**, `loadAd()`, lưu call vào `pendingBannerLoads`. `createBanner` resolve **sau khi ad thực sự load** (qua `didLoad` / `didFailToLoadAd` của delegate), khác với Android.
- **`createMRec`**: `MAAdView(adUnitIdentifier:adFormat:.mrec)` **300×250**; vị trí map bằng 2 switch constraint (leading/trailing/centerX + top/bottom/centerY).
- **`loadInterstitial`**: `MAInterstitialAd`, resolve ngay; `didHide` → `OnInterstitialAdHiddenEvent`. (Load interstitial iOS không báo fail qua call vì resolve ngay — lỗi chỉ log `NSLog`.)
- **`loadRewardedAd`**: `MARewardedAd.shared(withAdUnitIdentifier:)`; `didRewardUser` → grant + `OnRewardedAdReceivedRewardEvent`; `didHide` → `OnRewardedAdHiddenEvent` + nếu chưa grant → `OnRewardedAdSkippedEvent`.
- **`loadAppOpenAd`**: `MAAppOpenAd`; `didHide` → `OnAppOpenAdHiddenEvent`.
- **Delegates**: plugin implement `MAAdViewAdDelegate` (banner + MREC), `MAInterstitialAdDelegate`, `MARewardedAdDelegate`, `MAAppOpenAdDelegate`.
- **Registration** (`.m`): `CAP_PLUGIN(ALFAppLovinMAXPlugin, "ALFAppLovinMAX", ...)` liệt kê đủ 19 method.
- **Build**: `Package.swift` dùng `AppLovin-MAX-Swift-Package` (từ 12.6.0), iOS 14+.

### 1.4 Sự khác biệt Android vs iOS

| Hành vi | Android | iOS |
|---|---|---|
| Banner load resolve | `createBanner` resolve khi `onAdLoaded` | `createBanner` resolve khi `didLoad` (qua `pendingBannerLoads`) |
| Interstitial load | resolve/reject theo kết quả load | resolve ngay, fail chỉ log |
| Vị trí banner | `FrameLayout` gravity + bottom inset | Auto Layout vào safeArea |

---

## 2. Plugin `ALFAdMob` (AdMob)

### 2.1 Method map

| Method (JS) | Android | iOS | Events gửi đi |
|---|---|---|---|
| `initialize` | `MobileAds.initialize` | `MobileAds.shared.start` | — |
| `createBanner` / `showBanner` / `hideBanner` / `destroyBanner` | ✅ `AdView` (+ size/collapsible) | ❌ **chưa implement** | — |
| `loadInterstitial` / `isInterstitialReady` / `showInterstitial` | ✅ | ✅ | — |
| `loadRewardedAd` / `isRewardedAdReady` / `showRewardedAd` | ✅ | ✅ | `OnRewardedAdReceivedRewardEvent`, `OnRewardedAdSkippedEvent` |
| `loadOpenAppAd` / `isOpenAppAdReady` / `showOpenAppAd` | ✅ | ✅ | — |
| `showNativeAd` / `updateNativeAdRect` / `hideNativeAd` | ✅ `NativeAdView` | ✅ `NativeAdView` | `OnNativeAdImpressionEvent`, `OnNativeAdClickedEvent`, `OnNativeAdPaidEvent` |
| `showNativeAd({ overlay })` / `updateNativeAdOverlay` (1.3.4, rect mode) / `removeNativeAdOverlay` (1.7.0) | ✅ `LinearLayout` sibling trên ad | ✅ `ALFNativeAdOverlayView` sibling trên ad | `OnNativeAdOverlayCloseEvent` |
| `loadNativeAd` / `isNativeAdReady` / `destroyNativeAd` | ✅ | ✅ | `OnNativeAdLoadedEvent`, `OnNativeAdFailedToLoadEvent` |
| Tham số `slot` cho mọi method native (1.4.0) | ✅ khoá theo slot | ⛔ bỏ qua, khoá theo `adUnitId` | mọi event native thêm `slot` (Android) |
| `playNativeAdVideo` / `pauseNativeAdVideo` / `muteNativeAdVideo` | ✅ `VideoController` | ✅ `VideoController` | `OnNativeAdVideoEvent` |
| `reportNativeAdClick` | ⛔ luôn reject | ⛔ luôn reject | — |

> ⚠️ **Banner chỉ có trên Android.** iOS Swift + ObjC registration **không có** các method banner. Trên iOS, banner của app phải qua AppLovin (xem `AdController.ShowBannerAd` — chuỗi fallback). Gọi `ALFAdMob.createBanner` trên iOS sẽ báo "method not implemented".

### 2.1b Vì sao native ad phải render ở tầng native

AdMob **bắt buộc** native ad được hiển thị bằng `NativeAdView` (Android) / `NativeAdView` (iOS, trước đây `GADUnifiedNativeAdView`): gán từng asset view (`headlineView`, `iconView`, `mediaView`, `callToActionView`, ...) rồi `setNativeAd()` / `.nativeAd =`. Đúng thời điểm đó SDK mới:

1. ghi nhận **impression**, và
2. gắn **click handler** lên các asset view đã đăng ký.

Bóc asset ra JSON rồi vẽ lại bằng HTML trong WebView — cách SDK làm trước đây — không tạo view nào cho SDK, nên:

- không impression nào được ghi → AdMob coi ad chưa từng hiển thị;
- bấm CTA không mở được advertiser;
- vi phạm policy native ad → ad unit thật fill rất thấp hoặc bằng 0 (test unit vẫn load bình thường, nên dev nhìn như chạy được).

`loadNativeAd` vẫn còn để preview/debug và **đã được đánh dấu deprecated cho mục đích hiển thị**. `reportNativeAdClick` giờ luôn reject: không có cách hợp lệ nào để báo click thủ công, và việc nó im lặng resolve đã che mất sự thật rằng ad vẽ bằng HTML chưa bao giờ bấm được.

**Hai chế độ đặt vị trí của `showNativeAd`:**

| Mode | Tham số | Dùng khi |
|---|---|---|
| anchor | `position: 'TOP_CENTER' \| 'BOTTOM_CENTER'`, `height` (dp) | Ad neo mép màn hình, giống banner |
| rect | `rect: { x, y, width, height }` (CSS px) | Ad nằm trong layout app — JS đo placeholder bằng `getBoundingClientRect()`, gọi `updateNativeAdRect` khi scroll/resize |

Ad view nằm **trên** WebView và không tự cuộn theo trang, nên rect mode bắt buộc phải đồng bộ lại vị trí khi scroll.

### 2.2 Android (`ALFAdMobPlugin.java`)

**State:**

```java
Map<String, InterstitialAd>  interstitials;
Map<String, RewardedAd>      rewardedAds;
Map<String, AppOpenAd>       openAppAds;
Map<String, NativeAd>        nativeAds;
Map<String, AdView>          banners;
Map<String, Boolean>         rewardedGranted;
```

**Các điểm chính:**

- **`initialize`**: `MobileAds.initialize(ctx, listener)` → resolve `{initialized:true}`. Lưu ý: `requireSdk(call)` ở đây **trả về void** — chỉ `call.reject` nếu SDK chưa init nhưng **không dừng** luồng xử lý tiếp (khác AppLovin có `return false`).
- **`createBanner`**: xóa banner cũ → `AdView` + `setAdSize(parseAdSize(call))` → `AdListener` resolve `{width, height}` (đơn vị **dp**) khi `onAdLoaded`, reject khi fail → add vào window container UI thread + `applyBottomInset` nếu bottom → `adView.loadAd(buildBannerRequest(collapsible))`.
  - `parseAdSize`: `size` object `{width,height}` → `new AdSize(w,h)`; nếu string → `BANNER`/`LARGE_BANNER`/`MEDIUM_RECTANGLE`/`FULL_BANNER`/`LEADERBOARD`; mặc định → **anchored adaptive** (`getCurrentOrientationAnchoredAdaptiveBannerAdSize` theo screen width).
  - `buildBannerRequest`: thêm `AdMobAdapter` extras `{collapsible: 'top'|'bottom'}` → collapsible banner.
  - `bannerLayoutParams`: adaptive → width `MATCH_PARENT`; fixed → width/height px cố định; gravity bottom/top.
- **`loadInterstitial`**: `InterstitialAd.load`; `onAdDismissedFullScreenContent` chỉ xóa khỏi map (không emit event JS). Show trên main thread.
- **`loadRewardedAd`**: `RewardedAd.load`; khi dismiss: nếu `rewardedGranted != true` → emit `OnRewardedAdSkippedEvent`, rồi xóa khỏi map. `showRewardedAd` dùng `OnUserEarnedRewardListener` → `granted=true` + `OnRewardedAdReceivedRewardEvent`.
- **`loadOpenAppAd`**: `AppOpenAd.load` **bắt buộc trên main thread** (comment trong code); dismiss → xóa khỏi map.
- **`loadNativeAdInternal(adUnitId, call, callback)`**: `AdLoader.forNativeAd`, dùng chung bởi `loadNativeAd` (trả asset về JS) và `showNativeAd` (render thật). `buildNativeAdOptions(call)` đọc `video` / `mediaAspectRatio` của call → `VideoOptions` (`setStartMuted` mặc định `true`, `setCustomControlsRequested`, `setClickToExpandRequested`) + `setMediaAspectRatio(NATIVE_MEDIA_ASPECT_RATIO_*)`. Giữ `setReturnUrlsForImageAssets` ở mặc định `false` — khi đó SDK tự tải asset và điền **cả** `Drawable` lẫn `Uri`; bật `true` sẽ chỉ còn URL và làm `NativeAdView` mất icon.
- **`loadNativeAd`** *(deprecated cho hiển thị)*: build `JSObject` gồm `headline, body, callToAction, iconUrl, imageUrl, hasVideoContent, mediaAspectRatio, videoDuration, videoCustomControlsEnabled, price, store, starRating, advertiser`. Không còn `mediaUrl`: `getMediaContent().getMainImage()` trả `Drawable`, `.toString()` ra `BitmapDrawable@7f3a1b2` chứ không phải URL — nên thay bằng cờ `hasVideoContent`.
- **`showNativeAd`**: lấy ad từ cache (load trước nếu chưa có) → `renderNativeAd` trên UI thread: inflate `R.layout.alf_native_ad_{small,medium}` → `bindNativeAssets` gán + đăng ký từng asset view → `applyNativeAdStyle` → **`adView.setNativeAd(nativeAd)`** → add vào `getAdContainer()` với LayoutParams theo anchor hoặc rect.
- **`updateNativeAdRect` / `hideNativeAd`**: đổi LayoutParams / `setVisibility(GONE)` trên UI thread, không dựng lại view. `destroyNativeAdView` gỡ view + `adView.destroy()`.
- **Layout**: `res/layout/alf_native_ad_small.xml` và `alf_native_ad_medium.xml`, root là `NativeAdView`, dùng chung view id nên bind một lần cho cả 2 preset. Cả hai đều có nhãn "Ad" (bắt buộc theo policy).
- **Container & inset**: cùng pattern AppLovin — `getAdContainer()` = `android.R.id.content`, `applyBottomInset` cho edge-to-edge Android 15+.
- **Event native ad**: `loadNativeAdInternal` gắn `onAdImpression()` / `onAdClicked()` vào `AdListener` và `nativeAd.setOnPaidEventListener(...)` ngay khi ad loaded (trước khi caller kịp show, vì paid event bắn theo impression). `nativeAdToJson()` được dùng chung cho `loadNativeAd` và `OnNativeAdLoadedEvent` nên payload luôn khớp nhau.
- **Native video**: `MediaView` trong template `medium` tự phát video — không cần code riêng để hiển thị. `attachVideoLifecycle()` gắn `VideoController.VideoLifecycleCallbacks` ngay khi ad loaded (chỉ khi `hasVideoContent`) → `OnNativeAdVideoEvent` với `state` = `start` / `play` / `pause` / `end` / `mute` / `unmute`. `playNativeAdVideo` / `pauseNativeAdVideo` / `muteNativeAdVideo` lấy `VideoController` qua `videoControllerFor(call)` (reject nếu chưa load hoặc media không phải video) rồi gọi trên UI thread.
- **`handleOnDestroy()`**: destroy toàn bộ `NativeAdView` + `NativeAd` + `AdView` (banner) còn trong map và clear các map full-screen. Cần thiết vì WebView chết cùng Activity → `ALF.Ads.destroy()` bên JS không kịp chạy; `NativeAd` và `AdView` đều đòi `destroy()` tường minh. Chạy sẵn trên main thread nên gọi trực tiếp, **không** `runOnUiThread` (post có thể chạy sau khi Activity đã biến mất).
- **Build**: `play-services-ads:25.4.0`, `consumerProguardFiles`.

### 2.3 iOS (`ALFAdMobPlugin.swift` + `.m`)

**State:**

```swift
var interstitials: [String: InterstitialAd]
var rewardedAds:   [String: RewardedAd]
var openAppAds:    [String: AppOpenAd]
var nativeAds:     [String: NativeAd]
var rewardedGranted: [String: Bool]
var nativeAdLoaders: [String: AdLoader]
var nativeAdViews:   [String: NativeAdView]    // view đang hiển thị ad
var nativeAdRectConstraints: [String: (x, y, w, h)]  // giữ constraint cho rect mode
var pendingNativeRequests: [String: PendingNativeRequest]  // .assets | .show
```

**Các điểm chính:**

- **Không có banner** (xem lưu ý ở trên).
- **`loadInterstitial` / `loadRewardedAd` / `loadOpenAppAd`**: dùng `InterstitialAd.load` / `RewardedAd.load` / `AppOpenAd.load(with:request:orientation:.portrait)` — resolve/reject theo kết quả async. Show trên `DispatchQueue.main`.
- **Rewarded**: `present(from:)` completion → `rewardedGranted=true` + `OnRewardedAdReceivedRewardEvent`. Skip được xử lý ở `FullScreenContentDelegate.adDidDismissFullScreenContent` — tìm ad trong `rewardedAds`, nếu chưa grant → `OnRewardedAdSkippedEvent`, rồi cleanup cả interstitial/openApp khỏi map.
- **`loadNativeAdInternal`**: `AdLoader(adTypes:[.native], options: nativeAdLoaderOptions(call))` — `VideoOptions` (`shouldStartMuted` mặc định `true`, `areCustomControlsRequested`, `isClickToExpandRequested`) + `NativeAdMediaAdLoaderOptions.mediaAspectRatio`; `NativeAdLoaderDelegate`; lưu loader vào `nativeAdLoaders` và ý định của caller vào `pendingNativeRequests` (`.assets` cho `loadNativeAd`, `.show` cho `showNativeAd`). `adLoader(didReceive:)` phân nhánh theo ý định đó: `.show` → `renderNativeAd`, `.assets` → map asset rồi resolve.
- **`loadNativeAd`** *(deprecated cho hiển thị)*: map `headline, body, callToAction, icon.imageURL, images.first, hasVideoContent, price, store, starRating, advertiser`. Không còn `mediaUrl` — trước đây gán thẳng một `UIImage` vào `JSObject`, không serialize qua bridge được.
- **`showNativeAd`**: `ALFNativeAdViewBuilder.make()` dựng `NativeAdView` bằng UIStackView (2 preset khớp Android), gán asset view rồi `adView.nativeAd = nativeAd` → addSubview vào `bridge?.viewController?.view`. Anchor mode constraint theo `safeAreaLayoutGuide`; rect mode constraint theo x/y/w/h (CSS px ≈ point), giữ lại constraint để `updateNativeAdRect` chỉ đổi `constant`.
- **`ALFNativeAdView.swift`**: builder + `ALFNativeAdStyle` + `UIColor(alfHex:)` (parse `#RGB`/`#RRGGBB`/`#AARRGGBB`, cùng định dạng Android `Color.parseColor` nhận). Nút CTA đặt `isUserInteractionEnabled = false` để SDK nhận tap qua `NativeAdView` thay vì button nuốt mất.
- **`reportNativeAdClick`**: luôn reject — xem mục 2.1b.
- **Event native ad**: `adLoader(didReceive:)` gắn `nativeAd.delegate = self` và `nativeAd.paidEventHandler`, đồng thời emit `OnNativeAdLoadedEvent` (payload từ `nativeAdPayload()`, dùng chung với `loadNativeAd`). `extension ALFAdMobPlugin: NativeAdDelegate` implement `nativeAdDidRecordImpression` / `nativeAdDidRecordClick`; `adUnitId(for:)` tra ngược ad → unit id vì SDK chỉ trả về `NativeAd`. Loader được xoá khỏi `nativeAdLoaders` ngay sau khi load xong thay vì giữ tới lúc destroy.
- **Native video**: `adLoader(didReceive:)` gán `mediaContent.videoController.delegate = self` khi ad có video; `extension ALFAdMobPlugin: VideoControllerDelegate` → `OnNativeAdVideoEvent`. iOS **không có** callback `start` — frame đầu tiên đến dưới dạng `play`. `adUnitId(for: VideoController)` tra ngược controller → unit id. `mediaContent` là **non-optional** trong SDK 12 — code cũ dùng `nativeAd.mediaContent?` / `if let mediaContent =` (không compile được với non-optional) đã được sửa, `MediaView` giờ luôn được thêm vào template `medium`.
- **Không có hook lifecycle**: `CAPPlugin` không có `handleOnDestroy` như Android; plugin sống cùng app nên phải dựa vào `destroyNativeAd` gọi từ JS.
- **Registration** (`.m`): `CAP_PLUGIN(ALFAdMobPlugin, "ALFAdMob", ...)` liệt kê 21 method (không có banner; `updateNativeAdOverlay` thêm ở 1.3.4).
- **Slot (1.4.0, Android)**: map `nativeAds` / `nativeAdViews` / `nativeAdOverlays` khoá theo **slot** (`call.slot`, mặc định = `adUnitId` ⇒ y như trước). Hai slot dùng chung một unit vẫn là hai ad, hai view riêng. `nativeSlotUnits` nhớ unit đang nằm ở mỗi slot: `showNativeAd` chỉ dùng lại view/ad cache khi **cùng unit**, khác unit thì nạp mới (chuỗi fallback đi trong một slot). `nativeLoadTokens` đánh dấu lần nạp mới nhất của slot: lần nạp cũ về muộn (sau lần nạp mới hoặc sau `destroyNativeAd`) bị huỷ và không bắn event, nên unit chậm đầu chuỗi không đè lên unit thay nó. iOS chưa làm: Swift vẫn khoá theo `adUnitId`, bỏ qua `slot`.
- **Overlay (1.3.4)**: nhãn + nút đóng native vẽ TRÊN ad rect-mode (cả 2 nền tảng, cùng luật): là view anh em của `NativeAdView`, không phải con — không thuộc ad. Vùng trống không nhận chạm (Android: view không clickable; iOS: `hitTest` trả `nil`) nên chạm xuyên xuống ad; nút đóng nhận chạm cả khi đang khoá. Lớp nút né status bar/tai thỏ mà rect chui dưới; content template được đệm xuống dưới hàng nút và lên khỏi nav bar để không asset nào bị che. Đổi rect / ẩn / hiện / destroy thì overlay đi theo.
- **Build**: `Package.swift` dùng `swift-package-manager-google-mobile-ads` (từ 12.6.0), iOS 14+.

---

## 3. Event native → JS

Event đẩy lên JS qua `notifyListeners` — JS đăng ký bằng `addListener(eventName, cb)`.

| Event | Nguồn | Payload |
|---|---|---|
| `OnInterstitialAdHiddenEvent` | AppLovin (Android + iOS) | `{ adUnitId }` |
| `OnRewardedAdReceivedRewardEvent` | AppLovin + AdMob (Android + iOS) | `{ adUnitId, amount? }` |
| `OnRewardedAdSkippedEvent` | AppLovin (Android/iOS) + AdMob (Android/iOS) | `{ adUnitId }` |
| `OnRewardedAdHiddenEvent` | AppLovin (Android + iOS) | `{ adUnitId }` |
| `OnAppOpenAdHiddenEvent` | AppLovin (Android + iOS) | `{ adUnitId }` |
| `OnNativeAdLoadedEvent` | AdMob (Android + iOS) | `NativeAdData` |
| `OnNativeAdFailedToLoadEvent` | AdMob (Android + iOS) | `{ adUnitId, error }` |
| `OnNativeAdImpressionEvent` | AdMob (Android + iOS) | `{ adUnitId }` |
| `OnNativeAdClickedEvent` | AdMob (Android + iOS) | `{ adUnitId }` |
| `OnNativeAdPaidEvent` | AdMob (Android + iOS) | `{ adUnitId, value, currencyCode, precision }` |
| `OnNativeAdVideoEvent` | AdMob (Android + iOS) | `{ adUnitId, state: 'start' | 'play' | 'pause' | 'end' | 'mute' | 'unmute' }` — `start` chỉ Android |

> **Ghi chú về native ad event:** nguồn phát là callback của chính Google SDK, **không** phải suy ra từ lời gọi JS —
> Android dùng `onAdImpression()` / `onAdClicked()` của `AdListener` (gắn ở `AdLoader.Builder.withAdListener`) và
> `NativeAd.setOnPaidEventListener`; iOS dùng `NativeAdDelegate` (`nativeAdDidRecordImpression` / `nativeAdDidRecordClick`)
> và `nativeAd.paidEventHandler`. Vì vậy `impression` là tín hiệu **duy nhất** đáng tin rằng ad đã hiện thật: `showNativeAd()`
> resolve chỉ nghĩa là view đã được attach. `precision` được map về cùng 4 giá trị chuỗi ở 2 nền tảng
> (`unknown` / `estimated` / `publisherProvided` / `precise`), và `value` luôn là **đơn vị tiền tệ nguyên** (Android chia micros cho 1e6).
>
> 2 event `OnAdLoadedEvent` / `OnAdFailedToLoadEvent` đã **bị xóa** ở 1.2.0 — chúng từng được khai báo trong TS definitions
> nhưng native chưa bao giờ emit, nên `addListener` trả về handle hợp lệ mà callback không bao giờ chạy.

> **Ghi chú về rewarded:** cả 2 provider đều theo cùng một cơ chế — native giữ `rewardedGranted[adUnitId]`; khi full-screen ad đóng, nếu chưa grant reward thì native tự emit `OnRewardedAdSkippedEvent`. Nhờ vậy `AdController.ShowRewardedVideo` phân biệt được `rewarded` / `skipped` mà không cần chờ payload riêng.

## 4. Pattern chung đáng lưu ý

1. **Ad view phải nằm trong window content `FrameLayout`** (`android.R.id.content`), không phải WebView — vì Capacitor WebView (AbsoluteLayout-derived) bỏ qua gravity, khiến banner/MREC render sai vị trí.
2. **Edge-to-edge Android 15+**: mọi ad view anchor bottom đều `applyBottomInset()` — set `bottomMargin = systemWindowInsetBottom`.
3. **`AtomicBoolean loadCallCompleted`** (Android) — resolve/reject call load đúng **một lần** duy nhất, tránh double-settle khi callback fire nhiều lần.
4. **Load async resolve**: AppLovin banner Android resolve khi ad loaded; AppLovin iOS dùng `pendingBannerLoads` tương đương; AdMob interstitial/rewarded/openApp resolve qua `*LoadCallback`; AdMob native iOS resolve qua `pendingCalls`.
5. **Web implementation là no-op** — dựa vào `platform === 'web'` check ở controller, JS không gọi native khi trên web.
6. **Cache theo `adUnitId`** ở cả 2 plugin — cùng một unit chỉ tồn tại một instance; tạo lại sẽ destroy instance cũ.
