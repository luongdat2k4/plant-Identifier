# `index.ts` — Barrel export của ALF Framework

## Vai trò

File này là **public API** của toàn bộ ALF Framework. Nó export:
1. Hàm `initSDK(config)` — khởi tạo tất cả SDK (gọi từ `main.ts`)
2. Singleton `ALF` class
3. `ConfigConverter` — utility convert JSON → object config
4. Type definitions

---

## Luồng initSDK(config)

```mermaid
flowchart TD
    A["initSDK(config)"] --> B{"config hợp lệ?"}
    B -->|"config null hoặc keys null"| C["THROW Error"]
    B -->|OK| D["mergeDefaults(config)<br/><i>fill settings thiếu</i>"]
    
    D --> E["ALF.Instance<br/><i>lấy singleton</i>"]
    E --> F["af.Config.set(config)<br/><i>lưu config vào memory</i>"]
    
    F --> G["Permission.RequestTracking()<br/><i>iOS ATT — non-fatal</i>"]
    
    G --> H["Analytics.init()<br/><i>AppsFlyer — keys.appsflyer</i>"]
    H --> I["Ads.init()<br/><i>AppLovin MAX — keys.applovin</i>"]
    I --> J["Firebase.init()<br/><i>Remote Config fetch</i>"]
    J --> K["Storage.init()<br/><i>Filesystem DB</i>"]
    K --> L["Permission.init()"]
    L --> M["Camera.init()"]
    M --> N["Share.init()"]
    N --> O["Media.init()"]
    
    O --> P["LOG 'All SDK initialized successfully.'"]
```

## Thứ tự init

```mermaid
flowchart LR
    subgraph "Bước 1: Config"
        A["Config.set(config)"]
    end
    
    subgraph "Bước 2: ATT"
        B["Permission.RequestTracking()"]
    end
    
    subgraph "Bước 3: Init SDK"
        C["Analytics.init()<br/><i>AppsFlyer</i>"]
        D["Ads.init()<br/><i>AppLovin MAX</i>"]
        E["Firebase.init()<br/><i>Firebase RC</i>"]
        F["Storage.init()<br/><i>Filesystem</i>"]
    end
    
    subgraph "Bước 4: Module còn lại"
        G["Permission.init()"]
        H["Camera.init()"]
        I["Share.init()"]
        J["Media.init()"]
    end
    
    A --> B --> C --> D --> E --> F --> G --> H --> I --> J
```

### Lý do từng bước

| Thứ tự | Bước | Lý do |
|---|---|---|
| 1 | `Config.set(config)` | Set config trước — các controller khác cần config để init |
| 2 | `Permission.RequestTracking()` | iOS: phải xin ATT trước mọi SDK tracking |
| 3 | `Analytics.init()` | AppsFlyer: cần init sớm để bắt sự kiện install |
| 4 | `Ads.init()` | AppLovin MAX: cần sdkKey từ config |
| 5 | `Firebase.init()` | Remote Config: fetch sớm để kịp A/B test |
| 6 | `Storage.init()` | Database đọc file từ disk |
| 7 | Các module còn lại | Camera, Share, Media — không cần startup sớm |

---

## Cách dùng

### Cách 1: Truyền config trực tiếp (ưu tiên)

```mermaid
flowchart LR
    A["fetch('/config.json')"] --> B["ConfigConverter.convert(raw, mappings)"]
    B --> C["initSDK(config)"]
    C --> D["ALF.Config<br/>(memory)"]
    
    D --> E["ALF.Ads.InitBannerAd()"]
    D --> F["ALF.Camera.Take()"]
    D --> G["ALF.Share.ShareImage(data)"]
    D --> H["ALF.Config.get('settings.environment')"]
```

### Cách 2: Truyền thẳng object

```mermaid
flowchart LR
    A["initSDK({<br/>  settings: { dev: true, ... },<br/>  keys: { applovin: {...}, ... }<br/>})"]
    A --> B["ALF.Config.set(config)"]
```

### Ví dụ mapping ConfigConverter

```mermaid
flowchart LR
    A["JSON repo<br/>{ 'app.name':'MyApp',<br/>  'ads.max.sdkKey':'xxx' }"]
    A --> B["ConfigConverter.convert(raw, {<br/>  'app.name': 'settings.appName',<br/>  'ads.max.sdkKey': 'keys.applovin.android.sdkKey'<br/>})"]
    B --> C["Config chuẩn<br/>{ settings:{ appName:'MyApp' },<br/>  keys:{ applovin:{ android:{ sdkKey:'xxx' }}}}]"]
```

---

## Exports

| Export | Loại | Mô tả |
|---|---|---|
| `initSDK(config)` | Function | Hàm khởi tạo duy nhất, gọi từ `main.ts` |
| `ALF` | Class | Singleton: ConfigManager + 8 controllers |
| `ConfigConverter` | Class | Utility convert JSON → object Config |
| `Config`, `Settings`, `KeysConfig` | Type | Config types |
| `AdController`, `CameraController`, ... | Type | Controller types |
