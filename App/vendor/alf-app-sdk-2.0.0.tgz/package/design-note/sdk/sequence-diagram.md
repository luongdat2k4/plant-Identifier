# Sequence Diagrams

## 1. Sequence Diagram — Khởi tạo (initSDK)

Luồng khởi tạo toàn bộ framework khi app start. `initSDK(config)` nhận object config, set vào ConfigManager, sau đó lần lượt init các controller.

```mermaid
sequenceDiagram
    participant main as main.ts
    participant init as initSDK(config)
    participant ALF as ALF (singleton)
    participant Config as ConfigManager
    participant Ads as AdController
    participant Analytics as AnalyticsController
    participant Firebase as FirebaseController
    participant Perm as PermissionController
    participant Store as StorageController
    participant Vue as Vue App

    main->>init: await initSDK(config)
    init->>ALF: ALF.Instance
    Note over ALF: new ALF() <br/>tạo ConfigManager + tất cả controller

    init->>Config: set(config)
    Note over Config: lưu config object vào memory
    Config-->>init: ready

    init->>Perm: RequestTracking()
    Perm-->>init: tracking status

    init->>Analytics: await init()
    Analytics->>Config: get('keys.appsflyer')
    Analytics->>Config: get('settings.dev')
    Analytics->>Analytics: AppsFlyer initSDK(config)
    Analytics-->>init: ok

    init->>Ads: await init()
    Ads->>Config: get('keys.applovin.android.sdkKey')
    Ads->>Ads: AppLovin MAX initialize(sdkKey)
    Ads-->>init: ok

    init->>Firebase: await init()
    Firebase->>Firebase: FirebaseRemoteConfig.fetchAndActivate()
    Firebase-->>init: ok

    init->>Store: await init()
    Store->>Store: Filesystem đọc / tạo db.json
    Store-->>init: ok

    init->>Perm: await init()
    Perm-->>init: ok

    init-->>main: done
    main->>Vue: app.mount('#app')
```

## 2. Sequence Diagram — Người dùng chụp ảnh & share

Luồng user chụp ảnh qua `CameraController` (tự động xin quyền qua `PermissionController`), sau đó share ảnh qua `ShareController`.

```mermaid
sequenceDiagram
    actor User
    participant Vue as Vue Component
    participant ALF as ALF
    participant Cam as CameraController
    participant Perm as PermissionController
    participant Share as ShareController

    User->>Vue: Tap "Chụp & Share"
    Vue->>ALF: ALF.Camera.Take()
    ALF->>Cam: Take()

    Cam->>Perm: RequestPermission('camera')
    Perm-->>Cam: granted

    Cam->>Cam: Capacitor.Plugins.Camera.getPhoto()
    Cam-->>ALF: base64 image

    ALF-->>Vue: imageData

    Vue->>ALF: ALF.Share.ShareImage(imageData)
    ALF->>Share: ShareImage()
    Share->>Share: write temp file + Share.share()
    Share-->>ALF: ok
    ALF-->>Vue: shared
    Vue-->>User: thông báo thành công
```

## 3. Sequence Diagram — Hiển thị quảng cáo Banner

Luồng hiển thị và ẩn banner ad. AdController đọc ad unit ID từ ConfigManager.

```mermaid
sequenceDiagram
    actor User
    participant Vue as Vue Component
    participant ALF as ALF
    participant Config as ConfigManager
    participant Ads as AdController

    Note over Config: config đã được set <br/>ở initSDK(config)

    User->>Vue: Mở màn hình có banner
    Vue->>ALF: ALF.Ads.InitBannerAd()
    ALF->>Ads: InitBannerAd()

    Ads->>Config: get('keys.applovin.android.banner')
    Config-->>Ads: adUnitId

    Ads->>Ads: applovin.createBanner(adUnitId, position)
    Ads->>Ads: applovin.showBanner(adUnitId)
    Ads-->>ALF: ok
    ALF-->>Vue: done

    User->>Vue: Chuyển màn hình
    Vue->>ALF: ALF.Ads.HideBannerAd()
    ALF->>Ads: HideBannerAd()
    Ads->>Ads: applovin.hideBanner(adUnitId)
    Ads-->>ALF: ok
```

## 4. Sequence Diagram — Xem rewarded video

Luồng load và hiển thị rewarded video, dùng settings.dev để quyết định debug.

```mermaid
sequenceDiagram
    actor User
    participant Vue as Vue Component
    participant ALF as ALF
    participant Config as ConfigManager
    participant Ads as AdController

    User->>Vue: Tap "Xem video nhận thưởng"
    Vue->>ALF: ALF.Ads.LoadRewardedVideo()
    ALF->>Ads: LoadRewardedVideo()

    Ads->>Config: get('keys.applovin.android.rewarded')
    Config-->>Ads: rewardedAdUnitId

    Ads->>Ads: applovin.loadRewardedAd(adUnitId)
    Ads-->>ALF: ok
    ALF-->>Vue: loaded

    User->>Vue: Tap "Phát video"
    Vue->>ALF: ALF.Ads.ShowRewardedVideo(onReward)
    ALF->>Ads: ShowRewardedVideo(onReward)

    Ads->>Ads: applovin.isRewardedAdReady(adUnitId)
    alt Ad ready
        Ads->>Ads: applovin.showRewardedAd(adUnitId)
        Ads-->>User: hiển thị video
        User->>Ads: xem xong + nhận thưởng
        Ads->>Ads: gọi onReward callback
        Ads-->>ALF: reward granted
        ALF-->>Vue: thông báo thành công
    else Ad chưa ready
        Ads->>Ads: load lại rewarded ad
        Ads-->>ALF: retry
    end
```

## 5. Sequence Diagram — Firebase Remote Config

Luồng lấy feature flag từ Firebase để quyết định UI.

```mermaid
sequenceDiagram
    participant Vue as Vue Component
    participant ALF as ALF
    participant Firebase as FirebaseController

    Note over Firebase: Đã init ở initSDK()

    Vue->>ALF: ALF.Firebase.GetRemoteValue('show_new_feature')
    ALF->>Firebase: GetRemoteValue('show_new_feature')

    Firebase->>Firebase: kiểm tra cache trong session
    alt Có cache
        Firebase-->>ALF: giá trị từ cache
    else Không cache
        Firebase->>Firebase: FirebaseRemoteConfig.getValue({ key })
        Firebase->>Firebase: parse + cache lại
        Firebase-->>ALF: giá trị từ Firebase
    end

    ALF-->>Vue: true / false

    Vue->>Vue: quyết định hiển thị UI theo flag
```

## 6. Sequence Diagram — ConfigConverter: từ JSON đến initSDK

Luồng chuyển file config.json của repo thành object Config và gọi initSDK.

```mermaid
sequenceDiagram
    participant main as main.ts
    participant Conv as ConfigConverter
    participant init as initSDK(config)
    participant Config as ConfigManager

    main->>Conv: convert(jsonRaw, fieldMappings)
    Note over Conv: map field theo mappings<br/>merge với defaults
    Conv-->>main: config (Object)

    main->>init: await initSDK(config)
    init->>Config: set(config)
    Note over Config: lưu settings + keys<br/>trong memory
    Config-->>init: ready
    init-->>main: done

    Note over Config: controller đọc:<br/>get('keys.applovin')<br/>get('settings.dev')
```
