package alf.download;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.PermissionState;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(
    name = "ALFDownload",
    permissions = {
        @Permission(alias = "storage", strings = {Manifest.permission.WRITE_EXTERNAL_STORAGE})
    }
)
public class ALFDownloadPlugin extends Plugin {

    private static final String PROGRESS_EVENT = "OnDownloadProgress";

    private final ExecutorService executor = Executors.newCachedThreadPool();

    // ── Download to device (system Download folder) ──────────────────────

    @PluginMethod
    public void downloadToDevice(PluginCall call) {
        String url = call.getString("url");
        String targetPath = call.getString("targetPath");
        if (url == null || url.isEmpty() || targetPath == null || targetPath.isEmpty()) {
            call.reject("url and targetPath are required");
            return;
        }

        // Android 10+ uses scoped storage via MediaStore — no permission needed.
        // Android 9 and below writes to the public Download dir directly, which
        // requires the WRITE_EXTERNAL_STORAGE runtime permission.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
            && getPermissionState("storage") != PermissionState.GRANTED) {
            requestPermissionForAlias("storage", call, "storagePermissionCallback");
            return;
        }

        executor.execute(() -> {
            try {
                String savedPath = downloadToDeviceInternal(call, url, targetPath);
                JSObject ret = new JSObject();
                ret.put("path", savedPath);
                call.resolve(ret);
            } catch (Exception e) {
                call.reject("Download failed: " + e.getMessage(), e);
            }
        });
    }

    @PermissionCallback
    private void storagePermissionCallback(PluginCall call) {
        if (getPermissionState("storage") != PermissionState.GRANTED) {
            call.reject("WRITE_EXTERNAL_STORAGE permission denied");
            return;
        }
        String url = call.getString("url");
        String targetPath = call.getString("targetPath");
        executor.execute(() -> {
            try {
                String savedPath = downloadToDeviceInternal(call, url, targetPath);
                JSObject ret = new JSObject();
                ret.put("path", savedPath);
                call.resolve(ret);
            } catch (Exception e) {
                call.reject("Download failed: " + e.getMessage(), e);
            }
        });
    }

    private String downloadToDeviceInternal(PluginCall call, String url, String targetPath)
        throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Scoped storage: insert via MediaStore.Downloads, no permission required.
            String fileName = new File(targetPath).getName();
            if (fileName.isEmpty()) {
                throw new IOException("targetPath must end with a file name");
            }
            String parent = new File(targetPath).getParent();
            String relativePath = Environment.DIRECTORY_DOWNLOADS;
            if (parent != null && !parent.isEmpty() && !".".equals(parent)) {
                relativePath += "/" + parent;
            }

            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath);

            ContentResolver resolver = getContext().getContentResolver();
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) {
                throw new IOException("Failed to create MediaStore entry");
            }

            OutputStream out = resolver.openOutputStream(uri);
            if (out == null) {
                throw new IOException("Failed to open MediaStore output stream");
            }
            try {
                streamDownload(url, out, call);
            } finally {
                out.close();
            }
            return "Download/" + targetPath;
        }

        // Android 9 and below — direct write into the public Download folder.
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File target = new File(dir, targetPath);
        File parentDir = target.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            if (!parentDir.mkdirs()) {
                throw new IOException("Failed to create directory: " + parentDir.getAbsolutePath());
            }
        }
        try (OutputStream out = new FileOutputStream(target)) {
            streamDownload(url, out, call);
        }
        return target.getAbsolutePath();
    }

    // ── Download to app private storage ──────────────────────────────────

    @PluginMethod
    public void downloadToApp(PluginCall call) {
        String url = call.getString("url");
        String relativePath = call.getString("relativePath");
        if (url == null || url.isEmpty() || relativePath == null || relativePath.isEmpty()) {
            call.reject("url and relativePath are required");
            return;
        }

        File base = getContext().getFilesDir();
        File target;
        try {
            target = resolveWithin(base, relativePath);
        } catch (IOException e) {
            call.reject(e.getMessage());
            return;
        }

        executor.execute(() -> {
            try {
                File parent = target.getParentFile();
                if (parent != null && !parent.exists() && !parent.mkdirs()) {
                    throw new IOException("Failed to create directory: " + parent.getAbsolutePath());
                }
                try (OutputStream out = new FileOutputStream(target)) {
                    streamDownload(url, out, call);
                }
                JSObject ret = new JSObject();
                ret.put("path", target.getAbsolutePath());
                call.resolve(ret);
            } catch (Exception e) {
                call.reject("Download failed: " + e.getMessage(), e);
            }
        });
    }

    // ── App storage helpers ──────────────────────────────────────────────

    @PluginMethod
    public void getAppPath(PluginCall call) {
        String relativePath = call.getString("relativePath");
        if (relativePath == null || relativePath.isEmpty()) {
            call.reject("relativePath is required");
            return;
        }
        try {
            File resolved = resolveWithin(getContext().getFilesDir(), relativePath);
            JSObject ret = new JSObject();
            ret.put("path", resolved.getAbsolutePath());
            call.resolve(ret);
        } catch (IOException e) {
            call.reject(e.getMessage());
        }
    }

    @PluginMethod
    public void isAppFileExists(PluginCall call) {
        String relativePath = call.getString("relativePath");
        if (relativePath == null || relativePath.isEmpty()) {
            call.reject("relativePath is required");
            return;
        }
        try {
            File resolved = resolveWithin(getContext().getFilesDir(), relativePath);
            JSObject ret = new JSObject();
            ret.put("exists", resolved.exists() && resolved.isFile());
            call.resolve(ret);
        } catch (IOException e) {
            call.reject(e.getMessage());
        }
    }

    /**
     * Resolve a relative path inside {@code base}, rejecting paths that would
     * escape it (e.g. via ".." segments).
     */
    private File resolveWithin(File base, String relativePath) throws IOException {
        File resolved = new File(base, relativePath);
        String basePath = base.getCanonicalPath();
        String resolvedPath = resolved.getCanonicalPath();
        if (!resolvedPath.startsWith(basePath + File.separator) && !resolvedPath.equals(basePath)) {
            throw new IOException("Path escapes app storage: " + relativePath);
        }
        return resolved;
    }

    // ── Shared download engine ───────────────────────────────────────────

    private void streamDownload(String urlString, OutputStream out, PluginCall call)
        throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setConnectTimeout(15_000);
        conn.setReadTimeout(15_000);
        conn.setRequestMethod("GET");

        int code = conn.getResponseCode();
        if (code >= 400) {
            conn.disconnect();
            throw new IOException("HTTP " + code);
        }

        long total = conn.getContentLengthLong();
        InputStream in = conn.getInputStream();
        byte[] buffer = new byte[8 * 1024];
        long received = 0;
        int read;
        try {
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
                received += read;
                emitProgress(urlString, received, total);
            }
        } finally {
            try {
                in.close();
            } catch (IOException ignored) {
            }
            conn.disconnect();
        }
    }

    private void emitProgress(String url, long received, long total) {
        JSObject data = new JSObject();
        data.put("url", url);
        data.put("receivedBytes", received);
        data.put("totalBytes", total);
        data.put("progress", total > 0 ? (double) received / total : 0.0);
        notifyListeners(PROGRESS_EVENT, data);
    }

    @Override
    public void handleOnDestroy() {
        executor.shutdownNow();
        super.handleOnDestroy();
    }
}
