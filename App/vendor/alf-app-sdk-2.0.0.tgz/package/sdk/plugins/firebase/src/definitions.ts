/** Event params as Firebase accepts them. Booleans arrive as "true"/"false". */
export interface FirebaseEventParams {
  [key: string]: string | number | boolean
}

export interface FirebaseStatusResult {
  /** False when the host app has no google-services.json (no FirebaseApp). */
  available: boolean
}

export interface ALFFirebasePlugin {
  /** Whether Firebase started in this app. */
  getStatus(): Promise<FirebaseStatusResult>

  /** Turn Analytics collection on or off. Persists across launches. */
  setCollectionEnabled(options: { enabled: boolean }): Promise<void>

  logEvent(options: { name: string; params?: FirebaseEventParams }): Promise<void>

  /** Pass null to clear. */
  setUserId(options: { userId: string | null }): Promise<void>

  /** Pass a null value to clear the property. */
  setUserProperty(options: { name: string; value: string | null }): Promise<void>
}
