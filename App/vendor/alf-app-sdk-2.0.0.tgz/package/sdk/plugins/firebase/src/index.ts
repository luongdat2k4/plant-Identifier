import { registerPlugin } from '@capacitor/core'
import type { ALFFirebasePlugin } from './definitions'

const ALFFirebase = registerPlugin<ALFFirebasePlugin>('ALFFirebase', {
  web: () => import('./web').then((m) => new m.ALFFirebaseWeb()),
})

export * from './definitions'
export { ALFFirebase }
