import { registerPlugin } from '@capacitor/core'
import type { ALFDownloadPlugin } from './definitions'

const ALFDownload = registerPlugin<ALFDownloadPlugin>('ALFDownload', {
  web: () => import('./web').then((m) => new m.ALFDownloadWeb()),
})

export * from './definitions'
export { ALFDownload }
