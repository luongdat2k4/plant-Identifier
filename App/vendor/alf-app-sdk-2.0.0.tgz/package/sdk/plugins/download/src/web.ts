import type {
  ALFDownloadPlugin,
  DownloadResult,
  DownloadToDeviceOptions,
  DownloadToAppOptions,
  ExistsResult,
  PluginListenerHandle,
  DownloadProgressEvent,
} from './definitions'

function triggerBrowserDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = filename
  document.body.appendChild(anchor)
  anchor.click()
  anchor.remove()
  setTimeout(() => URL.revokeObjectURL(url), 10_000)
}

function filenameFromPath(path: string): string {
  const parts = path.split(/[\\/]/)
  return parts[parts.length - 1] || 'download.bin'
}

export class ALFDownloadWeb implements ALFDownloadPlugin {
  private progressListeners: Array<(event: DownloadProgressEvent) => void> = []

  async downloadToDevice(options: DownloadToDeviceOptions): Promise<DownloadResult> {
    const response = await fetch(options.url)
    if (!response.ok) {
      throw new Error(`Download failed: HTTP ${response.status} ${response.statusText}`)
    }

    const total = Number(response.headers.get('Content-Length') || 0)
    let received = 0

    if (response.body) {
      const reader = response.body.getReader()
      const chunks: Uint8Array[] = []
      for (;;) {
        const { done, value } = await reader.read()
        if (done) break
        if (value) {
          chunks.push(value)
          received += value.byteLength
          this.emitProgress(options.url, received, total)
        }
      }
      triggerBrowserDownload(
        new Blob(chunks as unknown as BlobPart[]),
        filenameFromPath(options.targetPath),
      )
    } else {
      const blob = await response.blob()
      triggerBrowserDownload(blob, filenameFromPath(options.targetPath))
    }

    return { path: options.targetPath }
  }

  async downloadToApp(_options: DownloadToAppOptions): Promise<DownloadResult> {
    throw new Error('[ALFDownload] downloadToApp is not supported on web')
  }

  async getAppPath(): Promise<DownloadResult> {
    throw new Error('[ALFDownload] getAppPath is not supported on web')
  }

  async isAppFileExists(): Promise<ExistsResult> {
    throw new Error('[ALFDownload] isAppFileExists is not supported on web')
  }

  async addListener(
    eventName: string,
    listenerFunc: (event: DownloadProgressEvent) => void,
  ): Promise<PluginListenerHandle> {
    if (eventName === 'OnDownloadProgress') {
      this.progressListeners.push(listenerFunc)
      return {
        remove: () => {
          const index = this.progressListeners.indexOf(listenerFunc)
          if (index >= 0) this.progressListeners.splice(index, 1)
        },
      }
    }
    return { remove: () => {} }
  }

  async removeAllListeners(): Promise<void> {
    this.progressListeners = []
  }

  private emitProgress(url: string, receivedBytes: number, totalBytes: number): void {
    const event: DownloadProgressEvent = {
      url,
      receivedBytes,
      totalBytes,
      progress: totalBytes > 0 ? Math.min(receivedBytes / totalBytes, 1) : 0,
    }
    for (const listener of this.progressListeners) {
      try {
        listener(event)
      } catch (e) {
        console.error('[ALFDownload] progress listener error:', e)
      }
    }
  }
}
