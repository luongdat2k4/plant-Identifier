/**
 * ALF Download Capacitor plugin — merged into the ALF SDK.
 *
 * Native code lives in ./android and ./ios. Provides streaming HTTP downloads
 * straight to disk (no base64 round-trip through the WebView), so it's safe for
 * large files such as on-device AI models.
 */
export * from './src'
