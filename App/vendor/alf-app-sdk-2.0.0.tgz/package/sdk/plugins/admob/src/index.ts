import { registerPlugin } from '@capacitor/core'
import type { ALFAdMobPlugin } from './definitions'

const ALFAdMob = registerPlugin<ALFAdMobPlugin>('ALFAdMob', {
  web: () => import('./web').then((m) => new m.ALFAdMobWeb()),
})

export * from './definitions'
export { ALFAdMob }
