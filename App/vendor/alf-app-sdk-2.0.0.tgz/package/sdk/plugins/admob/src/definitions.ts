export interface InitializeOptions {
  appId: string
}

export interface InitializeResult {
  initialized: boolean
}

export interface AdUnitOptions {
  adUnitId: string
}

export interface IsReadyResult {
  ready: boolean
}

/** Banner anchor position in the app window. */
export type BannerPosition = 'TOP_CENTER' | 'BOTTOM_CENTER'

/**
 * Banner size for createBanner.
 * - `'ADAPTIVE'` — anchored adaptive banner that fills the screen width (default)
 * - fixed sizes — standard AdMob banner sizes
 * - `{ width, height }` — custom size in dp
 */
export type BannerSize =
  | 'ADAPTIVE'
  | 'BANNER'
  | 'LARGE_BANNER'
  | 'MEDIUM_RECTANGLE'
  | 'FULL_BANNER'
  | 'LEADERBOARD'
  | { width: number; height: number }

/** Collapsible placement. Only `top`/`bottom` are supported by AdMob. */
export type BannerCollapsible = 'top' | 'bottom'

export interface BannerOptions {
  adUnitId: string
  position?: BannerPosition
  size?: BannerSize
  collapsible?: BannerCollapsible
}

/** Size of the loaded banner, in dp. */
export interface BannerSizeResult {
  width: number
  height: number
}

export interface RewardEvent {
  adUnitId: string
  amount?: number
}

/**
 * Native ad asset data returned to JavaScript.
 *
 * For **preview and debugging only**. Rendering these assets yourself (in HTML,
 * or any view the Google Mobile Ads SDK does not own) records no impression,
 * makes clicks inert, and violates the AdMob native ad policy. Use
 * `showNativeAd()` to display a native ad for real.
 */
export interface NativeAdData {
  adUnitId: string
  /** Slot the ad was loaded into (Android; equals `adUnitId` without a slot). */
  slot?: string
  headline: string
  body: string
  callToAction: string
  iconUrl: string
  imageUrl: string
  /** True when the creative's media asset is a video rather than an image. */
  hasVideoContent: boolean
  /**
   * Width / height of the media asset (image or video), or `0` when unknown.
   * Size the rect-mode placeholder from this so a video is not letterboxed.
   */
  mediaAspectRatio: number
  /** Video length in seconds; `0` for image creatives or when unknown. */
  videoDuration: number
  /**
   * True when the SDK granted `video.customControlsRequested` for this ad — the
   * app then owns play/pause/mute through `playNativeAdVideo()` and friends,
   * and the SDK draws no controls of its own.
   */
  videoCustomControlsEnabled: boolean
  price: string
  store: string
  starRating: number
  advertiser: string
}

/**
 * How a native video ad plays. Applied when the ad is **loaded** — the SDK
 * bakes these into the ad request, so they cannot change for an ad already in
 * the cache. Destroy the ad and load again to apply different options.
 */
export interface NativeAdVideoOptions {
  /** Start the video with sound off. Defaults to `true`, as AdMob recommends. */
  startMuted?: boolean
  /**
   * Ask for app-drawn controls: the SDK hides its own and the app drives the
   * video with `playNativeAdVideo()` / `pauseNativeAdVideo()` /
   * `muteNativeAdVideo()`. Only allowlisted publishers get it — check
   * `NativeAdData.videoCustomControlsEnabled` to see whether it was granted.
   */
  customControlsRequested?: boolean
  /** Let a tap on the video open it full screen instead of the advertiser. */
  clickToExpandRequested?: boolean
}

/**
 * Preferred shape of the media asset. `'any'` (default) takes whatever the
 * creative has; the others narrow the fill to creatives of that shape.
 */
export type NativeAdMediaAspectRatio = 'any' | 'landscape' | 'portrait' | 'square'

/** Options that shape the ad request — only used when a load actually happens. */
export interface NativeAdRequestOptions {
  video?: NativeAdVideoOptions
  mediaAspectRatio?: NativeAdMediaAspectRatio
}

/**
 * Where a native ad lives. Native ads are kept per **slot**, so the same ad unit
 * can be on screen twice at once (e.g. a bottom native and an MREC-sized native
 * sharing one Meta bidding unit), and one slot can walk a fallback chain of
 * units. Without `slot` the ad unit is its own slot — the pre-1.4 behaviour.
 */
export interface NativeAdSlotOptions {
  /** Free-form id chosen by the app, e.g. `'bottom'`, `'mrec'`. Defaults to `adUnitId`. */
  slot?: string
}

/**
 * Which native ad a call acts on: `slot`, or `adUnitId` when there is no slot.
 * `isNativeAdReady` with both checks the slot holds an ad of that unit.
 */
export interface NativeAdTargetOptions extends NativeAdSlotOptions {
  adUnitId?: string
}

export interface LoadNativeAdOptions extends NativeAdRequestOptions, NativeAdSlotOptions {
  adUnitId: string
}

/**
 * Built-in native ad layout preset.
 * - `small` — icon + headline + one-line body + CTA (~80dp tall)
 * - `medium` — icon + headline + advertiser + rating + body + media + CTA (~300dp tall)
 * - `mrec` — icon + headline + advertiser + media + CTA, no body (~228dp tall):
 *   fits a 300x250dp spot, so an in-page native and an MREC can share it.
 *   Android; iOS falls back to `medium`.
 */
export type NativeAdTemplate = 'small' | 'medium' | 'mrec'

/**
 * Where to place the native ad, in CSS pixels relative to the web view's
 * viewport — normally taken straight from `element.getBoundingClientRect()`.
 */
export interface NativeAdRect {
  x: number
  y: number
  width: number
  height: number
}

/** Colors applied to the built-in native ad templates. CSS hex strings, e.g. `#FFFFFF`. */
export interface NativeAdStyle {
  background?: string
  textColor?: string
  secondaryTextColor?: string
  ctaBackground?: string
  ctaTextColor?: string
  /** Corner radius in dp. */
  cornerRadius?: number
}

/**
 * `video` / `mediaAspectRatio` only apply when this call has to load the ad
 * itself; an ad already cached for the unit keeps the options it was loaded with.
 */
export interface ShowNativeAdOptions extends NativeAdRequestOptions, NativeAdSlotOptions {
  /** Unit to show. A slot holding an ad of another unit drops it and loads this one. */
  adUnitId: string
  /** Layout preset. Defaults to `'medium'`. */
  template?: NativeAdTemplate
  /** Anchor the ad to the top or bottom of the screen. Ignored when `rect` is set. */
  position?: BannerPosition
  /** Ad height in dp for anchor mode. Defaults to the template's natural height. */
  height?: number
  /** Position the ad over a specific area of the page. Takes precedence over `position`. */
  rect?: NativeAdRect
  style?: NativeAdStyle
  /**
   * Controls drawn natively ABOVE the ad — rect mode only. Lets an app run the
   * ad full screen as an interstitial: markup in the web view sits under the
   * ad view and can never be tapped. Change it later with `updateNativeAdOverlay()`.
   */
  overlay?: NativeAdOverlay
}

/**
 * A label and a close button the plugin draws over the top of a rect-mode
 * native ad.
 *
 * - The overlay sits below any system bar (status bar, notch) the rect reaches
 *   under; the empty area between the label and the button passes touches to
 *   the ad.
 * - The template's content is pushed down below the overlay and up off the
 *   navigation bar, so the "Ad" badge, assets and CTA stay uncovered (AdMob
 *   policy). Only the ad's background fills the rect edge to edge.
 * - A tap on the enabled button fires `OnNativeAdOverlayCloseEvent`; the plugin
 *   does not close anything itself — the app decides, then destroys the ad.
 */
export interface NativeAdOverlay {
  /** Text on the close button — e.g. a countdown `'5'` while locked. Defaults to `'✕'`. */
  closeText?: string
  /**
   * Whether a tap fires `OnNativeAdOverlayCloseEvent`. A disabled button still
   * swallows the tap so it never lands on the ad. Defaults to `true`.
   */
  closeEnabled?: boolean
  /** Pill label at the top-left, e.g. `'SPONSORED'`. Omit or `''` for none. */
  label?: string
  /** Close button diameter in dp/pt. Defaults to `40`. */
  size?: number
}

export interface UpdateNativeAdRectOptions extends NativeAdTargetOptions {
  rect: NativeAdRect
}

export interface UpdateNativeAdOverlayOptions extends NativeAdTargetOptions {
  overlay: NativeAdOverlay
}

/**
 * Something happened to the native ad of this unit. `slot` names where it
 * lives (Android; equals `adUnitId` when shown without a slot, absent on iOS).
 */
export interface NativeAdUnitEvent {
  adUnitId: string
  slot?: string
}

export interface NativeAdErrorEvent extends NativeAdUnitEvent {
  error: string
}

/**
 * What the video player of a native ad just did.
 *
 * `start` is Android only — iOS reports the first frame as `play`.
 */
export type NativeAdVideoState = 'start' | 'play' | 'pause' | 'end' | 'mute' | 'unmute'

export interface NativeAdVideoEvent extends NativeAdUnitEvent {
  state: NativeAdVideoState
}

export interface MuteNativeAdVideoOptions extends NativeAdTargetOptions {
  muted: boolean
}

/**
 * How precise the value reported by `OnNativeAdPaidEvent` is.
 * Mirrors AdMob's precision type on both platforms.
 */
export type AdValuePrecision = 'unknown' | 'estimated' | 'publisherProvided' | 'precise'

/**
 * Revenue earned by one native ad impression — forward this to your attribution
 * SDK (AppsFlyer, Firebase) to keep ROAS complete.
 */
export interface NativeAdPaidEvent {
  adUnitId: string
  /** Native ads only — the slot the paid ad lives in (Android). */
  slot?: string
  /**
   * Value in whole units of `currencyCode` (e.g. `0.0031` USD). Android reports
   * micros natively; the plugin divides by 1,000,000 so both platforms agree.
   */
  value: number
  /** ISO-4217 code, e.g. `'USD'`. */
  currencyCode: string
  precision: AdValuePrecision
}

/** An event about one ad unit's full-screen ad. */
export interface AdUnitEvent {
  adUnitId: string
}

export interface AdUnitErrorEvent extends AdUnitEvent {
  message: string
}

export interface PluginListenerHandle {
  remove: () => void
}

export interface ALFAdMobPlugin {
  // Init
  initialize(options: InitializeOptions): Promise<InitializeResult>

  // Banner
  createBanner(options: BannerOptions): Promise<BannerSizeResult>
  showBanner(options: AdUnitOptions): Promise<void>
  hideBanner(options: AdUnitOptions): Promise<void>
  destroyBanner(options: AdUnitOptions): Promise<void>

  // Interstitial — each ad unit is cached separately, so several units can be
  // loaded side by side and tried in turn.
  loadInterstitial(options: AdUnitOptions): Promise<void>
  /** `true` while a loaded ad waits; turns `false` as soon as it is shown. */
  isInterstitialReady(options: AdUnitOptions): Promise<IsReadyResult>
  /**
   * Resolves once the ad was handed the screen, not when it closes — follow
   * `OnInterstitialAdShowedEvent` / `FailedToShow` / `Dismissed` for that.
   * The ad is single-use: it leaves the cache here, load again for the next one.
   */
  showInterstitial(options: AdUnitOptions): Promise<void>

  // Rewarded
  loadRewardedAd(options: AdUnitOptions): Promise<void>
  isRewardedAdReady(options: AdUnitOptions): Promise<IsReadyResult>
  showRewardedAd(options: AdUnitOptions): Promise<void>

  // Open App
  loadOpenAppAd(options: AdUnitOptions): Promise<void>
  isOpenAppAdReady(options: AdUnitOptions): Promise<IsReadyResult>
  showOpenAppAd(options: AdUnitOptions): Promise<void>

  // Native
  /**
   * Load a native ad and return its assets.
   *
   * @deprecated for display purposes. The returned assets are for preview and
   * debugging only — rendering them yourself records no impression and leaves
   * clicks inert. Call `showNativeAd()` to display the ad.
   */
  loadNativeAd(options: LoadNativeAdOptions): Promise<NativeAdData>
  isNativeAdReady(options: NativeAdTargetOptions): Promise<IsReadyResult>

  /**
   * Render the loaded native ad in a real `NativeAdView` overlaid on the web
   * view. Loads the ad first if none is cached for this unit. This is the only
   * path that records impressions and makes the call-to-action clickable.
   */
  showNativeAd(options: ShowNativeAdOptions): Promise<void>
  /** Move an ad shown in rect mode — call on scroll and resize. */
  updateNativeAdRect(options: UpdateNativeAdRectOptions): Promise<void>
  /** Change the overlay of a rect-mode ad (adds one if it has none). */
  updateNativeAdOverlay(options: UpdateNativeAdOverlayOptions): Promise<void>
  /**
   * Take the overlay off a rect-mode ad and give its content back the room it
   * had. No-op when the ad has none; `showNativeAd({ overlay })` or
   * `updateNativeAdOverlay()` puts one back.
   */
  removeNativeAdOverlay(options: NativeAdTargetOptions): Promise<void>
  hideNativeAd(options: NativeAdTargetOptions): Promise<void>
  /** Also cancels a load still in flight for the slot. */
  destroyNativeAd(options: NativeAdTargetOptions): Promise<void>

  // Native video — reject when the unit has no ad or its media is not a video.
  // While the SDK's own controls are in charge (custom controls not granted)
  // the player may ignore these; see `NativeAdData.videoCustomControlsEnabled`.
  playNativeAdVideo(options: NativeAdTargetOptions): Promise<void>
  pauseNativeAdVideo(options: NativeAdTargetOptions): Promise<void>
  muteNativeAdVideo(options: MuteNativeAdVideoOptions): Promise<void>

  /**
   * @deprecated Always rejects. Clicks are registered by the SDK through the
   * `NativeAdView` that `showNativeAd()` builds; they cannot be reported manually.
   */
  reportNativeAdClick(options: AdUnitOptions): Promise<void>

  // Events
  /** An interstitial took over the screen. */
  addListener(eventName: 'OnInterstitialAdShowedEvent', listener: (event: AdUnitEvent) => void): Promise<PluginListenerHandle>
  /** `showInterstitial()` was accepted but the ad never appeared. */
  addListener(eventName: 'OnInterstitialAdFailedToShowEvent', listener: (event: AdUnitErrorEvent) => void): Promise<PluginListenerHandle>
  /** The user closed the interstitial; the app may move on. */
  addListener(eventName: 'OnInterstitialAdDismissedEvent', listener: (event: AdUnitEvent) => void): Promise<PluginListenerHandle>
  /** Revenue for one interstitial impression — same shape as `OnNativeAdPaidEvent`. */
  addListener(eventName: 'OnInterstitialAdPaidEvent', listener: (event: NativeAdPaidEvent) => void): Promise<PluginListenerHandle>
  addListener(eventName: 'OnRewardedAdReceivedRewardEvent', listener: (event: RewardEvent) => void): Promise<PluginListenerHandle>
  addListener(eventName: 'OnRewardedAdSkippedEvent', listener: (event: { adUnitId: string }) => void): Promise<PluginListenerHandle>
  /** The user closed the rewarded ad, rewarded or not — fires after the reward / skip event. */
  addListener(eventName: 'OnRewardedAdDismissedEvent', listener: (event: AdUnitEvent) => void): Promise<PluginListenerHandle>
  /** The user closed the app open ad. */
  addListener(eventName: 'OnOpenAppAdDismissedEvent', listener: (event: AdUnitEvent) => void): Promise<PluginListenerHandle>

  // Native ad — emitted by the SDK's own callbacks, so they report what really
  // happened to the NativeAdView rather than what the JS call asked for.
  /** A native ad finished loading. Carries the same assets as `loadNativeAd()`. */
  addListener(eventName: 'OnNativeAdLoadedEvent', listener: (event: NativeAdData) => void): Promise<PluginListenerHandle>
  addListener(eventName: 'OnNativeAdFailedToLoadEvent', listener: (event: NativeAdErrorEvent) => void): Promise<PluginListenerHandle>
  /**
   * The ad was actually seen, as judged by the Google Mobile Ads SDK. This is
   * the only reliable signal that the ad is on screen — `showNativeAd()`
   * resolving only means the view was attached.
   */
  addListener(eventName: 'OnNativeAdImpressionEvent', listener: (event: NativeAdUnitEvent) => void): Promise<PluginListenerHandle>
  /** The user clicked the ad and is leaving the app for the advertiser. */
  addListener(eventName: 'OnNativeAdClickedEvent', listener: (event: NativeAdUnitEvent) => void): Promise<PluginListenerHandle>
  /** Revenue for one impression — forward to your attribution SDK. */
  addListener(eventName: 'OnNativeAdPaidEvent', listener: (event: NativeAdPaidEvent) => void): Promise<PluginListenerHandle>
  /** The native ad's video started, played, paused, ended, or changed mute. */
  addListener(eventName: 'OnNativeAdVideoEvent', listener: (event: NativeAdVideoEvent) => void): Promise<PluginListenerHandle>
  /** The user tapped the enabled close button of the ad's overlay. */
  addListener(eventName: 'OnNativeAdOverlayCloseEvent', listener: (event: NativeAdUnitEvent) => void): Promise<PluginListenerHandle>
  removeAllListeners(): Promise<void>
}
