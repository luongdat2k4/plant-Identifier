/**
 * AppLovin MAX Capacitor plugin — merged into the ALF SDK.
 *
 * Native code lives in ./android and ./ios (wired up by the SDK root
 * package.json `capacitor` field during `cap sync`). This entry re-exports
 * the Capacitor plugin definitions and web impl.
 */
export * from './src'
