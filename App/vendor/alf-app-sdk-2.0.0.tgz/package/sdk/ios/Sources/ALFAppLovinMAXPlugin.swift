import Foundation
import Capacitor
import AppLovinSDK

@objc(ALFAppLovinMAXPlugin)
public class ALFAppLovinMAXPlugin: CAPPlugin {

    private var banners: [String: MAAdView] = [:]
    private var pendingBannerLoads: [String: CAPPluginCall] = [:]
    private var mrecs: [String: MAAdView] = [:]
    private var interstitials: [String: MAInterstitialAd] = [:]
    private var rewardedAds: [String: MARewardedAd] = [:]
    private var rewardListeners: [String: (MARewardedAd) -> Void] = [:]
    private var rewardedGranted: [String: Bool] = [:]
    private var appOpenAds: [String: MAAppOpenAd] = [:]

    // MARK: - Initialize

    @objc func initialize(_ call: CAPPluginCall) {
        guard let sdkKey = call.getString("sdkKey"), !sdkKey.isEmpty else {
            call.reject("sdkKey is required")
            return
        }

        let settings = ALSdkSettings()
        let sdk = ALSdk.initialize(sdkKey: sdkKey, settings: settings) { configuration in
            call.resolve([
                "initialized": true
            ])
        }
    }

    @objc func isTablet(_ call: CAPPluginCall) {
        let isTablet = UIDevice.current.userInterfaceIdiom == .pad
        call.resolve([
            "isTablet": isTablet
        ])
    }

    // MARK: - Banner

    @objc func createBanner(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), !adUnitId.isEmpty else {
            call.reject("adUnitId is required")
            return
        }

        let position = call.getString("position") ?? "BOTTOM_CENTER"

        // Remove existing banner if any
        if let existing = banners[adUnitId] {
            existing.removeFromSuperview()
            banners.removeValue(forKey: adUnitId)
        }

        let adView = MAAdView(adUnitIdentifier: adUnitId)
        adView.delegate = self
        adView.backgroundColor = .black

        guard let rootView = self.bridge?.viewController?.view else {
            call.reject("No root view controller")
            return
        }

        rootView.addSubview(adView)
        adView.translatesAutoresizingMaskIntoConstraints = false

        let isBottom = position == "BOTTOM_CENTER"

        NSLayoutConstraint.activate([
            adView.leadingAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.leadingAnchor),
            adView.trailingAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.trailingAnchor),
            isBottom
                ? adView.bottomAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.bottomAnchor)
                : adView.topAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.topAnchor)
        ])

        // Set fixed height based on device type
        let height: CGFloat = UIDevice.current.userInterfaceIdiom == .pad ? 90 : 50
        adView.heightAnchor.constraint(equalToConstant: height).isActive = true

        // Start loading
        adView.loadAd()

        banners[adUnitId] = adView
        pendingBannerLoads[adUnitId] = call
    }

    @objc func showBanner(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), let adView = banners[adUnitId] else {
            call.reject("Banner not found for adUnitId")
            return
        }
        adView.isHidden = false
        call.resolve()
    }

    @objc func hideBanner(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), let adView = banners[adUnitId] else {
            call.reject("Banner not found for adUnitId")
            return
        }
        adView.isHidden = true
        call.resolve()
    }

    @objc func destroyBanner(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), let adView = banners[adUnitId] else {
            call.reject("Banner not found for adUnitId")
            return
        }
        adView.removeFromSuperview()
        banners.removeValue(forKey: adUnitId)
        call.resolve()
    }

    // MARK: - MREC

    @objc func createMRec(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), !adUnitId.isEmpty else {
            call.reject("adUnitId is required")
            return
        }

        let position = call.getString("position") ?? "TOP_CENTER"

        // Remove existing MREC if any
        if let existing = mrecs[adUnitId] {
            existing.removeFromSuperview()
            mrecs.removeValue(forKey: adUnitId)
        }

        let adView = MAAdView(adUnitIdentifier: adUnitId, adFormat: .mrec)
        adView.delegate = self
        adView.backgroundColor = .black

        guard let rootView = self.bridge?.viewController?.view else {
            call.reject("No root view controller")
            return
        }

        rootView.addSubview(adView)
        adView.translatesAutoresizingMaskIntoConstraints = false

        var constraints: [NSLayoutConstraint] = [
            adView.widthAnchor.constraint(equalToConstant: 300),
            adView.heightAnchor.constraint(equalToConstant: 250)
        ]

        switch position {
        case "TOP_LEFT", "BOTTOM_LEFT":
            constraints.append(adView.leadingAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.leadingAnchor))
        case "TOP_RIGHT", "BOTTOM_RIGHT":
            constraints.append(adView.trailingAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.trailingAnchor))
        default:
            constraints.append(adView.centerXAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.centerXAnchor))
        }

        switch position {
        case "TOP_LEFT", "TOP_CENTER", "TOP_RIGHT":
            constraints.append(adView.topAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.topAnchor))
        case "BOTTOM_LEFT", "BOTTOM_CENTER", "BOTTOM_RIGHT":
            constraints.append(adView.bottomAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.bottomAnchor))
        default:
            constraints.append(adView.centerYAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.centerYAnchor))
        }

        NSLayoutConstraint.activate(constraints)

        adView.loadAd()

        mrecs[adUnitId] = adView
        call.resolve()
    }

    @objc func showMRec(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), let adView = mrecs[adUnitId] else {
            call.reject("MREC not found for adUnitId")
            return
        }
        adView.isHidden = false
        call.resolve()
    }

    @objc func hideMRec(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), let adView = mrecs[adUnitId] else {
            call.reject("MREC not found for adUnitId")
            return
        }
        adView.isHidden = true
        call.resolve()
    }

    @objc func destroyMRec(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), let adView = mrecs[adUnitId] else {
            call.reject("MREC not found for adUnitId")
            return
        }
        adView.removeFromSuperview()
        mrecs.removeValue(forKey: adUnitId)
        call.resolve()
    }

    // MARK: - Interstitial

    @objc func loadInterstitial(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), !adUnitId.isEmpty else {
            call.reject("adUnitId is required")
            return
        }

        let interstitial = MAInterstitialAd(adUnitIdentifier: adUnitId)
        interstitial.delegate = self
        interstitials[adUnitId] = interstitial
        interstitial.load()

        call.resolve()
    }

    @objc func isInterstitialReady(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        let ready = interstitials[adUnitId]?.isReady ?? false
        call.resolve([
            "ready": ready
        ])
    }

    @objc func showInterstitial(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        guard let interstitial = interstitials[adUnitId], interstitial.isReady else {
            call.reject("Interstitial ad is not ready")
            return
        }

        interstitial.show()
        call.resolve()
    }

    // MARK: - Rewarded

    @objc func loadRewardedAd(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), !adUnitId.isEmpty else {
            call.reject("adUnitId is required")
            return
        }

        let rewarded = MARewardedAd.shared(withAdUnitIdentifier: adUnitId)
        rewarded.delegate = self
        rewardedAds[adUnitId] = rewarded
        rewarded.load()

        call.resolve()
    }

    @objc func isRewardedAdReady(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        let ready = rewardedAds[adUnitId]?.isReady ?? false
        call.resolve([
            "ready": ready
        ])
    }

    @objc func showRewardedAd(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        guard let rewarded = rewardedAds[adUnitId], rewarded.isReady else {
            call.reject("Rewarded ad is not ready")
            return
        }

        rewarded.show()
        call.resolve()
    }

    // MARK: - App Open

    @objc func loadAppOpenAd(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), !adUnitId.isEmpty else {
            call.reject("adUnitId is required")
            return
        }

        let appOpenAd = MAAppOpenAd(adUnitIdentifier: adUnitId)
        appOpenAd.delegate = self
        appOpenAds[adUnitId] = appOpenAd
        appOpenAd.load()

        call.resolve()
    }

    @objc func isAppOpenAdReady(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        let ready = appOpenAds[adUnitId]?.isReady ?? false
        call.resolve([
            "ready": ready
        ])
    }

    @objc func showAppOpenAd(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        guard let appOpenAd = appOpenAds[adUnitId], appOpenAd.isReady else {
            call.reject("App open ad is not ready")
            return
        }

        appOpenAd.show()
        call.resolve()
    }
}

// MARK: - MAAdViewAdDelegate

extension ALFAppLovinMAXPlugin: MAAdViewAdDelegate {
    public func didLoad(_ ad: MAAd) {
        if let call = pendingBannerLoads.removeValue(forKey: ad.adUnitIdentifier) {
            call.resolve()
        }
    }
    public func didFailToLoadAd(forAdUnitIdentifier adUnitIdentifier: String, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Failed to load ad for \(adUnitIdentifier): \(error.message)")
        if let call = pendingBannerLoads.removeValue(forKey: adUnitIdentifier) {
            call.reject("Banner failed to load (adUnitId=\(adUnitIdentifier), code=\(error.code)): \(error.message)")
        }
    }
    public func didDisplay(_ ad: MAAd) {}
    public func didHide(_ ad: MAAd) {}
    public func didClick(_ ad: MAAd) {}
    public func didFail(toDisplay ad: MAAd, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Failed to display ad: \(error.message)")
    }
}

// MARK: - MAInterstitialAdDelegate

extension ALFAppLovinMAXPlugin: MAInterstitialAdDelegate {
    public func didLoad(_ ad: MAAd) {}
    public func didFailToLoadAd(forAdUnitIdentifier adUnitIdentifier: String, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Interstitial failed to load for \(adUnitIdentifier): \(error.message)")
    }
    public func didDisplay(_ ad: MAAd) {}
    public func didHide(_ ad: MAAd) {
        notifyListeners("OnInterstitialAdHiddenEvent", data: [
            "adUnitId": ad.adUnitIdentifier
        ])
    }
    public func didClick(_ ad: MAAd) {}
    public func didFail(toDisplay ad: MAAd, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Interstitial failed to display: \(error.message)")
    }
}

// MARK: - MARewardedAdDelegate

extension ALFAppLovinMAXPlugin: MARewardedAdDelegate {
    public func didLoad(_ ad: MAAd) {
        rewardedGranted[ad.adUnitIdentifier] = false
    }
    public func didFailToLoadAd(forAdUnitIdentifier adUnitIdentifier: String, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Rewarded failed to load for \(adUnitIdentifier): \(error.message)")
    }
    public func didDisplay(_ ad: MAAd) {}
    public func didHide(_ ad: MAAd) {
        notifyListeners("OnRewardedAdHiddenEvent", data: [
            "adUnitId": ad.adUnitIdentifier
        ])

        if rewardedGranted[ad.adUnitIdentifier] != true {
            notifyListeners("OnRewardedAdSkippedEvent", data: [
                "adUnitId": ad.adUnitIdentifier
            ])
        }
    }
    public func didClick(_ ad: MAAd) {}
    public func didStartRewardedAd(for ad: MAAd) {
        NSLog("[ALFAppLovinMAX] Rewarded video started")
    }
    public func didCompleteRewardedVideo(for ad: MAAd) {
        NSLog("[ALFAppLovinMAX] Rewarded video completed")
    }
    public func didRewardUser(for ad: MAAd, with reward: MAReward) {
        rewardedGranted[ad.adUnitIdentifier] = true
        notifyListeners("OnRewardedAdReceivedRewardEvent", data: [
            "adUnitId": ad.adUnitIdentifier,
            "amount": reward.amount
        ])
    }
    public func didFail(toDisplay ad: MAAd, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Rewarded failed to display: \(error.message)")
    }
}

// MARK: - MAAppOpenAdDelegate

extension ALFAppLovinMAXPlugin: MAAppOpenAdDelegate {
    public func didLoad(_ ad: MAAd) {
        NSLog("[ALFAppLovinMAX] App open ad loaded for \(ad.adUnitIdentifier)")
    }
    public func didFailToLoadAd(forAdUnitIdentifier adUnitIdentifier: String, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] App open failed to load for \(adUnitIdentifier): \(error.message)")
    }
    public func didDisplay(_ ad: MAAd) {}
    public func didHide(_ ad: MAAd) {
        notifyListeners("OnAppOpenAdHiddenEvent", data: [
            "adUnitId": ad.adUnitIdentifier
        ])
    }
    public func didClick(_ ad: MAAd) {}
    public func didFail(toDisplay ad: MAAd, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] App open failed to display: \(error.message)")
    }
}
