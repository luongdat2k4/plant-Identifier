#import <Capacitor/Capacitor.h>

CAP_PLUGIN(ALFAdMobPlugin, "ALFAdMob",
  CAP_PLUGIN_METHOD(initialize, CAPPluginReturnPromise);

  CAP_PLUGIN_METHOD(loadInterstitial, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(isInterstitialReady, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(showInterstitial, CAPPluginReturnPromise);

  CAP_PLUGIN_METHOD(loadRewardedAd, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(isRewardedAdReady, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(showRewardedAd, CAPPluginReturnPromise);

  CAP_PLUGIN_METHOD(loadOpenAppAd, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(isOpenAppAdReady, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(showOpenAppAd, CAPPluginReturnPromise);

  CAP_PLUGIN_METHOD(loadNativeAd, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(isNativeAdReady, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(showNativeAd, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(updateNativeAdRect, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(updateNativeAdOverlay, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(removeNativeAdOverlay, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(hideNativeAd, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(destroyNativeAd, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(playNativeAdVideo, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(pauseNativeAdVideo, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(muteNativeAdVideo, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(reportNativeAdClick, CAPPluginReturnPromise);
)
