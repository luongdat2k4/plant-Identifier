import Foundation
import UIKit
import Capacitor
import GoogleMobileAds

/// Colors applied to the built-in native ad templates.
struct ALFNativeAdStyle {
  var background: UIColor = .systemBackground
  var textColor: UIColor = .label
  var secondaryTextColor: UIColor = .secondaryLabel
  var ctaBackground: UIColor = UIColor(red: 0.10, green: 0.45, blue: 0.91, alpha: 1)
  var ctaTextColor: UIColor = .white
  var cornerRadius: CGFloat = 0

  init(from style: JSObject?) {
    guard let style = style else { return }
    if let value = UIColor(alfHex: style["background"] as? String) { background = value }
    if let value = UIColor(alfHex: style["textColor"] as? String) { textColor = value }
    if let value = UIColor(alfHex: style["secondaryTextColor"] as? String) { secondaryTextColor = value }
    if let value = UIColor(alfHex: style["ctaBackground"] as? String) { ctaBackground = value }
    if let value = UIColor(alfHex: style["ctaTextColor"] as? String) { ctaTextColor = value }
    if let radius = style["cornerRadius"] as? NSNumber { cornerRadius = CGFloat(radius.doubleValue) }
  }
}

extension UIColor {
  /// Parse `#RGB`, `#RRGGBB` or `#AARRGGBB`, matching what Android's
  /// Color.parseColor accepts so both platforms take the same style values.
  convenience init?(alfHex hex: String?) {
    guard var raw = hex?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty else { return nil }
    if raw.hasPrefix("#") { raw.removeFirst() }

    var value: UInt64 = 0
    guard Scanner(string: raw).scanHexInt64(&value) else { return nil }

    let r, g, b, a: CGFloat
    switch raw.count {
    case 3:
      r = CGFloat((value >> 8) & 0xF) / 15
      g = CGFloat((value >> 4) & 0xF) / 15
      b = CGFloat(value & 0xF) / 15
      a = 1
    case 6:
      r = CGFloat((value >> 16) & 0xFF) / 255
      g = CGFloat((value >> 8) & 0xFF) / 255
      b = CGFloat(value & 0xFF) / 255
      a = 1
    case 8:
      a = CGFloat((value >> 24) & 0xFF) / 255
      r = CGFloat((value >> 16) & 0xFF) / 255
      g = CGFloat((value >> 8) & 0xFF) / 255
      b = CGFloat(value & 0xFF) / 255
    default:
      return nil
    }
    self.init(red: r, green: g, blue: b, alpha: a)
  }
}

/// Builds the `NativeAdView` that actually displays a native ad.
///
/// The view hierarchy matters: the Google Mobile Ads SDK records the impression
/// and takes over click handling only for asset views registered on a
/// `NativeAdView` whose `nativeAd` has been set. Drawing these assets anywhere
/// else — a web view included — shows something that looks like an ad but is
/// not one.
enum ALFNativeAdViewBuilder {

  /// Tag of the template's content view, so the overlay can pad it.
  static let contentTag = 0xA1F0

  static func make(nativeAd: NativeAd, template: String, style: ALFNativeAdStyle) -> NativeAdView {
    let adView = NativeAdView()
    adView.backgroundColor = style.background
    adView.layer.cornerRadius = style.cornerRadius
    adView.clipsToBounds = style.cornerRadius > 0

    let content = template == "small"
      ? makeSmall(nativeAd: nativeAd, style: style, adView: adView)
      : makeMedium(nativeAd: nativeAd, style: style, adView: adView)

    content.translatesAutoresizingMaskIntoConstraints = false
    content.tag = contentTag
    adView.addSubview(content)
    let inset: CGFloat = template == "small" ? 10 : 12
    NSLayoutConstraint.activate([
      content.leadingAnchor.constraint(equalTo: adView.leadingAnchor, constant: inset),
      content.trailingAnchor.constraint(equalTo: adView.trailingAnchor, constant: -inset),
      content.topAnchor.constraint(equalTo: adView.topAnchor, constant: inset),
      content.bottomAnchor.constraint(equalTo: adView.bottomAnchor, constant: -inset)
    ])

    // Registers the impression and wires up the clickable asset views.
    adView.nativeAd = nativeAd
    return adView
  }

  // ── Templates ─────────────────────────────────────
  private static func makeMedium(nativeAd: NativeAd, style: ALFNativeAdStyle, adView: NativeAdView) -> UIView {
    let stack = verticalStack(spacing: 8)

    // Header: icon + headline/advertiser/rating + "Ad" badge
    let header = UIStackView()
    header.axis = .horizontal
    header.spacing = 10
    header.alignment = .center

    if let icon = makeIcon(nativeAd: nativeAd, size: 48) {
      adView.iconView = icon
      header.addArrangedSubview(icon)
    }

    let headerText = verticalStack(spacing: 2)
    let headline = makeLabel(text: nativeAd.headline, size: 15, weight: .bold, color: style.textColor, lines: 2)
    adView.headlineView = headline
    headerText.addArrangedSubview(headline)

    if let advertiser = nativeAd.advertiser, !advertiser.isEmpty {
      let label = makeLabel(text: advertiser, size: 12, weight: .regular, color: style.secondaryTextColor, lines: 1)
      adView.advertiserView = label
      headerText.addArrangedSubview(label)
    }
    if let rating = nativeAd.starRating {
      let label = makeRatingLabel(rating: rating.doubleValue, color: style.secondaryTextColor)
      adView.starRatingView = label
      headerText.addArrangedSubview(label)
    }
    header.addArrangedSubview(headerText)
    header.addArrangedSubview(makeAdBadge(style: style))
    stack.addArrangedSubview(header)

    if let body = nativeAd.body, !body.isEmpty {
      let label = makeLabel(text: body, size: 13, weight: .regular, color: style.secondaryTextColor, lines: 3)
      adView.bodyView = label
      stack.addArrangedSubview(label)
    }

    // mediaContent is non-optional in the SDK — every native ad has an image or
    // a video, and the MediaView plays the video itself once registered.
    let mediaView = MediaView()
    mediaView.mediaContent = nativeAd.mediaContent
    mediaView.contentMode = .scaleAspectFill
    mediaView.clipsToBounds = true
    mediaView.setContentHuggingPriority(.defaultLow, for: .vertical)
    mediaView.heightAnchor.constraint(greaterThanOrEqualToConstant: 120).isActive = true
    adView.mediaView = mediaView
    stack.addArrangedSubview(mediaView)

    if let cta = makeCTA(nativeAd: nativeAd, style: style) {
      adView.callToActionView = cta
      cta.heightAnchor.constraint(equalToConstant: 44).isActive = true
      stack.addArrangedSubview(cta)
    }

    return stack
  }

  private static func makeSmall(nativeAd: NativeAd, style: ALFNativeAdStyle, adView: NativeAdView) -> UIView {
    let stack = UIStackView()
    stack.axis = .horizontal
    stack.spacing = 10
    stack.alignment = .center

    if let icon = makeIcon(nativeAd: nativeAd, size: 40) {
      adView.iconView = icon
      stack.addArrangedSubview(icon)
    }

    let text = verticalStack(spacing: 1)

    let headlineRow = UIStackView()
    headlineRow.axis = .horizontal
    headlineRow.spacing = 5
    headlineRow.alignment = .center
    headlineRow.addArrangedSubview(makeAdBadge(style: style))
    let headline = makeLabel(text: nativeAd.headline, size: 14, weight: .bold, color: style.textColor, lines: 1)
    adView.headlineView = headline
    headlineRow.addArrangedSubview(headline)
    text.addArrangedSubview(headlineRow)

    if let body = nativeAd.body, !body.isEmpty {
      let label = makeLabel(text: body, size: 12, weight: .regular, color: style.secondaryTextColor, lines: 1)
      adView.bodyView = label
      text.addArrangedSubview(label)
    }
    if let advertiser = nativeAd.advertiser, !advertiser.isEmpty {
      let label = makeLabel(text: advertiser, size: 11, weight: .regular, color: style.secondaryTextColor, lines: 1)
      adView.advertiserView = label
      text.addArrangedSubview(label)
    }
    stack.addArrangedSubview(text)

    if let cta = makeCTA(nativeAd: nativeAd, style: style) {
      adView.callToActionView = cta
      cta.setContentHuggingPriority(.required, for: .horizontal)
      cta.widthAnchor.constraint(greaterThanOrEqualToConstant: 72).isActive = true
      cta.heightAnchor.constraint(equalToConstant: 36).isActive = true
      stack.addArrangedSubview(cta)
    }

    return stack
  }

  // ── Pieces ────────────────────────────────────────
  private static func verticalStack(spacing: CGFloat) -> UIStackView {
    let stack = UIStackView()
    stack.axis = .vertical
    stack.spacing = spacing
    stack.alignment = .fill
    return stack
  }

  private static func makeLabel(
    text: String?, size: CGFloat, weight: UIFont.Weight, color: UIColor, lines: Int
  ) -> UILabel {
    let label = UILabel()
    label.text = text ?? ""
    label.font = .systemFont(ofSize: size, weight: weight)
    label.textColor = color
    label.numberOfLines = lines
    label.lineBreakMode = .byTruncatingTail
    return label
  }

  private static func makeRatingLabel(rating: Double, color: UIColor) -> UILabel {
    let filled = Int(rating.rounded())
    let stars = String(repeating: "★", count: max(0, min(5, filled)))
      + String(repeating: "☆", count: max(0, 5 - min(5, filled)))
    return makeLabel(text: stars, size: 11, weight: .regular, color: color, lines: 1)
  }

  private static func makeIcon(nativeAd: NativeAd, size: CGFloat) -> UIImageView? {
    guard let image = nativeAd.icon?.image else { return nil }
    let view = UIImageView(image: image)
    view.contentMode = .scaleAspectFit
    view.widthAnchor.constraint(equalToConstant: size).isActive = true
    view.heightAnchor.constraint(equalToConstant: size).isActive = true
    return view
  }

  /// Required by AdMob policy: ads must be labelled as such.
  private static func makeAdBadge(style: ALFNativeAdStyle) -> UILabel {
    let label = PaddedLabel()
    label.text = "Ad"
    label.font = .systemFont(ofSize: 10, weight: .bold)
    label.textColor = style.background
    label.backgroundColor = style.ctaBackground
    label.layer.cornerRadius = 2
    label.clipsToBounds = true
    label.setContentHuggingPriority(.required, for: .horizontal)
    label.setContentCompressionResistancePriority(.required, for: .horizontal)
    return label
  }

  private static func makeCTA(nativeAd: NativeAd, style: ALFNativeAdStyle) -> UIButton? {
    guard let title = nativeAd.callToAction, !title.isEmpty else { return nil }
    let button = UIButton(type: .system)
    button.setTitle(title, for: .normal)
    button.setTitleColor(style.ctaTextColor, for: .normal)
    button.titleLabel?.font = .systemFont(ofSize: 14, weight: .semibold)
    button.backgroundColor = style.ctaBackground
    button.layer.cornerRadius = style.cornerRadius > 0 ? style.cornerRadius : 6
    button.clipsToBounds = true
    // The SDK drives the tap through the NativeAdView, so the button must not
    // swallow it with a target of its own.
    button.isUserInteractionEnabled = false
    return button
  }
}

/// UILabel with inset text, used for the "Ad" badge and the overlay label.
final class PaddedLabel: UILabel {
  var insets = UIEdgeInsets(top: 1, left: 5, bottom: 1, right: 5) {
    didSet { invalidateIntrinsicContentSize() }
  }

  override func drawText(in rect: CGRect) {
    super.drawText(in: rect.inset(by: insets))
  }

  override var intrinsicContentSize: CGSize {
    let size = super.intrinsicContentSize
    return CGSize(
      width: size.width + insets.left + insets.right,
      height: size.height + insets.top + insets.bottom
    )
  }
}

/// Label and close button drawn ABOVE a rect-mode native ad, so an app can run
/// the ad full screen as an interstitial — anything the web view draws sits
/// under the ad view and could never be tapped.
///
/// A sibling of the `NativeAdView`, not part of the ad. Only the close button
/// takes touches; the rest falls through to the ad. The button takes them even
/// while disabled, so a tap on a locked button is not turned into an ad click.
///
/// Nothing of the ad may sit under the controls or the system bars (AdMob
/// policy: the "Ad" badge, assets and CTA must stay visible), so `layout()`
/// pads the template's content clear of both; only the ad's background reaches
/// the screen edges.
final class ALFNativeAdOverlayView: UIView {
  var onClose: (() -> Void)?

  private let label = PaddedLabel()
  private let closeButton = UIButton(type: .custom)
  private var leading: NSLayoutConstraint?
  private var trailing: NSLayoutConstraint?
  private var top: NSLayoutConstraint?
  private var height: NSLayoutConstraint?
  private var buttonSize: NSLayoutConstraint?
  // The template's content edges, and their insets before the overlay.
  private weak var contentTop: NSLayoutConstraint?
  private weak var contentBottom: NSLayoutConstraint?
  private var baseTop: CGFloat = 0
  private var baseBottom: CGFloat = 0
  private var size: CGFloat = 40

  init() {
    super.init(frame: .zero)

    label.insets = UIEdgeInsets(top: 3, left: 8, bottom: 3, right: 8)
    label.font = .systemFont(ofSize: 11, weight: .bold)
    label.textColor = UIColor(red: 0x0B / 255, green: 0x0F / 255, blue: 0x14 / 255, alpha: 1)
    label.backgroundColor = UIColor(red: 0xC9 / 255, green: 0xD3 / 255, blue: 0xDE / 255, alpha: 1)
    label.layer.cornerRadius = 4
    label.clipsToBounds = true
    label.translatesAutoresizingMaskIntoConstraints = false
    addSubview(label)

    closeButton.backgroundColor = UIColor.black.withAlphaComponent(0.6)
    closeButton.clipsToBounds = true
    closeButton.layer.borderWidth = 1.5
    closeButton.translatesAutoresizingMaskIntoConstraints = false
    closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
    addSubview(closeButton)

    let side = closeButton.widthAnchor.constraint(equalToConstant: size)
    buttonSize = side
    NSLayoutConstraint.activate([
      label.leadingAnchor.constraint(equalTo: leadingAnchor),
      label.centerYAnchor.constraint(equalTo: centerYAnchor),
      label.trailingAnchor.constraint(lessThanOrEqualTo: closeButton.leadingAnchor, constant: -8),
      closeButton.trailingAnchor.constraint(equalTo: trailingAnchor),
      closeButton.centerYAnchor.constraint(equalTo: centerYAnchor),
      closeButton.heightAnchor.constraint(equalTo: closeButton.widthAnchor),
      side
    ])
  }

  required init?(coder: NSCoder) { nil }

  // Only the button takes touches; the rest falls through to the ad.
  override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
    let hit = super.hitTest(point, with: event)
    return hit === self ? nil : hit
  }

  /// Pin to the top of the ad and remember the template's content insets.
  func attach(to adView: NativeAdView) {
    let l = leadingAnchor.constraint(equalTo: adView.leadingAnchor)
    let t = trailingAnchor.constraint(equalTo: adView.trailingAnchor)
    let tp = topAnchor.constraint(equalTo: adView.topAnchor)
    let h = heightAnchor.constraint(equalToConstant: size)
    NSLayoutConstraint.activate([l, t, tp, h])
    leading = l; trailing = t; top = tp; height = h

    guard let content = adView.viewWithTag(ALFNativeAdViewBuilder.contentTag) else { return }
    for c in adView.constraints where (c.firstItem as? UIView) === content {
      if c.firstAttribute == .top { contentTop = c; baseTop = c.constant }
      if c.firstAttribute == .bottom { contentBottom = c; baseBottom = -c.constant }
    }
  }

  func configure(label text: String?, closeText: String?, closeEnabled: Bool, size newSize: CGFloat) {
    label.text = text
    label.isHidden = (text ?? "").isEmpty

    closeButton.setTitle((closeText ?? "").isEmpty ? "\u{2715}" : closeText, for: .normal)
    closeButton.isEnabled = closeEnabled
    closeButton.setTitleColor(.white, for: .normal)
    closeButton.setTitleColor(UIColor.white.withAlphaComponent(0.7), for: .disabled)
    closeButton.layer.borderColor = UIColor.white.withAlphaComponent(closeEnabled ? 0.55 : 0.25).cgColor

    size = newSize
    buttonSize?.constant = newSize
    height?.constant = newSize
    closeButton.layer.cornerRadius = newSize / 2
    closeButton.titleLabel?.font = .systemFont(ofSize: newSize * 0.42, weight: .bold)
  }

  /// `cover`: how far each system bar reaches into the ad, in points.
  func layout(cover: UIEdgeInsets, margin: CGFloat) {
    leading?.constant = cover.left + margin
    trailing?.constant = -(cover.right + margin)
    top?.constant = cover.top + margin
    contentTop?.constant = cover.top + margin + size + baseTop
    contentBottom?.constant = -(cover.bottom + baseBottom)
  }

  /// Give the template's content back the insets it had before the overlay.
  func detach() {
    contentTop?.constant = baseTop
    contentBottom?.constant = -baseBottom
  }

  @objc private func closeTapped() {
    onClose?()
  }
}
