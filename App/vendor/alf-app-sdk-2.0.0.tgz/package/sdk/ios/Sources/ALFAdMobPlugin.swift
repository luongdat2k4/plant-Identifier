import Foundation
import Capacitor
import GoogleMobileAds

@objc(ALFAdMobPlugin)
public class ALFAdMobPlugin: CAPPlugin {

  private var interstitials: [String: InterstitialAd] = [:]
  // Interstitials on screen → their ad unit, for the show/dismiss events.
  private var presentingInterstitials: [ObjectIdentifier: String] = [:]
  private var rewardedAds: [String: RewardedAd] = [:]
  private var openAppAds: [String: AppOpenAd] = [:]
  private var nativeAds: [String: NativeAd] = [:]
  private var rewardedGranted: [String: Bool] = [:]
  private var nativeAdLoaders: [String: AdLoader] = [:]
  // Rendered native ad views, keyed by ad unit — the NativeAdView is what makes
  // the ad a real ad: it records the impression and owns the click handling.
  private var nativeAdViews: [String: NativeAdView] = [:]
  // Constraints held for rect mode so updateNativeAdRect() can move the view
  // without rebuilding it.
  private var nativeAdRectConstraints: [String: (x: NSLayoutConstraint, y: NSLayoutConstraint, w: NSLayoutConstraint, h: NSLayoutConstraint)] = [:]
  // Controls drawn over a rect-mode native ad (label + close button), keyed by
  // ad unit. Main thread only.
  private var nativeAdOverlays: [String: ALFNativeAdOverlayView] = [:]

  // ── Initialize ──────────────────────────────────
  @objc func initialize(_ call: CAPPluginCall) {
    guard let appId = call.getString("appId"), !appId.isEmpty else {
      call.reject("appId is required")
      return
    }

    MobileAds.shared.start { [weak self] status in
      var result = JSObject()
      result["initialized"] = true
      call.resolve(result)
    }
  }

  // ── Interstitial ────────────────────────────────
  @objc func loadInterstitial(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }

    InterstitialAd.load(with: adUnitId, request: Request()) { [weak self] ad, error in
      if let error = error {
        self?.interstitials.removeValue(forKey: adUnitId)
        call.reject(error.localizedDescription)
        return
      }
      guard let ad = ad else {
        call.reject("Ad is nil")
        return
      }
      ad.fullScreenContentDelegate = self
      ad.paidEventHandler = { [weak self] adValue in
        self?.notifyAdPaid("OnInterstitialAdPaidEvent", adUnitId: adUnitId, adValue: adValue)
      }
      self?.interstitials[adUnitId] = ad
      call.resolve()
    }
  }

  @objc func isInterstitialReady(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    var result = JSObject()
    result["ready"] = interstitials[adUnitId] != nil
    call.resolve(result)
  }

  @objc func showInterstitial(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    // An interstitial plays once: it leaves the cache as it is shown, same as
    // Android, and is tracked in `presentingInterstitials` until it closes.
    guard let ad = interstitials.removeValue(forKey: adUnitId) else {
      call.reject("Interstitial not ready")
      return
    }

    DispatchQueue.main.async {
      guard let root = self.bridge?.viewController else {
        call.reject("No view controller")
        return
      }
      self.presentingInterstitials[ObjectIdentifier(ad)] = adUnitId
      ad.present(from: root)
      call.resolve()
    }
  }

  // ── Rewarded ────────────────────────────────────
  @objc func loadRewardedAd(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }

    RewardedAd.load(with: adUnitId, request: Request()) { [weak self] ad, error in
      if let error = error {
        self?.rewardedAds.removeValue(forKey: adUnitId)
        call.reject(error.localizedDescription)
        return
      }
      guard let ad = ad else {
        call.reject("Ad is nil")
        return
      }
      ad.fullScreenContentDelegate = self
      self?.rewardedAds[adUnitId] = ad
      self?.rewardedGranted[adUnitId] = false
      call.resolve()
    }
  }

  @objc func isRewardedAdReady(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    var result = JSObject()
    result["ready"] = rewardedAds[adUnitId] != nil
    call.resolve(result)
  }

  @objc func showRewardedAd(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    guard let ad = rewardedAds[adUnitId] else {
      call.reject("Rewarded ad not ready")
      return
    }

    DispatchQueue.main.async {
      guard let root = self.bridge?.viewController else {
        call.reject("No view controller")
        return
      }
      ad.present(from: root) { [weak self] in
        self?.rewardedGranted[adUnitId] = true
        var event = JSObject()
        event["adUnitId"] = adUnitId
        event["amount"] = ad.adReward.amount
        self?.notifyListeners("OnRewardedAdReceivedRewardEvent", data: event)
      }
      call.resolve()
    }
  }

  // ── Open App ────────────────────────────────────
  @objc func loadOpenAppAd(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }

    AppOpenAd.load(with: adUnitId, request: Request(), orientation: .portrait) { [weak self] ad, error in
      if let error = error {
        self?.openAppAds.removeValue(forKey: adUnitId)
        call.reject(error.localizedDescription)
        return
      }
      guard let ad = ad else {
        call.reject("Ad is nil")
        return
      }
      ad.fullScreenContentDelegate = self
      self?.openAppAds[adUnitId] = ad
      call.resolve()
    }
  }

  @objc func isOpenAppAdReady(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    var result = JSObject()
    result["ready"] = openAppAds[adUnitId] != nil
    call.resolve(result)
  }

  @objc func showOpenAppAd(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    guard let ad = openAppAds[adUnitId] else {
      call.reject("Open app ad not ready")
      return
    }

    DispatchQueue.main.async {
      guard let root = self.bridge?.viewController else {
        call.reject("No view controller")
        return
      }
      ad.present(from: root)
      call.resolve()
    }
  }

  // ── Native Ad ───────────────────────────────────
  /// What a caller waiting on a native ad load wants once it arrives.
  private enum PendingNativeRequest {
    /// loadNativeAd — resolve with the ad's assets.
    case assets(CAPPluginCall)
    /// showNativeAd — render the ad, then resolve.
    case show(CAPPluginCall)

    var call: CAPPluginCall {
      switch self {
      case .assets(let call): return call
      case .show(let call): return call
      }
    }
  }

  private var pendingNativeRequests: [String: PendingNativeRequest] = [:]

  /// Start a load for the unit, replacing whatever was cached for it.
  /// The call's `video` / `mediaAspectRatio` go into the request — the SDK fixes
  /// them at load time, so they cannot be changed for an ad once it is cached.
  private func loadNativeAdInternal(_ adUnitId: String, request: PendingNativeRequest) {
    destroyNativeAdView(adUnitId)
    if let existing = nativeAds.removeValue(forKey: adUnitId) {
      existing.unregisterAdView()
    }

    let loader = AdLoader(
      adUnitID: adUnitId,
      rootViewController: bridge?.viewController,
      adTypes: [.native],
      options: ALFAdMobPlugin.nativeAdLoaderOptions(request.call)
    )
    loader.delegate = self
    nativeAdLoaders[adUnitId] = loader
    pendingNativeRequests[adUnitId] = request
    loader.load(Request())
  }

  /// Load a native ad and return its assets to JavaScript.
  ///
  /// Deprecated for display: these assets are for preview and debugging only —
  /// rendering them in the web view records no impression and leaves clicks
  /// inert. Use `showNativeAd` to display the ad.
  @objc func loadNativeAd(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    loadNativeAdInternal(adUnitId, request: .assets(call))
  }

  @objc func isNativeAdReady(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    var result = JSObject()
    result["ready"] = nativeAds[adUnitId] != nil
    call.resolve(result)
  }

  /// Render the native ad in a real `NativeAdView` laid over the web view.
  ///
  /// This is the only path that displays a native ad for real: binding the
  /// assets and setting `nativeAd` is what makes the SDK record the impression
  /// and take over click handling.
  @objc func showNativeAd(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }

    // Re-show a view we already built rather than registering the same NativeAd
    // on a fresh NativeAdView, which would record a second impression for one ad.
    if let existing = nativeAdViews[adUnitId] {
      let rect = call.getObject("rect")
      let overlay = call.getObject("overlay")
      DispatchQueue.main.async {
        if let rect = rect, let c = self.nativeAdRectConstraints[adUnitId] {
          c.x.constant = ALFAdMobPlugin.number(rect, "x")
          c.y.constant = ALFAdMobPlugin.number(rect, "y")
          c.w.constant = ALFAdMobPlugin.number(rect, "width")
          c.h.constant = ALFAdMobPlugin.number(rect, "height")
        }
        existing.isHidden = false
        if let overlay = overlay { self.applyNativeAdOverlay(adUnitId, adView: existing, options: overlay) }
        self.layoutNativeAdOverlay(adUnitId)
        call.resolve()
      }
      return
    }

    if let cached = nativeAds[adUnitId] {
      renderNativeAd(call: call, adUnitId: adUnitId, nativeAd: cached)
      return
    }
    loadNativeAdInternal(adUnitId, request: .show(call))
  }

  /// Move an ad shown in rect mode. Called from JS on scroll and resize.
  @objc func updateNativeAdRect(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    guard let constraints = nativeAdRectConstraints[adUnitId] else {
      call.reject("Native ad is not shown in rect mode")
      return
    }
    guard let rect = call.getObject("rect") else {
      call.reject("rect is required")
      return
    }

    DispatchQueue.main.async {
      constraints.x.constant = ALFAdMobPlugin.number(rect, "x")
      constraints.y.constant = ALFAdMobPlugin.number(rect, "y")
      constraints.w.constant = ALFAdMobPlugin.number(rect, "width")
      constraints.h.constant = ALFAdMobPlugin.number(rect, "height")
      self.layoutNativeAdOverlay(adUnitId)
      self.nativeAdViews[adUnitId]?.superview?.layoutIfNeeded()
      call.resolve()
    }
  }

  /// Change the controls drawn over a rect-mode native ad — e.g. tick the close
  /// button's countdown, then enable it. Adds the overlay if the ad has none.
  @objc func updateNativeAdOverlay(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    guard let adView = nativeAdViews[adUnitId] else {
      call.reject("Native ad view not found")
      return
    }
    guard let overlay = call.getObject("overlay") else {
      call.reject("overlay is required")
      return
    }
    DispatchQueue.main.async {
      self.applyNativeAdOverlay(adUnitId, adView: adView, options: overlay)
      self.layoutNativeAdOverlay(adUnitId)
      call.resolve()
    }
  }

  /// Take the overlay off a native ad and give the content back its insets.
  /// No-op when the ad has none.
  @objc func removeNativeAdOverlay(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    guard nativeAdViews[adUnitId] != nil else {
      call.reject("Native ad view not found")
      return
    }
    DispatchQueue.main.async {
      if let overlay = self.nativeAdOverlays.removeValue(forKey: adUnitId) {
        overlay.detach()
        overlay.removeFromSuperview()
      }
      call.resolve()
    }
  }

  @objc func hideNativeAd(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }
    guard let adView = nativeAdViews[adUnitId] else {
      call.reject("Native ad view not found")
      return
    }
    DispatchQueue.main.async {
      adView.isHidden = true
      self.nativeAdOverlays[adUnitId]?.isHidden = true
      call.resolve()
    }
  }

  @objc func destroyNativeAd(_ call: CAPPluginCall) {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return
    }

    destroyNativeAdView(adUnitId)
    if let ad = nativeAds.removeValue(forKey: adUnitId) {
      ad.unregisterAdView()
    }
    nativeAdLoaders.removeValue(forKey: adUnitId)
    call.resolve()
  }

  // ── Native video ────────────────────────────────
  // While the SDK's own controls are in charge (custom controls not granted),
  // the player may ignore these — the app is expected to leave it alone then.

  @objc func playNativeAdVideo(_ call: CAPPluginCall) {
    guard let controller = videoController(for: call) else { return }
    DispatchQueue.main.async {
      controller.play()
      call.resolve()
    }
  }

  @objc func pauseNativeAdVideo(_ call: CAPPluginCall) {
    guard let controller = videoController(for: call) else { return }
    DispatchQueue.main.async {
      controller.pause()
      call.resolve()
    }
  }

  @objc func muteNativeAdVideo(_ call: CAPPluginCall) {
    guard let muted = call.getBool("muted") else {
      call.reject("muted is required")
      return
    }
    guard let controller = videoController(for: call) else { return }
    DispatchQueue.main.async {
      controller.setMute(muted)
      call.resolve()
    }
  }

  /// The video controller of the unit's ad, or nil after rejecting the call.
  private func videoController(for call: CAPPluginCall) -> VideoController? {
    guard let adUnitId = call.getString("adUnitId") else {
      call.reject("adUnitId is required")
      return nil
    }
    guard let nativeAd = nativeAds[adUnitId] else {
      call.reject("Native ad not loaded")
      return nil
    }
    guard nativeAd.mediaContent.hasVideoContent else {
      call.reject("Native ad has no video content")
      return nil
    }
    return nativeAd.mediaContent.videoController
  }

  /// Deprecated: always rejects. The SDK registers clicks itself through the
  /// `NativeAdView` built by `showNativeAd`; there is no supported way to
  /// report a click by hand, and pretending otherwise hid the fact that ads
  /// rendered in the web view were never clickable at all.
  @objc func reportNativeAdClick(_ call: CAPPluginCall) {
    call.reject(
      "reportNativeAdClick is not supported. AdMob registers clicks through the "
        + "NativeAdView created by showNativeAd() — call that to display the ad."
    )
  }

  // ── Native ad rendering ─────────────────────────
  private func renderNativeAd(call: CAPPluginCall, adUnitId: String, nativeAd: NativeAd) {
    let template = call.getString("template") ?? "medium"
    let style = ALFNativeAdStyle(from: call.getObject("style"))
    let rect = call.getObject("rect")
    let position = call.getString("position") ?? "BOTTOM_CENTER"
    let height = call.getDouble("height")
    let overlay = call.getObject("overlay")

    DispatchQueue.main.async {
      guard let rootView = self.bridge?.viewController?.view else {
        call.reject("No root view controller")
        return
      }

      self.destroyNativeAdView(adUnitId)

      let adView = ALFNativeAdViewBuilder.make(nativeAd: nativeAd, template: template, style: style)
      adView.translatesAutoresizingMaskIntoConstraints = false
      rootView.addSubview(adView)

      if let rect = rect {
        // Rect mode — CSS pixels map 1:1 to points in the web view.
        let x = adView.leadingAnchor.constraint(
          equalTo: rootView.leadingAnchor, constant: ALFAdMobPlugin.number(rect, "x"))
        let y = adView.topAnchor.constraint(
          equalTo: rootView.topAnchor, constant: ALFAdMobPlugin.number(rect, "y"))
        let w = adView.widthAnchor.constraint(equalToConstant: ALFAdMobPlugin.number(rect, "width"))
        let h = adView.heightAnchor.constraint(equalToConstant: ALFAdMobPlugin.number(rect, "height"))
        NSLayoutConstraint.activate([x, y, w, h])
        self.nativeAdRectConstraints[adUnitId] = (x, y, w, h)
      } else {
        let guide = rootView.safeAreaLayoutGuide
        var constraints: [NSLayoutConstraint] = [
          adView.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
          adView.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
          position == "BOTTOM_CENTER"
            ? adView.bottomAnchor.constraint(equalTo: guide.bottomAnchor)
            : adView.topAnchor.constraint(equalTo: guide.topAnchor)
        ]
        if let height = height, height > 0 {
          constraints.append(adView.heightAnchor.constraint(equalToConstant: CGFloat(height)))
        }
        NSLayoutConstraint.activate(constraints)
      }

      self.nativeAdViews[adUnitId] = adView
      if let overlay = overlay, rect != nil {
        self.applyNativeAdOverlay(adUnitId, adView: adView, options: overlay)
        self.layoutNativeAdOverlay(adUnitId)
      }
      call.resolve()
    }
  }

  /// Detach and release the rendered view for a unit, if there is one.
  private func destroyNativeAdView(_ adUnitId: String) {
    nativeAdRectConstraints.removeValue(forKey: adUnitId)
    guard let adView = nativeAdViews.removeValue(forKey: adUnitId) else { return }
    let remove = {
      self.nativeAdOverlays.removeValue(forKey: adUnitId)?.removeFromSuperview()
      adView.removeFromSuperview()
    }
    if Thread.isMainThread {
      remove()
    } else {
      DispatchQueue.main.async(execute: remove)
    }
  }

  // ── Native ad overlay ───────────────────────────
  // See `ALFNativeAdOverlayView`. Rect mode only: the overlay follows the rect
  // constraints, and is laid out again whenever they change.
  private static let overlayDefaultSize: CGFloat = 40
  private static let overlayMargin: CGFloat = 10

  /// Create the unit's overlay if needed and apply the options to it. Main thread.
  private func applyNativeAdOverlay(_ adUnitId: String, adView: NativeAdView, options: JSObject) {
    let overlay: ALFNativeAdOverlayView
    if let existing = nativeAdOverlays[adUnitId] {
      overlay = existing
    } else {
      guard let rootView = adView.superview else { return }
      overlay = ALFNativeAdOverlayView()
      overlay.translatesAutoresizingMaskIntoConstraints = false
      overlay.onClose = { [weak self] in
        self?.notifyAdUnitEvent("OnNativeAdOverlayCloseEvent", adUnitId: adUnitId)
      }
      // Added after the ad view, so it draws — and takes touches — above it.
      rootView.addSubview(overlay)
      overlay.attach(to: adView)
      nativeAdOverlays[adUnitId] = overlay
    }
    let size = (options["size"] as? NSNumber).map { CGFloat($0.doubleValue) } ?? 0
    overlay.configure(
      label: options["label"] as? String,
      closeText: options["closeText"] as? String,
      closeEnabled: (options["closeEnabled"] as? Bool) ?? true,
      size: size > 0 ? size : ALFAdMobPlugin.overlayDefaultSize)
  }

  /// Place the overlay below any system bar the ad reaches under, and pad the
  /// ad's content clear of the overlay and the bars. Main thread.
  private func layoutNativeAdOverlay(_ adUnitId: String) {
    guard let overlay = nativeAdOverlays[adUnitId],
          let adView = nativeAdViews[adUnitId],
          let rootView = adView.superview,
          let rect = nativeAdRectConstraints[adUnitId] else { return }
    let safe = rootView.safeAreaInsets
    let bounds = rootView.bounds
    let x = rect.x.constant, y = rect.y.constant
    let w = rect.w.constant, h = rect.h.constant
    // How far each system bar reaches into the ad.
    let cover = UIEdgeInsets(
      top: max(0, safe.top - y),
      left: max(0, safe.left - x),
      bottom: bounds.height > 0 ? max(0, (y + h) - (bounds.height - safe.bottom)) : 0,
      right: bounds.width > 0 ? max(0, (x + w) - (bounds.width - safe.right)) : 0)
    overlay.layout(cover: cover, margin: ALFAdMobPlugin.overlayMargin)
    // Follows the ad: showNativeAd() re-showing a hidden ad brings it back too.
    overlay.isHidden = adView.isHidden
  }

  private static func number(_ obj: JSObject, _ key: String) -> CGFloat {
    guard let value = obj[key] as? NSNumber else { return 0 }
    return CGFloat(value.doubleValue)
  }

  // ── Helpers ─────────────────────────────────────
  private func resolvePendingCall(forAdUnitId adUnitId: String, withResult result: JSObject) {
    guard let request = pendingNativeRequests.removeValue(forKey: adUnitId) else { return }
    request.call.resolve(result)
  }

  private func rejectPendingCall(forAdUnitId adUnitId: String, withError error: String) {
    guard let request = pendingNativeRequests.removeValue(forKey: adUnitId) else { return }
    request.call.reject(error)
  }

  // ── Native ad events ────────────────────────────
  /// Which unit a cached ad belongs to — the SDK hands back the ad, not its id.
  fileprivate func adUnitId(for nativeAd: NativeAd) -> String? {
    for (id, ad) in nativeAds where ad === nativeAd {
      return id
    }
    return nil
  }

  /// Map a loaded ad's assets to the shape JS expects (NativeAdData).
  fileprivate func nativeAdPayload(adUnitId: String, nativeAd: NativeAd) -> JSObject {
    var result = JSObject()
    result["adUnitId"] = adUnitId

    if let headline = nativeAd.headline { result["headline"] = headline } else { result["headline"] = "" }
    if let body = nativeAd.body { result["body"] = body } else { result["body"] = "" }
    if let cta = nativeAd.callToAction { result["callToAction"] = cta } else { result["callToAction"] = "" }

    // Icon
    if let icon = nativeAd.icon, let iconUrl = icon.imageURL {
      result["iconUrl"] = iconUrl.absoluteString
    } else {
      result["iconUrl"] = ""
    }

    // Images
    if let images = nativeAd.images, let firstImage = images.first, let imageUrl = firstImage.imageURL {
      result["imageUrl"] = imageUrl.absoluteString
    } else {
      result["imageUrl"] = ""
    }

    // Media content is a UIImage or a video stream owned by the SDK — there is
    // no URL to hand out, so describe it instead. (This used to carry the
    // UIImage itself, which cannot cross the bridge at all.)
    let media = nativeAd.mediaContent
    result["hasVideoContent"] = media.hasVideoContent
    result["mediaAspectRatio"] = Double(media.aspectRatio)
    result["videoDuration"] = media.hasVideoContent ? media.duration : 0.0
    result["videoCustomControlsEnabled"] =
      media.hasVideoContent && media.videoController.customControlsEnabled()

    if let price = nativeAd.price { result["price"] = price } else { result["price"] = "" }
    if let store = nativeAd.store { result["store"] = store } else { result["store"] = "" }
    if let rating = nativeAd.starRating { result["starRating"] = rating.doubleValue } else { result["starRating"] = 0.0 }
    if let advertiser = nativeAd.advertiser { result["advertiser"] = advertiser } else { result["advertiser"] = "" }
    return result
  }

  /// Request options from the caller. Video starts muted unless told otherwise —
  /// the SDK default too, and what AdMob recommends for ads that autoplay in feed.
  private static func nativeAdLoaderOptions(_ call: CAPPluginCall) -> [AdLoaderOptions] {
    let video = call.getObject("video")
    let videoOptions = VideoOptions()
    videoOptions.shouldStartMuted = (video?["startMuted"] as? Bool) ?? true
    videoOptions.areCustomControlsRequested = (video?["customControlsRequested"] as? Bool) ?? false
    videoOptions.isClickToExpandRequested = (video?["clickToExpandRequested"] as? Bool) ?? false

    let mediaOptions = NativeAdMediaAdLoaderOptions()
    switch call.getString("mediaAspectRatio") {
    case "landscape": mediaOptions.mediaAspectRatio = .landscape
    case "portrait": mediaOptions.mediaAspectRatio = .portrait
    case "square": mediaOptions.mediaAspectRatio = .square
    default: mediaOptions.mediaAspectRatio = .any
    }

    return [videoOptions, mediaOptions]
  }

  /// Which unit a video controller belongs to — its delegate callbacks carry
  /// only the controller.
  fileprivate func adUnitId(for videoController: VideoController) -> String? {
    for (id, ad) in nativeAds where ad.mediaContent.videoController === videoController {
      return id
    }
    return nil
  }

  fileprivate func notifyNativeAdVideo(_ videoController: VideoController, state: String) {
    guard let unitId = adUnitId(for: videoController) else { return }
    var event = JSObject()
    event["adUnitId"] = unitId
    event["state"] = state
    notifyListeners("OnNativeAdVideoEvent", data: event)
  }

  fileprivate func notifyAdUnitEvent(_ eventName: String, adUnitId: String) {
    var event = JSObject()
    event["adUnitId"] = adUnitId
    notifyListeners(eventName, data: event)
  }

  /// Forward ad revenue to JS so the app can report it to its attribution SDK.
  /// `value` is in whole currency units on both platforms (Android divides micros).
  fileprivate func notifyAdPaid(_ eventName: String, adUnitId: String, adValue: AdValue) {
    var event = JSObject()
    event["adUnitId"] = adUnitId
    event["value"] = adValue.value.doubleValue
    event["currencyCode"] = adValue.currencyCode
    event["precision"] = ALFAdMobPlugin.precisionName(adValue.precision)
    notifyListeners(eventName, data: event)
  }

  private static func precisionName(_ precision: AdValuePrecision) -> String {
    switch precision {
    case .estimated: return "estimated"
    case .publisherProvided: return "publisherProvided"
    case .precise: return "precise"
    case .unknown: return "unknown"
    @unknown default: return "unknown"
    }
  }
}

// ── FullScreenContentDelegate ─────────────────────
extension ALFAdMobPlugin: FullScreenContentDelegate {
  public func adWillPresentFullScreenContent(_ ad: FullScreenPresentingAd) {
    if let id = presentingInterstitials[ObjectIdentifier(ad as AnyObject)] {
      notifyAdUnitEvent("OnInterstitialAdShowedEvent", adUnitId: id)
    }
  }

  public func ad(_ ad: FullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
    if let id = presentingInterstitials.removeValue(forKey: ObjectIdentifier(ad as AnyObject)) {
      var event = JSObject()
      event["adUnitId"] = id
      event["message"] = error.localizedDescription
      notifyListeners("OnInterstitialAdFailedToShowEvent", data: event)
    }
  }

  public func adDidDismissFullScreenContent(_ ad: FullScreenPresentingAd) {
    // Handle rewarded skip
    for (id, rewardedAd) in rewardedAds {
      if rewardedAd === ad {
        if rewardedGranted[id] != true {
          var event = JSObject()
          event["adUnitId"] = id
          notifyListeners("OnRewardedAdSkippedEvent", data: event)
        }
        rewardedAds.removeValue(forKey: id)
        rewardedGranted.removeValue(forKey: id)
        notifyAdUnitEvent("OnRewardedAdDismissedEvent", adUnitId: id)
        return
      }
    }
    // Interstitials leave `interstitials` when shown — see showInterstitial().
    if let id = presentingInterstitials.removeValue(forKey: ObjectIdentifier(ad as AnyObject)) {
      notifyAdUnitEvent("OnInterstitialAdDismissedEvent", adUnitId: id)
      return
    }
    // Clean up open app ads
    for (id, openAppAd) in openAppAds {
      if openAppAd === ad {
        openAppAds.removeValue(forKey: id)
        notifyAdUnitEvent("OnOpenAppAdDismissedEvent", adUnitId: id)
        return
      }
    }
  }
}

// ── NativeAdLoaderDelegate ────────────────────────
extension ALFAdMobPlugin: NativeAdLoaderDelegate {
  public func adLoader(_ adLoader: AdLoader, didReceive nativeAd: NativeAd) {
    // Find the ad unit id for this loader
    var adUnitId: String?
    for (id, loader) in nativeAdLoaders {
      if loader === adLoader {
        adUnitId = id
        break
      }
    }

    guard let unitId = adUnitId else { return }

    nativeAds[unitId] = nativeAd
    // Impressions and clicks come from the ad itself, not the loader.
    nativeAd.delegate = self
    // Set before the caller can show the ad: the paid event fires off the
    // impression, which happens as soon as the view goes on screen.
    nativeAd.paidEventHandler = { [weak self] adValue in
      self?.notifyAdPaid("OnNativeAdPaidEvent", adUnitId: unitId, adValue: adValue)
    }
    if nativeAd.mediaContent.hasVideoContent {
      nativeAd.mediaContent.videoController.delegate = self
    }
    // The load is over; keeping the loader would only pin it in memory.
    nativeAdLoaders.removeValue(forKey: unitId)

    let assets = nativeAdPayload(adUnitId: unitId, nativeAd: nativeAd)
    notifyListeners("OnNativeAdLoadedEvent", data: assets)

    // showNativeAd() wants the ad rendered, not its assets shipped to JS.
    if case .show(let call)? = pendingNativeRequests[unitId] {
      pendingNativeRequests.removeValue(forKey: unitId)
      renderNativeAd(call: call, adUnitId: unitId, nativeAd: nativeAd)
      return
    }

    resolvePendingCall(forAdUnitId: unitId, withResult: assets)
  }

  public func adLoader(_ adLoader: AdLoader, didFailToReceiveAdWithError error: Error) {
    var adUnitId: String?
    for (id, loader) in nativeAdLoaders {
      if loader === adLoader {
        adUnitId = id
        break
      }
    }

    guard let unitId = adUnitId else { return }
    nativeAdLoaders.removeValue(forKey: unitId)

    var event = JSObject()
    event["adUnitId"] = unitId
    event["error"] = error.localizedDescription
    notifyListeners("OnNativeAdFailedToLoadEvent", data: event)

    rejectPendingCall(forAdUnitId: unitId, withError: error.localizedDescription)
  }
}

// ── NativeAdDelegate ──────────────────────────────
// Impression and click are reported by the SDK once the NativeAdView is on
// screen and tapped. Without this the app has no way to know an ad was really
// seen — showNativeAd() resolving only means the view was attached — nor that
// the user just left for the advertiser.
extension ALFAdMobPlugin: NativeAdDelegate {
  public func nativeAdDidRecordImpression(_ nativeAd: NativeAd) {
    guard let unitId = adUnitId(for: nativeAd) else { return }
    notifyAdUnitEvent("OnNativeAdImpressionEvent", adUnitId: unitId)
  }

  public func nativeAdDidRecordClick(_ nativeAd: NativeAd) {
    guard let unitId = adUnitId(for: nativeAd) else { return }
    notifyAdUnitEvent("OnNativeAdClickedEvent", adUnitId: unitId)
  }
}

// ── VideoControllerDelegate ───────────────────────
// Same caveat as NativeAdDelegate: every method is an optional @objc
// requirement, so a misspelt name compiles and is simply never called. There
// is no "start" callback on iOS — the first frame arrives as a play.
extension ALFAdMobPlugin: VideoControllerDelegate {
  public func videoControllerDidPlayVideo(_ videoController: VideoController) {
    notifyNativeAdVideo(videoController, state: "play")
  }

  public func videoControllerDidPauseVideo(_ videoController: VideoController) {
    notifyNativeAdVideo(videoController, state: "pause")
  }

  public func videoControllerDidEndVideoPlayback(_ videoController: VideoController) {
    notifyNativeAdVideo(videoController, state: "end")
  }

  public func videoControllerDidMuteVideo(_ videoController: VideoController) {
    notifyNativeAdVideo(videoController, state: "mute")
  }

  public func videoControllerDidUnmuteVideo(_ videoController: VideoController) {
    notifyNativeAdVideo(videoController, state: "unmute")
  }
}
