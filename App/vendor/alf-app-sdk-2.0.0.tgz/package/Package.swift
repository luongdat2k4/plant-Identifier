// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "AlfAppSdk",
    platforms: [
        .iOS(.v14)
    ],
    products: [
        .library(
            name: "AlfAppSdk",
            targets: ["AlfAppSdk"]
        )
    ],
    // TODO(1.3.0): Firebase Analytics is Android-only (ALFFirebasePlugin). For iOS, add
    // firebase-ios-sdk (FirebaseAnalytics) here plus an ALFFirebase Swift plugin with
    // the same methods; until then FirebaseAnalyticsController is a no-op on iOS.
    dependencies: [
        .package(url: "https://github.com/ionic-team/capacitor-swift-pm.git", from: "8.0.0"),
        .package(url: "https://github.com/AppLovin/AppLovin-MAX-Swift-Package.git", from: "12.6.0"),
        .package(url: "https://github.com/googleads/swift-package-manager-google-mobile-ads.git", from: "12.6.0")
    ],
    targets: [
        .target(
            name: "AlfAppSdk",
            dependencies: [
                .product(name: "Capacitor", package: "capacitor-swift-pm"),
                .product(name: "AppLovinSDK", package: "AppLovin-MAX-Swift-Package"),
                .product(name: "GoogleMobileAds", package: "swift-package-manager-google-mobile-ads")
            ],
            path: "sdk/ios/Sources"
        )
    ]
)
